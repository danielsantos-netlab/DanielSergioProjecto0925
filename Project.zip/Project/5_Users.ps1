# =============================================================================
# Modules/5_Users.ps1 - User & Group Management
# Supports both Active Directory and local users (auto-detected)
# =============================================================================

. "$Global:ProjectRoot\Config.ps1"

# Detect AD availability if not already set
if ($null -eq $Global:ADAvailable) {
    $Global:ADAvailable = $null -ne (Get-Module -ListAvailable -Name "ActiveDirectory" -ErrorAction SilentlyContinue)
}

function Get-ADMode { return $Global:ADAvailable }

function Show-ADMode {
    $mode = if (Get-ADMode) { "Active Directory" } else { "Local Users" }
    Write-Host "  Mode: $mode" -ForegroundColor DarkGray
    Write-Host ""
}

# =============================================================================
# 1. List users
# =============================================================================
function Show-Users {
    Show-Header "USER LIST"
    Show-ADMode

    if (Get-ADMode) {
        try {
            Import-Module ActiveDirectory -ErrorAction Stop
            Get-ADUser -Filter * -Properties DisplayName, Enabled, LastLogonDate, PasswordLastSet |
                Select-Object SamAccountName, DisplayName, Enabled,
                    @{N="LastLogin"; E={ if ($_.LastLogonDate) { $_.LastLogonDate.ToString("yyyy-MM-dd") } else { "Never" } }},
                    @{N="PasswordUpdated"; E={ if ($_.PasswordLastSet) { $_.PasswordLastSet.ToString("yyyy-MM-dd") } else { "N/A" } }} |
                Format-Table -AutoSize
        } catch {
            Write-Host "  Error accessing AD: $($_.Exception.Message)" -ForegroundColor Red
            Write-Log "AD error listing users: $($_.Exception.Message)" "ERROR"
        }
    } else {
        Get-LocalUser | Select-Object Name, Enabled, LastLogon,
            @{N="Description"; E={ $_.Description }} |
            Format-Table -AutoSize
    }
    Write-Log "User list queried." "INFO"
    Pause-Screen
}

# =============================================================================
# 2. Create user
# =============================================================================
function New-UserInteractive {
    Show-Header "CREATE USER"
    Show-ADMode

    Write-Host "  Username: " -NoNewline -ForegroundColor Cyan
    $username = Read-Host
    Write-Host "  Full name: " -NoNewline -ForegroundColor Cyan
    $fullname = Read-Host
    Write-Host "  Password: " -NoNewline -ForegroundColor Cyan
    $password = Read-Host -AsSecureString
    Write-Host "  Description (optional): " -NoNewline -ForegroundColor Cyan
    $desc = Read-Host

    if ([string]::IsNullOrWhiteSpace($username)) {
        Write-Host "  Invalid username." -ForegroundColor Red
        Pause-Screen; return
    }

    if (Get-ADMode) {
        try {
            Import-Module ActiveDirectory -ErrorAction Stop
            Write-Host "  OU (ex: OU=Users,DC=domain,DC=local) ou Enter para default: " -NoNewline -ForegroundColor Cyan
            $ou = Read-Host
            $params = @{
                SamAccountName = $username
                Name           = if ($fullname) { $fullname } else { $username }
                DisplayName    = if ($fullname) { $fullname } else { $username }
                AccountPassword = $password
                Enabled        = $true
                Description    = $desc
            }
            if ($ou) { $params["Path"] = $ou }
            New-ADUser @params
            Write-Host "  [OK] AD user created: $username" -ForegroundColor Green
            Write-Log "AD user created: $username" "INFO"
        } catch {
            Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
            Write-Log "Error creating AD user ${username}: $($_.Exception.Message)" "ERROR"
        }
    } else {
        try {
            $params = @{
                Name        = $username
                Password    = $password
                FullName    = $fullname
                Description = $desc
            }
            New-LocalUser @params
            Write-Host "  [OK] Local user created: $username" -ForegroundColor Green
            Write-Log "Local user created: $username" "INFO"
        } catch {
            Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
            Write-Log "Error creating local user ${username}: $($_.Exception.Message)" "ERROR"
        }
    }
    Pause-Screen
}

# =============================================================================
# 3. Delete user
# =============================================================================
function Remove-UserInteractive {
    Show-Header "REMOVE USER"
    Show-ADMode

    Write-Host "  Username to remove: " -NoNewline -ForegroundColor Cyan
    $username = Read-Host

    Write-Host "  Confirm removal of '$username'? (Y/N): " -NoNewline -ForegroundColor Yellow
    $confirm = Read-Host
    if ($confirm.ToUpper() -ne "Y") { Write-Host "  Cancelled." -ForegroundColor DarkGray; Pause-Screen; return }

    if (Get-ADMode) {
        try {
            Import-Module ActiveDirectory -ErrorAction Stop
            Remove-ADUser -Identity $username -Confirm:$false
            Write-Host "  [OK] AD user removed: $username" -ForegroundColor Green
            Write-Log "AD user removed: $username" "WARN"
        } catch {
            Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
            Write-Log "Error removing AD user ${username}: $($_.Exception.Message)" "ERROR"
        }
    } else {
        try {
            Remove-LocalUser -Name $username
            Write-Host "  [OK] Local user removed: $username" -ForegroundColor Green
            Write-Log "Local user removed: $username" "WARN"
        } catch {
            Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
            Write-Log "Error removing local user ${username}: $($_.Exception.Message)" "ERROR"
        }
    }
    Pause-Screen
}

# =============================================================================
# 4. Enable / Disable user
# =============================================================================
function Toggle-UserState {
    Show-Header "ENABLE / DISABLE USER"
    Show-ADMode

    Write-Host "  Username: " -NoNewline -ForegroundColor Cyan
    $username = Read-Host
    Write-Host "  [1] Enable  [2] Disable: " -NoNewline -ForegroundColor Cyan
    $action = Read-Host

    if (Get-ADMode) {
        try {
            Import-Module ActiveDirectory -ErrorAction Stop
            if ($action -eq "1") { Enable-ADAccount -Identity $username;  Write-Host "  [OK] Enabled." -ForegroundColor Green; Write-Log "AD user enabled: $username" "INFO" }
            else                 { Disable-ADAccount -Identity $username; Write-Host "  [OK] Disabled." -ForegroundColor Yellow; Write-Log "AD user disabled: $username" "WARN" }
        } catch {
            Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
            Write-Log "Error changing AD user state ${username}: $($_.Exception.Message)" "ERROR"
        }
    } else {
        try {
            if ($action -eq "1") { Enable-LocalUser -Name $username;  Write-Host "  [OK] Enabled." -ForegroundColor Green }
            else                 { Disable-LocalUser -Name $username; Write-Host "  [OK] Disabled." -ForegroundColor Yellow }
            Write-Log "Local user $(if ($action -eq '1') {'enabled'} else {'disabled'}): $username" "INFO"
        } catch {
            Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
            Write-Log "Error changing local user state ${username}: $($_.Exception.Message)" "ERROR"
        }
    }
    Pause-Screen
}

# =============================================================================
# 5. List groups
# =============================================================================
function Show-Groups {
    Show-Header "GROUP LIST"
    Show-ADMode

    if (Get-ADMode) {
        try {
            Import-Module ActiveDirectory -ErrorAction Stop
            Get-ADGroup -Filter * | Select-Object Name, GroupCategory, GroupScope, DistinguishedName |
                Sort-Object Name | Format-Table -AutoSize
        } catch {
            Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        }
    } else {
        Get-LocalGroup | Select-Object Name, Description | Sort-Object Name | Format-Table -AutoSize
    }
    Write-Log "Groups queried." "INFO"
    Pause-Screen
}

# =============================================================================
# 6. Create group
# =============================================================================
function New-GroupInteractive {
    Show-Header "CREATE GROUP"
    Show-ADMode

    Write-Host "  Group name: " -NoNewline -ForegroundColor Cyan
    $groupName = Read-Host
    Write-Host "  Description: " -NoNewline -ForegroundColor Cyan
    $desc = Read-Host

    if (Get-ADMode) {
        try {
            Import-Module ActiveDirectory -ErrorAction Stop
            New-ADGroup -Name $groupName -GroupScope Global -Description $desc
            Write-Host "  [OK] AD group created: $groupName" -ForegroundColor Green
            Write-Log "AD group created: $groupName" "INFO"
        } catch {
            Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
            Write-Log "Error creating AD group ${groupName}: $($_.Exception.Message)" "ERROR"
        }
    } else {
        try {
            New-LocalGroup -Name $groupName -Description $desc
            Write-Host "  [OK] Local group created: $groupName" -ForegroundColor Green
            Write-Log "Local group created: $groupName" "INFO"
        } catch {
            Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        }
    }
    Pause-Screen
}

# =============================================================================
# 7. Add user to group
# =============================================================================
function Add-UserToGroupInteractive {
    Show-Header "ADD USER TO GROUP"
    Show-ADMode

    Write-Host "  Username: " -NoNewline -ForegroundColor Cyan
    $username = Read-Host
    Write-Host "  Group name: " -NoNewline -ForegroundColor Cyan
    $groupName = Read-Host

    if (Get-ADMode) {
        try {
            Import-Module ActiveDirectory -ErrorAction Stop
            Add-ADGroupMember -Identity $groupName -Members $username
            Write-Host "  [OK] $username added to group $groupName" -ForegroundColor Green
            Write-Log "AD: $username added to group $groupName" "INFO"
        } catch {
            Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
            Write-Log "Error adding $username to AD group ${groupName}: $($_.Exception.Message)" "ERROR"
        }
    } else {
        try {
            Add-LocalGroupMember -Group $groupName -Member $username
            Write-Host "  [OK] $username added to group $groupName" -ForegroundColor Green
            Write-Log "Local: $username added to group $groupName" "INFO"
        } catch {
            Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        }
    }
    Pause-Screen
}

# =============================================================================
# 8. User audit report
# =============================================================================
function Export-UsersReport {
    Show-Header "GENERATE USER REPORT"
    $reportPath = Get-ReportPath "Users"

    $lines = @()
    $lines += "=" * 60
    $lines += "USER & GROUP REPORT"
    $lines += "Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    $lines += "Server: $env:COMPUTERNAME"
    $lines += "Modo: $(if (Get-ADMode) { 'Active Directory' } else { 'Local' })"
    $lines += "=" * 60
    $lines += ""

    if (Get-ADMode) {
        try {
            Import-Module ActiveDirectory -ErrorAction Stop
            $lines += "AD USERS"
            $users = Get-ADUser -Filter * -Properties DisplayName, Enabled, LastLogonDate
            $lines += ($users | Select-Object SamAccountName, DisplayName, Enabled,
                @{N="LastLogin"; E={ if ($_.LastLogonDate) { $_.LastLogonDate.ToString("yyyy-MM-dd") } else { "Never" } }} |
                Format-Table -AutoSize | Out-String)

            $lines += "AD GROUPS"
            $lines += (Get-ADGroup -Filter * | Select-Object Name, GroupScope | Format-Table -AutoSize | Out-String)

            $lines += "DISABLED USERS"
            $disabled = $users | Where-Object { -not $_.Enabled }
            $lines += "  Total: $($disabled.Count)"
            $lines += ($disabled | Select-Object SamAccountName, DisplayName | Format-Table -AutoSize | Out-String)
        } catch {
            $lines += "Error accessing AD: $($_.Exception.Message)"
        }
    } else {
        $lines += "LOCAL USERS"
        $lines += (Get-LocalUser | Select-Object Name, Enabled, LastLogon, Description | Format-Table -AutoSize | Out-String)
        $lines += "LOCAL GROUPS"
        $lines += (Get-LocalGroup | Select-Object Name, Description | Format-Table -AutoSize | Out-String)
    }

    $lines | Set-Content -Path $reportPath -Encoding UTF8
    Write-Host "  [OK] Report saved to: $reportPath" -ForegroundColor Green
    Write-Log "User report generated: $reportPath" "INFO"
    Pause-Screen
}

# =============================================================================
# MODULE MENU
# =============================================================================
function Show-UsersMenu {
    do {
Show-Header "USERS & GROUPS MANAGEMENT"
        Write-Host "   USERS" -ForegroundColor DarkCyan
        Write-Host "   [1]  List users" -ForegroundColor White
        Write-Host "   [2]  Create user" -ForegroundColor White
        Write-Host "   [3]  Remove user" -ForegroundColor White
        Write-Host "   [4]  Enable / Disable user" -ForegroundColor White
        Write-Host ""
        Write-Host "   GROUPS" -ForegroundColor DarkCyan
        Write-Host "   [5]  List groups" -ForegroundColor White
        Write-Host "   [6]  Create group" -ForegroundColor White
        Write-Host "   [7]  Add user to group" -ForegroundColor White
        Write-Host ""
        Write-Host "  ------------------------------------------------------------" -ForegroundColor DarkGray
        Write-Host "   [8]  Generate report" -ForegroundColor DarkYellow
        Write-Host "   [0]  Back to main menu" -ForegroundColor DarkGray
        Write-Host ""

        $choice = Read-Host "  Option"
        switch ($choice) {
            "1" { Show-Users }
            "2" { New-UserInteractive }
            "3" { Remove-UserInteractive }
            "4" { Toggle-UserState }
            "5" { Show-Groups }
            "6" { New-GroupInteractive }
            "7" { Add-UserToGroupInteractive }
            "8" { Export-UsersReport }
            "0" { return }
            default { Write-Host "  Invalid option." -ForegroundColor Red; Start-Sleep 1 }
        }
    } while ($true)
}

Show-UsersMenu
