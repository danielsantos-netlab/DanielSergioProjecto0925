# =============================================================================
# Modules/3_Resources.ps1 - Resource Monitoring
# CPU | RAM | Disk | Network
# =============================================================================

. "$Global:ProjectRoot\Config.ps1"

# =============================================================================
# HELPER: Get current resource snapshot
# =============================================================================
function Get-ResourceSnapshot {
    # CPU - average load over 1 second sample
    $cpu = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average

    # RAM
    $os  = Get-CimInstance Win32_OperatingSystem
    $ramTotalGB  = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2)
    $ramFreeGB   = [math]::Round($os.FreePhysicalMemory / 1MB, 2)
    $ramUsedGB   = [math]::Round($ramTotalGB - $ramFreeGB, 2)
    $ramPct      = [math]::Round(($ramUsedGB / $ramTotalGB) * 100, 1)

    # Disks
    $disks = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | Select-Object `
        DeviceID,
        @{N="Total_GB"; E={ [math]::Round($_.Size / 1GB, 2) }},
        @{N="Free_GB";  E={ [math]::Round($_.FreeSpace / 1GB, 2) }},
        @{N="Used_GB";  E={ [math]::Round(($_.Size - $_.FreeSpace) / 1GB, 2) }},
        @{N="Used_Pct"; E={ [math]::Round((($_.Size - $_.FreeSpace) / $_.Size) * 100, 1) }}

    # Network adapters (active ones)
    $netAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" } | Select-Object `
        Name,
        @{N="Speed_Mbps"; E={ [math]::Round($_.LinkSpeed / 1MB, 0) }},
        MacAddress,
        InterfaceDescription

    return [PSCustomObject]@{
        CPU_Pct     = $cpu
        RAM_Total   = $ramTotalGB
        RAM_Used    = $ramUsedGB
        RAM_Free    = $ramFreeGB
        RAM_Pct     = $ramPct
        Disks       = $disks
        NetAdapters = $netAdapters
        Timestamp   = Get-Date
    }
}

# =============================================================================
# 1. Display current resource usage
# =============================================================================
function Show-ResourceStatus {
    Show-Header "CURRENT STATUS OF RESOURCES"

    $snap = Get-ResourceSnapshot

    # CPU
    $cpuColor = if ($snap.CPU_Pct -ge $Global:ThresholdCPU) { "Red" } elseif ($snap.CPU_Pct -ge 60) { "Yellow" } else { "Green" }
    Write-Host "  CPU:" -ForegroundColor White -NoNewline
    Write-Host "  $($snap.CPU_Pct)%" -ForegroundColor $cpuColor

    # RAM
    $ramColor = if ($snap.RAM_Pct -ge $Global:ThresholdRAM) { "Red" } elseif ($snap.RAM_Pct -ge 60) { "Yellow" } else { "Green" }
    Write-Host "  RAM:" -ForegroundColor White -NoNewline
    Write-Host "  $($snap.RAM_Used) GB / $($snap.RAM_Total) GB  ($($snap.RAM_Pct)%)" -ForegroundColor $ramColor

    # Disk
    Write-Host ""
    Write-Host "  DISC:" -ForegroundColor White
    foreach ($disk in $snap.Disks) {
        $dColor = if ($disk.Used_Pct -ge $Global:ThresholdDisk) { "Red" } elseif ($disk.Used_Pct -ge 70) { "Yellow" } else { "Green" }
        Write-Host ("  {0,-5} {1,6} GB free from {2,6} GB  ({3}%)" -f `
            $disk.DeviceID, $disk.Free_GB, $disk.Total_GB, $disk.Used_Pct) -ForegroundColor $dColor
    }

    # Network
    Write-Host ""
    Write-Host "  ACTIVE NETWORK ADAPTERS:" -ForegroundColor White
    foreach ($nic in $snap.NetAdapters) {
        Write-Host "  $($nic.Name)  |  $($nic.Speed_Mbps) Mbps  |  $($nic.MacAddress)" -ForegroundColor Cyan
    }

    Write-Log "Feature snapshot: CPU=$($snap.CPU_Pct)% RAM=$($snap.RAM_Pct)%" "INFO"
    Pause-Screen
}

# =============================================================================
# 2. Check alerts (compare against thresholds)
# =============================================================================
function Check-ResourceAlerts {
    Show-Header "ALERT VERIFICATION"
    $snap = Get-ResourceSnapshot
    $alerts = 0

    if ($snap.CPU_Pct -ge $Global:ThresholdCPU) {
        Write-Host "  [ALERT] CPU: $($snap.CPU_Pct)% (limit: $Global:ThresholdCPU%)" -ForegroundColor Magenta
        Write-Log "ALERT CPU: $($snap.CPU_Pct)%" "ALERT"
        $alerts++
    }

    if ($snap.RAM_Pct -ge $Global:ThresholdRAM) {
        Write-Host "  [ALERT] RAM: $($snap.RAM_Pct)% (limit: $Global:ThresholdRAM%)" -ForegroundColor Magenta
        Write-Log "ALERT RAM: $($snap.RAM_Pct)%" "ALERT"
        $alerts++
    }

    foreach ($disk in $snap.Disks) {
        if ($disk.Used_Pct -ge $Global:ThresholdDisk) {
            Write-Host "  [ALERT] Disco $($disk.DeviceID): $($disk.Used_Pct)% usado (limit: $Global:ThresholdDisk%)" -ForegroundColor Magenta
            Write-Log "ALERT DISCO $($disk.DeviceID): $($disk.Used_Pct)%" "ALERT"
            $alerts++
        }
    }

    if ($alerts -eq 0) {
        Write-Host "  All resources within normal limits.." -ForegroundColor Green
        Write-Log "Alert verification: no issues found." "INFO"
    } else {
        Write-Host "`n  Total alerts: $alerts" -ForegroundColor Yellow
    }
    Pause-Screen
}

# =============================================================================
# 3. Continuous monitoring (live, updates every N seconds)
# =============================================================================
function Start-LiveMonitoring {
    Show-Header "REAL-TIME MONITORING"
    Write-Host ""

    $interval = 5  # seconds

    try {
        while ($true) {
            $snap = Get-ResourceSnapshot

            $line = "[{0}]  CPU: {1,3}%  |  RAM: {2,5} GB ({3,4}%)  |  Disk C: {4}%" -f `
                $snap.Timestamp.ToString("HH:mm:ss"),
                $snap.CPU_Pct,
                $snap.RAM_Used,
                $snap.RAM_Pct,
                ($snap.Disks | Where-Object { $_.DeviceID -eq "C:" } | Select-Object -First 1).Used_Pct

            $color = "Cyan"
            if ($snap.CPU_Pct -ge $Global:ThresholdCPU -or $snap.RAM_Pct -ge $Global:ThresholdRAM) {
                $color = "Magenta"
                Write-Log "Alert during live monitoring: CPU=$($snap.CPU_Pct)% RAM=$($snap.RAM_Pct)%" "ALERT"
            }

            Write-Host $line -ForegroundColor $color
            Start-Sleep -Seconds $interval
        }
    } catch {
        Write-Host "`n  Monitoring completed.." -ForegroundColor DarkGray
    }
    Pause-Screen
}

# =============================================================================
# 4. Record performance history (append to CSV)
# =============================================================================
function Record-PerformanceHistory {
    $histFile = Join-Path $Global:LogDir "resource_history.csv"

    # Write header if file doesn't exist
    if (-not (Test-Path $histFile)) {
        "Timestamp,CPU_Pct,RAM_Pct,RAM_Used_GB,RAM_Total_GB,DiskC_Pct" | Set-Content $histFile
    }

    $snap = Get-ResourceSnapshot
    $diskC = ($snap.Disks | Where-Object { $_.DeviceID -eq "C:" } | Select-Object -First 1).Used_Pct

    "$($snap.Timestamp.ToString('yyyy-MM-dd HH:mm:ss')),$($snap.CPU_Pct),$($snap.RAM_Pct),$($snap.RAM_Used),$($snap.RAM_Total),$diskC" |
        Add-Content $histFile

    Write-Log "Recorded performance history." "INFO"
    return $histFile
}

function Show-PerformanceHistory {
    Show-Header "PERFORMANCE HISTORY"

    $histFile = Join-Path $Global:LogDir "resource_history.csv"

    if (-not (Test-Path $histFile)) {
        Write-Host "  No history found. Run the periodic registration option first." -ForegroundColor DarkGray
        Pause-Screen
        return
    }

    $data = Import-Csv $histFile | Select-Object -Last 20
    Write-Host "  Last 20 entries recorded:" -ForegroundColor Cyan
    $data | Format-Table -AutoSize
    Pause-Screen
}

# =============================================================================
# 5. Scheduled recording (runs in background for N minutes)
# =============================================================================
function Start-ScheduledRecording {
    Show-Header "PERIODIC REGISTRATION OF RESOURCES"

    Write-Host "  For how many minutes do you intend to record? (ex: 10): " -NoNewline -ForegroundColor Cyan
    $mins = Read-Host
    if ($mins -notmatch '^\d+$') { Write-Host "  Invalid value." -ForegroundColor Red; Pause-Screen; return }

    Write-Host "  What is the interval between records in seconds? (ex: 30): " -NoNewline -ForegroundColor Cyan
    $secs = Read-Host
    if ($secs -notmatch '^\d+$') { Write-Host "  Invalid value." -ForegroundColor Red; Pause-Screen; return }

    $totalSecs  = [int]$mins * 60
    $interval   = [int]$secs
    $elapsed    = 0
    $count      = 0

    Write-Host "`n  Logging by $mins minutes (interval: ${secs}s)..." -ForegroundColor Green
    Write-Host "  Press CTRL+C to stop prematurely.." -ForegroundColor DarkGray
    Write-Host ""

    try {
        while ($elapsed -lt $totalSecs) {
            $histFile = Record-PerformanceHistory
            $count++
            Write-Host "  [$count] $(Get-Date -Format 'HH:mm:ss') registered." -ForegroundColor DarkGray
            Start-Sleep -Seconds $interval
            $elapsed += $interval
        }
    } catch {}

    Write-Host "`n  Registration complete. $count entries saved in: $histFile" -ForegroundColor Green
    Write-Log "Periodic registration completed: $count entries." "INFO"
    Pause-Screen
}

# =============================================================================
# 6. Generate report
# =============================================================================
function Export-ResourceReport {
    Show-Header "GENERATE RESOURCES REPORT"

    $reportPath = Get-ReportPath "Resources"
    $snap = Get-ResourceSnapshot

    $lines = @()
    $lines += "=" * 60
    $lines += "SYSTEM RESOURCES REPORT"
    $lines += "Data: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    $lines += "Server: $env:COMPUTERNAME"
    $lines += "=" * 60
    $lines += ""
    $lines += "CPU"
    $lines += "  Use: $($snap.CPU_Pct)%  (Alert limit: $Global:ThresholdCPU%)"
    $lines += ""
    $lines += "MEMORIA RAM"
    $lines += "  Total : $($snap.RAM_Total) GB"
    $lines += "  Used : $($snap.RAM_Used) GB ($($snap.RAM_Pct)%)"
    $lines += "  Free : $($snap.RAM_Free) GB"
    $lines += "  Alert limit: $Global:ThresholdRAM%"
    $lines += ""
    $lines += "DISCOS"
    foreach ($disk in $snap.Disks) {
        $lines += "  $($disk.DeviceID)  Total: $($disk.Total_GB) GB  |  Used: $($disk.Used_GB) GB ($($disk.Used_Pct)%)  |  Livre: $($disk.Free_GB) GB"
    }
    $lines += ""
    $lines += "ACTIVE NETWORK ADAPTERS"
    foreach ($nic in $snap.NetAdapters) {
        $lines += "  $($nic.Name)  |  $($nic.Speed_Mbps) Mbps  |  $($nic.MacAddress)"
    }

    # Add history summary if available
    $histFile = Join-Path $Global:LogDir "resource_history.csv"
    if (Test-Path $histFile) {
        $hist = Import-Csv $histFile
        $lines += ""
        $lines += "HISTORY (last 10 entries)"
        $lines += ($hist | Select-Object -Last 10 | Format-Table -AutoSize | Out-String)
    }

    $lines | Set-Content -Path $reportPath -Encoding UTF8
    Write-Host "  [OK] Report saved in: $reportPath" -ForegroundColor Green
    Write-Log "Resource report generated: $reportPath" "INFO"
    Pause-Screen
}

# =============================================================================
# 7. Edit alert thresholds interactively
# =============================================================================
function Set-Thresholds {
    Show-Header "SETTING UP ALERT LIMITS"

    Write-Host "  Current CPU limit : $Global:ThresholdCPU%  - New value (Enter to keep): " -NoNewline
    $v = Read-Host
    if ($v -match '^\d+$') { $Global:ThresholdCPU = [int]$v }

    Write-Host "  Current RAM limit : $Global:ThresholdRAM%  - New value (Enter to keep): " -NoNewline
    $v = Read-Host
    if ($v -match '^\d+$') { $Global:ThresholdRAM = [int]$v }

    Write-Host "  Current Disk Limit: $Global:ThresholdDisk%  - New value (Enter to keep): " -NoNewline
    $v = Read-Host
    if ($v -match '^\d+$') { $Global:ThresholdDisk = [int]$v }

    Write-Host "`n  Updated limits: CPU=$Global:ThresholdCPU% | RAM=$Global:ThresholdRAM% | Disco=$Global:ThresholdDisk%" -ForegroundColor Green
    Write-Log "Updated limits: CPU=$Global:ThresholdCPU% RAM=$Global:ThresholdRAM% Disco=$Global:ThresholdDisk%" "INFO"
    Pause-Screen
}

# =============================================================================
# MODULE MENU
# =============================================================================
function Show-ResourceMenu {
    do {
        Show-Header "RESOURCE MONITORING"
        Write-Host "   STATUS" -ForegroundColor DarkCyan
        Write-Host "   [1]  Current status (CPU / RAM / Disk / Network)" -ForegroundColor White
        Write-Host "   [2]  Check alerts" -ForegroundColor White
        Write-Host "   [3]  Real-time monitoring (live)" -ForegroundColor White
        Write-Host ""
        Write-Host "   HISTORY" -ForegroundColor DarkCyan
        Write-Host "   [4]  View performance history" -ForegroundColor White
        Write-Host "   [5]  Start periodic recording" -ForegroundColor White
        Write-Host ""
        Write-Host "   SETTINGS" -ForegroundColor DarkCyan
        Write-Host "   [7]  Configure alert thresholds" -ForegroundColor White
        Write-Host ""
        Write-Host "  ------------------------------------------------------------" -ForegroundColor DarkGray
        Write-Host "   [6]  Generate report" -ForegroundColor DarkYellow
        Write-Host "   [0]  Back to main menu" -ForegroundColor DarkGray
        Write-Host ""

        $choice = Read-Host "  Opcao"
        switch ($choice) {
            "1" { Show-ResourceStatus }
            "2" { Check-ResourceAlerts }
            "3" { Start-LiveMonitoring }
            "4" { Show-PerformanceHistory }
            "5" { Start-ScheduledRecording }
            "6" { Export-ResourceReport }
            "7" { Set-Thresholds }
            "0" { return }
            default { Write-Host "  Invalid option." -ForegroundColor Red; Start-Sleep 1 }
        }
    } while ($true)
}

Show-ResourceMenu
