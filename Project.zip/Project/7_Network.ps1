# =============================================================================
# Modules/7_Network.ps1 - Network Management and Monitoring
# Traffic | Open ports | Connectivity | Applications | DNS | ARP
# =============================================================================

. "$Global:ProjectRoot\Config.ps1"

# =============================================================================
# 1. Network adapter status and IP info
# =============================================================================
function Show-NetworkAdapters {
    Show-Header "NETWORK ADAPTERS"

    Get-NetAdapter | ForEach-Object {
        $adapter = $_
        $ips = Get-NetIPAddress -InterfaceIndex $adapter.ifIndex -ErrorAction SilentlyContinue
        $gw  = (Get-NetRoute -InterfaceIndex $adapter.ifIndex -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue | Select-Object -First 1).NextHop

        $color = if ($adapter.Status -eq "Up") { "Green" } else { "DarkGray" }
        Write-Host "  $($adapter.Name)  [$($adapter.Status)]  $($adapter.InterfaceDescription)" -ForegroundColor $color
        Write-Host "    MAC   : $($adapter.MacAddress)" -ForegroundColor DarkGray
        Write-Host "    Speed : $([math]::Round($adapter.LinkSpeed/1MB,0)) Mbps" -ForegroundColor DarkGray
        foreach ($ip in $ips) {
            Write-Host "    IP    : $($ip.IPAddress)/$($ip.PrefixLength)  ($($ip.AddressFamily))" -ForegroundColor DarkGray
        }
        if ($gw) { Write-Host "    GW    : $gw" -ForegroundColor DarkGray }
        Write-Host ""
    }

    Write-Log "Network adapters checked." "INFO"
    Pause-Screen
}

# =============================================================================
# 2. Open ports and active connections (netstat equivalent)
# =============================================================================
function Show-NetConnections {
    Show-Header "CONNECTIONS AND PORTS (NETSTAT)"

    Write-Host "  [1] Ports in listen  [2] Established connections  [3] All: " -NoNewline -ForegroundColor Cyan
    $filter = Read-Host

    $states = switch ($filter) {
        "1" { @("Listen") }
        "2" { @("Established") }
        default { @("Listen","Established","TimeWait","CloseWait") }
    }

    $conns = Get-NetTCPConnection -ErrorAction SilentlyContinue |
             Where-Object { $_.State -in $states } |
             Select-Object State, LocalAddress, LocalPort, RemoteAddress, RemotePort, OwningProcess,
                 @{N="Process"; E={ (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).Name }} |
             Sort-Object State, LocalPort

    $conns | Format-Table -AutoSize
    Write-Host "  Total: $($conns.Count) connections" -ForegroundColor DarkGray
    Write-Log "Network connections checked." "INFO"
    Pause-Screen
}

# =============================================================================
# 3. Ping connectivity test
# =============================================================================
function Test-Connectivity {
    Show-Header "CONNECTIVITY TEST (PING)"

    Write-Host "  Host(s) to test (comma-separated, Enter = gateway): " -NoNewline -ForegroundColor Cyan
    $input = Read-Host

    $targets = if ([string]::IsNullOrWhiteSpace($input)) {
        # Default: gateway + common public
        $gw = (Get-NetRoute -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue | Sort-Object RouteMetric | Select-Object -First 1).NextHop
        @($gw, "8.8.8.8", "1.1.1.1") | Where-Object { $_ }
    } else {
        $input -split "," | ForEach-Object { $_.Trim() }
    }

    Write-Host ""
    foreach ($target in $targets) {
        $result = Test-Connection -ComputerName $target -Count 3 -ErrorAction SilentlyContinue
        if ($result) {
            $avg = [math]::Round(($result | Measure-Object ResponseTime -Average).Average, 1)
            Write-Host ("  {0,-20} OK   Average latency: {1} ms" -f $target, $avg) -ForegroundColor Green
            Write-Log "Ping $target OK - $avg ms" "INFO"
        } else {
            Write-Host ("  {0,-20} FAILURE  (no response)" -f $target) -ForegroundColor Red
            Write-Log "Ping $target FAILED" "WARN"
        }
    }
    Pause-Screen
}

# =============================================================================
# 4. DNS resolution test
# =============================================================================
function Test-DNSResolution {
    Show-Header "DNS RESOLUTION TEST"

    Write-Host "  Name(s) to resolve (comma-separated): " -NoNewline -ForegroundColor Cyan
    $input = Read-Host
    if ([string]::IsNullOrWhiteSpace($input)) { $input = "google.com,microsoft.com" }

    $names = $input -split "," | ForEach-Object { $_.Trim() }

    Write-Host ""
    foreach ($name in $names) {
        try {
            $result = Resolve-DnsName -Name $name -ErrorAction Stop | Select-Object -First 3
            Write-Host "  $name" -ForegroundColor Green
            $result | ForEach-Object { Write-Host "    -> $($(if ($_.IPAddress) { $_.IPAddress } else { $_.NameHost }))" -ForegroundColor DarkGray }
        } catch {
            Write-Host "  $name  ->  FAILURE in resolution" -ForegroundColor Red
            Write-Log "DNS failed for $name" "WARN"
        }
    }

    # Show current DNS servers
    Write-Host ""
    Write-Host "  DNS SERVERS CONFIGURED:" -ForegroundColor Yellow
    Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.ServerAddresses.Count -gt 0 } |
        Select-Object InterfaceAlias, ServerAddresses |
        Format-Table -AutoSize

    Write-Log "DNS resolution test completed." "INFO"
    Pause-Screen
}

# =============================================================================
# 5. ARP table and MAC addresses
# =============================================================================
function Show-ARPTable {
    Show-Header "ARP TABLE (MAC ADDRESSES ON THE NETWORK)"

    $arp = Get-NetNeighbor -ErrorAction SilentlyContinue |
           Where-Object { $_.State -ne "Unreachable" -and $_.LinkLayerAddress -ne "00-00-00-00-00-00" } |
           Select-Object IPAddress, LinkLayerAddress, State, InterfaceAlias |
           Sort-Object InterfaceAlias, IPAddress

    $arp | Format-Table -AutoSize
    Write-Host "  Total: $($arp.Count) entries" -ForegroundColor DarkGray
    Write-Log "ARP table checked: $($arp.Count) entries." "INFO"
    Pause-Screen
}

# =============================================================================
# 6. Running applications using network
# =============================================================================
function Show-NetworkApps {
    Show-Header "APPLICATIONS USING THE NETWORK"

    $apps = Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue |
            Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, OwningProcess,
                @{N="Application"; E={ (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).Name }} |
            Where-Object { $_.Application } |
            Group-Object Application |
            Select-Object Name, Count,
                @{N="RemotePorts"; E={ ($_.Group.RemotePort | Sort-Object -Unique) -join "," }} |
            Sort-Object Count -Descending

    $apps | Format-Table -AutoSize
    Write-Log "Applications using the network checked." "INFO"
    Pause-Screen
}

# =============================================================================
# 7. Network route table
# =============================================================================
function Show-RouteTable {
    Show-Header "ROUTE TABLE"

    Get-NetRoute -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Select-Object DestinationPrefix, NextHop, RouteMetric, InterfaceAlias |
        Sort-Object RouteMetric |
        Format-Table -AutoSize

    Write-Log "Route table checked." "INFO"
    Pause-Screen
}

# =============================================================================
# 8. Generate network report
# =============================================================================
function Export-NetworkReport {
    Show-Header "GENERATE NETWORK REPORT"
    $reportPath = Get-ReportPath "Network"

    $lines = @()
    $lines += "=" * 60
    $lines += "NETWORK REPORT"
    $lines += "Data: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    $lines += "Server: $env:COMPUTERNAME"
    $lines += "=" * 60
    $lines += ""
    $lines += "ADAPTERS"
    $lines += (Get-NetAdapter | Select-Object Name, Status, MacAddress, @{N="Speed_Mbps"; E={ [math]::Round($_.LinkSpeed/1MB,0) }} | Format-Table -AutoSize | Out-String)
    $lines += "Configured IPs"
    $lines += (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object InterfaceAlias, IPAddress, PrefixLength | Format-Table -AutoSize | Out-String)
    $lines += "PORTS IN LISTEN"
    $lines += (Get-NetTCPConnection -State Listen | Select-Object LocalPort, OwningProcess, @{N="Proc"; E={ (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).Name }} | Sort-Object LocalPort | Format-Table -AutoSize | Out-String)
    $lines += "DNS SERVERS"
    $lines += (Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.ServerAddresses.Count -gt 0 } | Select-Object InterfaceAlias, ServerAddresses | Format-Table -AutoSize | Out-String)
    $lines += "ROUTES"
    $lines += (Get-NetRoute -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object DestinationPrefix, NextHop, RouteMetric | Sort-Object RouteMetric | Format-Table -AutoSize | Out-String)

    $lines | Set-Content -Path $reportPath -Encoding UTF8
    Write-Host "  [OK] Report generated at: $reportPath" -ForegroundColor Green
    Write-Log "Network report generated: $reportPath" "INFO"
    Pause-Screen
}

# =============================================================================
# MODULE MENU
# =============================================================================
function Show-NetworkMenu {
    do {
        Show-Header "NETWORK MANAGEMENT"
        Write-Host "   INFO" -ForegroundColor DarkCyan
        Write-Host "   [1]  Network adapters & IPs" -ForegroundColor White
        Write-Host "   [5]  ARP table (MACs on network)" -ForegroundColor White
        Write-Host "   [7]  Routing table" -ForegroundColor White
        Write-Host ""
        Write-Host "   DIAGNOSTICS" -ForegroundColor DarkCyan
        Write-Host "   [2]  Active connections & ports (netstat)" -ForegroundColor White
        Write-Host "   [3]  Connectivity test (ping)" -ForegroundColor White
        Write-Host "   [4]  DNS resolution test" -ForegroundColor White
        Write-Host "   [6]  Applications using network" -ForegroundColor White
        Write-Host ""
        Write-Host "  ------------------------------------------------------------" -ForegroundColor DarkGray
        Write-Host "   [8]  Generate report" -ForegroundColor DarkYellow
        Write-Host "   [0]  Back to main menu" -ForegroundColor DarkGray
        Write-Host ""

        $choice = Read-Host "  Option"
        switch ($choice) {
            "1" { Show-NetworkAdapters }
            "2" { Show-NetConnections }
            "3" { Test-Connectivity }
            "4" { Test-DNSResolution }
            "5" { Show-ARPTable }
            "6" { Show-NetworkApps }
            "7" { Show-RouteTable }
            "8" { Export-NetworkReport }
            "0" { return }
            default { Write-Host "  Invalid option." -ForegroundColor Red; Start-Sleep 1 }
        }
    } while ($true)
}

Show-NetworkMenu
