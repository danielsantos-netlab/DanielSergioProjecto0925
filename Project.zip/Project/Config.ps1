# =============================================================================
# Config.ps1 - Shared helpers and thresholds
# NOTE: All paths ($Global:ProjectRoot, ModuleDir, LogDir, etc.)
#       are set by MainMenu.ps1 BEFORE this file is dot-sourced.
#       This file must NEVER overwrite them.
# =============================================================================

# --- Safety fallback only (should never be needed) ---
if (-not $Global:ProjectRoot) { $Global:ProjectRoot = "C:\Project" }
if (-not $Global:ModuleDir)   { $Global:ModuleDir   = $Global:ProjectRoot }
if (-not $Global:LogDir)      { $Global:LogDir       = Join-Path $Global:ProjectRoot "Logs" }
if (-not $Global:ReportDir)   { $Global:ReportDir    = Join-Path $Global:ProjectRoot "Reports" }
if (-not $Global:BackupDir)   { $Global:BackupDir    = Join-Path $Global:ProjectRoot "Backups" }
if (-not $Global:LogFile)     { $Global:LogFile      = Join-Path $Global:LogDir ("sysadmin_" + (Get-Date -Format "yyyy-MM-dd") + ".log") }

# --- Ensure directories exist ---
foreach ($dir in @($Global:LogDir, $Global:ReportDir, $Global:BackupDir)) {
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
}

# --- Thresholds (only set if not already defined) ---
if (-not $Global:ThresholdCPU)    { $Global:ThresholdCPU    = 85 }
if (-not $Global:ThresholdRAM)    { $Global:ThresholdRAM    = 80 }
if (-not $Global:ThresholdDisk)   { $Global:ThresholdDisk   = 90 }
if (-not $Global:TopProcessCount) { $Global:TopProcessCount = 10 }

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO","WARN","ERROR","ALERT")][string]$Level = "INFO"
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $entry = "[$timestamp][$Level] $Message"
    try { Add-Content -Path $Global:LogFile -Value $entry -ErrorAction SilentlyContinue } catch {}

    switch ($Level) {
        "INFO"  { Write-Host $entry -ForegroundColor Cyan }
        "WARN"  { Write-Host $entry -ForegroundColor Yellow }
        "ERROR" { Write-Host $entry -ForegroundColor Red }
        "ALERT" { Write-Host $entry -ForegroundColor Magenta }
    }
}

function Show-Header {
    param([string]$Title)
    Clear-Host
    Write-Host ("=" * 60) -ForegroundColor DarkCyan
    Write-Host "  $Title" -ForegroundColor Cyan
    Write-Host "  $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor DarkGray
    Write-Host ("=" * 60) -ForegroundColor DarkCyan
    Write-Host ""
}

function Pause-Screen {
    Write-Host ""
    Write-Host "  Press any key to return to the menu...." -ForegroundColor DarkGray
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

function Get-ReportPath {
    param([string]$ModuleName)
    $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm"
    return Join-Path $Global:ReportDir ("${ModuleName}_${timestamp}.txt")
}
