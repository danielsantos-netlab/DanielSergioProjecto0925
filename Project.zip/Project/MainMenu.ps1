# =============================================================================
# MainMenu.ps1 - Main Launcher
# Automated System Administration & Monitoring Infrastructure
# Run as Administrator on Windows Server 2025
# =============================================================================

#Requires -RunAsAdministrator

# --- Determine project root robustly (works from any launch method) ---
if ($PSScriptRoot -and (Test-Path $PSScriptRoot)) {
    $Global:ProjectRoot = $PSScriptRoot
} elseif ($MyInvocation.MyCommand.Path) {
    $Global:ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
} else {
    $Global:ProjectRoot = (Get-Location).Path
}

# --- Define all paths here, once, globally ---
$Global:ModuleDir  = $Global:ProjectRoot
$Global:LogDir     = Join-Path $Global:ProjectRoot "Logs"
$Global:ReportDir  = Join-Path $Global:ProjectRoot "Reports"
$Global:BackupDir  = Join-Path $Global:ProjectRoot "Backups"
$Global:LogFile    = Join-Path $Global:LogDir ("sysadmin_" + (Get-Date -Format "yyyy-MM-dd") + ".log")

# --- Thresholds ---
$Global:ThresholdCPU    = 85
$Global:ThresholdRAM    = 80
$Global:ThresholdDisk   = 90
$Global:TopProcessCount = 10

# --- Load Setup and run if first time ---
. "$Global:ProjectRoot\Setup.ps1"
$marker = Join-Path $Global:ProjectRoot ".setup_done"
if (-not (Test-Path $marker)) {
    Run-Setup -ProjectRoot $Global:ProjectRoot
}

# --- Load shared config (helpers only, paths already set above) ---
. "$Global:ProjectRoot\Config.ps1"

# =============================================================================
# HELPER: open a module script
# =============================================================================
function Open-Module {
    param([string]$Script)
    $path = Join-Path $Global:ModuleDir $Script
    if (Test-Path $path) {
        & $path
    } else {
        Write-Host ""
        Write-Host "  [!] Module not found: $path" -ForegroundColor Yellow
        Write-Host "  Confirm that '$Script' exists in:" -ForegroundColor DarkGray
        Write-Host "  $Global:ModuleDir" -ForegroundColor DarkGray
        Pause-Screen
    }
}

function Show-MainMenu {
    Clear-Host
    Write-Host ""
    Write-Host "  ============================================================" -ForegroundColor DarkCyan
    Write-Host "   ATEC // SYSTEM_CORE_2026" -ForegroundColor Cyan
    Write-Host "   SysAdmin - Administration & Monitoring Infrastructure" -ForegroundColor DarkGray
    Write-Host "  ============================================================" -ForegroundColor DarkCyan
    Write-Host ""

    # --- Quick Status Bar (cached - refreshes every 30s) ---
    $now = Get-Date
    if (-not $Global:_statusCache -or ($now - $Global:_statusCacheTime).TotalSeconds -gt 30) {
        $cpuVal = try { (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average } catch { 0 }
        $ramVal = 0
        $diskVal = 0
        $osInfo = try { Get-CimInstance Win32_OperatingSystem } catch { $null }
        if ($osInfo) {
            $ramT = $osInfo.TotalVisibleMemorySize
            $ramF = $osInfo.FreePhysicalMemory
            $ramVal = [math]::Round((($ramT - $ramF) / $ramT) * 100, 1)
        }
        $diskC = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue
        if ($diskC) { $diskVal = [math]::Round((($diskC.Size - $diskC.FreeSpace) / $diskC.Size) * 100, 1) }
        $Global:_statusCache = @{
            cpu     = $cpuVal
            ramPct  = $ramVal
            diskPct = $diskVal
        }
        $Global:_statusCacheTime = $now
    }
    $cpu = $Global:_statusCache.cpu
    $ramPct = $Global:_statusCache.ramPct
    $diskPct = $Global:_statusCache.diskPct

    $cpuColor  = if ($cpu -ge $Global:ThresholdCPU) { "Red" } elseif ($cpu -ge 70) { "Yellow" } else { "Green" }
    $ramColor  = if ($ramPct -ge $Global:ThresholdRAM) { "Red" } elseif ($ramPct -ge 70) { "Yellow" } else { "Green" }
    $diskColor = if ($diskPct -ge $Global:ThresholdDisk) { "Red" } elseif ($diskPct -ge 70) { "Yellow" } else { "Green" }
    $adStatus  = if ($Global:ADAvailable) { "Available" } else { "Local mode" }

    Write-Host "   Server: " -NoNewline -ForegroundColor DarkGray; Write-Host "$env:COMPUTERNAME" -NoNewline -ForegroundColor White
    Write-Host "  |  User: " -NoNewline -ForegroundColor DarkGray; Write-Host "$env:USERNAME" -NoNewline -ForegroundColor White
    Write-Host "  |  AD: " -NoNewline -ForegroundColor DarkGray; Write-Host "$adStatus" -ForegroundColor $(if ($Global:ADAvailable) { "Green" } else { "DarkGray" })
    Write-Host "   CPU: " -NoNewline -ForegroundColor DarkGray; Write-Host "$($cpu)%" -NoNewline -ForegroundColor $cpuColor
    Write-Host "  |  RAM: " -NoNewline -ForegroundColor DarkGray; Write-Host "$($ramPct)%" -NoNewline -ForegroundColor $ramColor
    Write-Host "  |  Disk C: " -NoNewline -ForegroundColor DarkGray; Write-Host "$($diskPct)%" -NoNewline -ForegroundColor $diskColor
    Write-Host "  |  " -NoNewline -ForegroundColor DarkGray; Write-Host "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor DarkGray
    Write-Host "  ------------------------------------------------------------" -ForegroundColor DarkGray
    Write-Host ""

    # --- Monitoring ---
    Write-Host "   MONITORING" -ForegroundColor DarkCyan
    Write-Host "   [1]  Processes & Memory" -ForegroundColor White
    Write-Host "   [2]  Resources (CPU / RAM / Disk / Network)" -ForegroundColor White
    Write-Host ""

    # --- System ---
    Write-Host "   SYSTEM" -ForegroundColor DarkCyan
    Write-Host "   [3]  File System" -ForegroundColor White
    Write-Host "   [4]  Services & Servers" -ForegroundColor White
    Write-Host "   [5]  Users & Groups" -ForegroundColor White
    Write-Host ""

    # --- Security ---
    Write-Host "   SECURITY" -ForegroundColor DarkCyan
    Write-Host "   [6]  Security & System Analysis" -ForegroundColor White
    Write-Host ""

    # --- Infrastructure ---
    Write-Host "   INFRASTRUCTURE" -ForegroundColor DarkCyan
    Write-Host "   [7]  Network Management" -ForegroundColor White
    Write-Host "   [8]  Backup & Recovery" -ForegroundColor White
    Write-Host "   [9]  Server Configuration" -ForegroundColor White
    Write-Host "   [10] Virtualization (Hyper-V)" -ForegroundColor White
    Write-Host ""

    # --- Utilities ---
    Write-Host "  ------------------------------------------------------------" -ForegroundColor DarkGray
    Write-Host "   [L] Today's Logs   [R] Saved Reports   [S] Re-run Setup   " -NoNewline -ForegroundColor DarkYellow
    Write-Host "[Q] Quit" -ForegroundColor DarkRed
    Write-Host "  ------------------------------------------------------------" -ForegroundColor DarkGray

    # --- Last log entry ---
    if (Test-Path $Global:LogFile) {
        $lastLog = Get-Content $Global:LogFile -Tail 1 -ErrorAction SilentlyContinue
        if ($lastLog) {
            Write-Host "   Last: " -NoNewline -ForegroundColor DarkGray
            $truncated = if ($lastLog.Length -gt 55) { $lastLog.Substring(0, 55) + "..." } else { $lastLog }
            if     ($truncated -match "\[ALERT\]") { Write-Host $truncated -ForegroundColor Magenta }
            elseif ($truncated -match "\[WARN\]")  { Write-Host $truncated -ForegroundColor Yellow }
            elseif ($truncated -match "\[ERROR\]") { Write-Host $truncated -ForegroundColor Red }
            else                                   { Write-Host $truncated -ForegroundColor DarkGray }
        }
    }
    Write-Host ""
}

function Show-TodayLogs {
    Show-Header "TODAY'S LOGS"
    if (Test-Path $Global:LogFile) {
        Get-Content $Global:LogFile | Select-Object -Last 60 | ForEach-Object {
            if ($_ -match "\[ALERT\]")      { Write-Host $_ -ForegroundColor Magenta }
            elseif ($_ -match "\[WARN\]")   { Write-Host $_ -ForegroundColor Yellow }
            elseif ($_ -match "\[ERROR\]")  { Write-Host $_ -ForegroundColor Red }
            else                            { Write-Host $_ -ForegroundColor DarkGray }
        }
    } else {
        Write-Host "  No logs found for today." -ForegroundColor DarkGray
    }
    Pause-Screen
}

function Show-Reports {
    Show-Header "SAVED REPORTS"
    $reports = Get-ChildItem -Path $Global:ReportDir -Filter "*.txt" -ErrorAction SilentlyContinue |
               Sort-Object LastWriteTime -Descending | Select-Object -First 20

    if (-not $reports) {
        Write-Host "  No reports found." -ForegroundColor DarkGray
        Pause-Screen
        return
    }

    $i = 1
    foreach ($r in $reports) {
        Write-Host "  [$i] $($r.Name)  ($($r.LastWriteTime.ToString('yyyy-MM-dd HH:mm')))" -ForegroundColor White
        $i++
    }
    Write-Host ""
    Write-Host "  Report number to open (Enter to go back): " -NoNewline -ForegroundColor Cyan
    $choice = Read-Host
    if ($choice -match '^\d+$') {
        $idx = [int]$choice - 1
        if ($idx -ge 0 -and $idx -lt $reports.Count) {
            Show-Header $reports[$idx].Name
            Get-Content $reports[$idx].FullName | ForEach-Object { Write-Host $_ }
            Pause-Screen
        }
    }
}

function Repeat-Setup {
    $marker2 = Join-Path $Global:ProjectRoot ".setup_done"
    Remove-Item -Path $marker2 -Force -ErrorAction SilentlyContinue
    Run-Setup -ProjectRoot $Global:ProjectRoot
    . "$Global:ProjectRoot\Config.ps1"
}

# =============================================================================
# MAIN LOOP
# =============================================================================
Write-Log "System started by $env:USERNAME on $env:COMPUTERNAME." "INFO"

do {
    Show-MainMenu
    $choice = Read-Host "  Option"

    switch ($choice.ToUpper()) {
        "1"  { Open-Module "1_Processes.ps1" }
        "2"  { Open-Module "3_Resources.ps1" }
        "3"  { Open-Module "2_FileSystem.ps1" }
        "4"  { Open-Module "6_Services.ps1" }
        "5"  { Open-Module "5_Users.ps1" }
        "6"  { Open-Module "4_Security.ps1" }
        "7"  { Open-Module "7_Network.ps1" }
        "8"  { Open-Module "8_Backup.ps1" }
        "9"  { Open-Module "9_ServerConfig.ps1" }
        "10" { Open-Module "10_Virtualization.ps1" }
        "L"  { Show-TodayLogs }
        "R"  { Show-Reports }
        "S"  { Repeat-Setup }
        "Q"  { Write-Log "System closed by $env:USERNAME." "INFO"; Write-Host "`n  Goodbye!`n" -ForegroundColor Cyan }
        default { Write-Host "`n  Invalid option." -ForegroundColor Red; Start-Sleep -Seconds 1 }
    }
} while ($choice.ToUpper() -ne "Q")
