# =============================================================================
# Modules/4_Security.ps1 - Security & System Analysis
# Failed logins | Security logs | Open ports | Alerts
# =============================================================================

. "$Global:ProjectRoot\Config.ps1"

# =============================================================================
# 1. Failed login attempts (Event ID 4625)
# =============================================================================
function Show-FailedLogins {
    Show-Header "FAILED LOGIN ATTEMPTS"

    Write-Host "  How many recent events? (Enter = 50): " -NoNewline -ForegroundColor Cyan
    $max = Read-Host
    if ($max -notmatch '^\d+$') { $max = 50 }

    Write-Host "  Searching Event ID 4625 in Security log..." -ForegroundColor DarkGray
    Write-Host ""

    try {
        $events = Get-WinEvent -FilterHashtable @{LogName="Security"; Id=4625} -MaxEvents ([int]$max) -ErrorAction Stop

        $results = $events | ForEach-Object {
            [PSCustomObject]@{
                Time       = $_.TimeCreated.ToString("yyyy-MM-dd HH:mm:ss")
                User       = $_.Properties[5].Value
                Domain     = $_.Properties[6].Value
                Source_IP  = $_.Properties[19].Value
                Reason     = $_.Properties[8].Value
            }
        }

        if ($results) {
            $results | Format-Table -AutoSize

            # Summarize by user
            Write-Host "  --- Attempts per user ---" -ForegroundColor Yellow
            $results | Group-Object User | Sort-Object Count -Descending |
                Select-Object Count, Name | Format-Table -AutoSize

            # Alert if any user has >5 failures
            $highRisk = $results | Group-Object User | Where-Object { $_.Count -ge 5 }
            foreach ($u in $highRisk) {
                Write-Host "  [ALERT] '$($u.Name)' has $($u.Count) failed logins!" -ForegroundColor Magenta
                Write-Log "Security ALERT: '$($u.Name)' - $($u.Count) failed logins." "ALERT"
            }
        } else {
            Write-Host "  No failed login attempts recorded." -ForegroundColor Green
        }
    } catch {
        Write-Host "  Could not read the security log. Requires Administrator privileges." -ForegroundColor Yellow
        Write-Log "Error reading failed logins: $($_.Exception.Message)" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 2. Successful logins (Event ID 4624)
# =============================================================================
function Show-SuccessLogins {
    Show-Header "RECENT SUCCESSFUL LOGINS"

    try {
        $events = Get-WinEvent -FilterHashtable @{LogName="Security"; Id=4624} -MaxEvents 30 -ErrorAction Stop

        $results = $events | ForEach-Object {
            $logonType = $_.Properties[8].Value
            $typeName = switch ([int]$logonType) {
                2  { "Interactive" }
                3  { "Network" }
                4  { "Batch" }
                5  { "Service" }
                7  { "Unlock" }
                10 { "Remote (RDP)" }
                default { "Type $logonType" }
            }
            [PSCustomObject]@{
                Time        = $_.TimeCreated.ToString("yyyy-MM-dd HH:mm:ss")
                User        = $_.Properties[5].Value
                Domain      = $_.Properties[6].Value
                Type        = $typeName
                Source_IP   = $_.Properties[18].Value
            }
        } | Where-Object { $_.User -notmatch "SYSTEM|ANONYMOUS|DWM|UMFD|-$" }

        $results | Format-Table -AutoSize
        Write-Log "Successful logins queried." "INFO"
    } catch {
        Write-Host "  Could not read login events." -ForegroundColor Yellow
        Write-Log "Error reading logins: $($_.Exception.Message)" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 3. Open ports
# =============================================================================
function Show-OpenPorts {
    Show-Header "OPEN PORTS & ACTIVE CONNECTIONS"

    Write-Host "  LISTENING PORTS:" -ForegroundColor Yellow
    Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
        Select-Object LocalAddress, LocalPort, OwningProcess,
            @{N="Process"; E={ (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).Name }} |
        Sort-Object LocalPort |
        Format-Table -AutoSize

    Write-Host "  ESTABLISHED CONNECTIONS:" -ForegroundColor Yellow
    Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue |
        Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, OwningProcess,
            @{N="Process"; E={ (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).Name }} |
        Sort-Object RemoteAddress |
        Format-Table -AutoSize

    # Alert on well-known risky ports
    $riskyPorts = @(23,135,137,138,139,445,3389,4444,5900,6667)
    $open = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty LocalPort
    $found = $riskyPorts | Where-Object { $_ -in $open }
    if ($found) {
        Write-Host "  [ALERT] Risky ports detected open: $($found -join ', ')" -ForegroundColor Magenta
        Write-Log "Risky ports open: $($found -join ', ')" "ALERT"
    }

    Write-Log "Open ports queried." "INFO"
    Pause-Screen
}

# =============================================================================
# 4. Security event log analysis
# =============================================================================
function Show-SecurityLog {
    Show-Header "SECURITY LOG ANALYSIS"

    $events = @(
        @{Id=4720; Desc="User created"},
        @{Id=4722; Desc="User enabled"},
        @{Id=4725; Desc="User disabled"},
        @{Id=4726; Desc="User deleted"},
        @{Id=4728; Desc="Member added to privileged group"},
        @{Id=4732; Desc="Member added to Administrators"},
        @{Id=4740; Desc="Account locked out"},
        @{Id=4756; Desc="Member added to universal group"},
        @{Id=1102; Desc="Audit log cleared"}
    )

    foreach ($ev in $events) {
        try {
            $count = (Get-WinEvent -FilterHashtable @{LogName="Security"; Id=$ev.Id} -MaxEvents 100 -ErrorAction Stop).Count
            $color = if ($count -gt 0) { "Yellow" } else { "DarkGray" }
            Write-Host ("  [{0,4}] {1,-40} : {2} occurrence(s)" -f $ev.Id, $ev.Desc, $count) -ForegroundColor $color
            if ($count -gt 0) {
                Write-Log "Security event $($ev.Id) ($($ev.Desc)): $count occurrence(s)" "WARN"
            }
        } catch {
            Write-Host ("  [{0,4}] {1,-40} : no data" -f $ev.Id, $ev.Desc) -ForegroundColor DarkGray
        }
    }
    Pause-Screen
}

# =============================================================================
# 5. Check Windows Firewall status
# =============================================================================
function Show-FirewallStatus {
    Show-Header "FIREWALL STATUS"

    try {
        $profiles = Get-NetFirewallProfile -ErrorAction Stop
        foreach ($p in $profiles) {
            $status = if ($p.Enabled) { "ACTIVE" } else { "INACTIVE" }
            $color  = if ($p.Enabled) { "Green" } else { "Red" }
            Write-Host "  $($p.Name): $status" -ForegroundColor $color

            if (-not $p.Enabled) {
                Write-Log "FIREWALL INACTIVE on profile $($p.Name)!" "ALERT"
            }
        }

        Write-Host ""
        Write-Host "  ACTIVE INBOUND RULES (first 20):" -ForegroundColor Yellow
        Get-NetFirewallRule -Direction Inbound -Enabled True -ErrorAction SilentlyContinue |
            Select-Object DisplayName, Profile, Action |
            Select-Object -First 20 |
            Format-Table -AutoSize

        Write-Log "Firewall status queried." "INFO"
    } catch {
        Write-Host "  Could not access firewall configuration." -ForegroundColor Yellow
        Write-Log "Error reading firewall: $($_.Exception.Message)" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 6. Check for suspicious scheduled tasks
# =============================================================================
function Show-ScheduledTasksAudit {
    Show-Header "SUSPICIOUS SCHEDULED TASKS"

    $tasks = Get-ScheduledTask -ErrorAction SilentlyContinue |
             Where-Object { $_.State -eq "Ready" -or $_.State -eq "Running" } |
             ForEach-Object {
                 $action = ($_.Actions | Select-Object -First 1)
                 $exec   = if ($action.Execute) { $action.Execute } else { "N/A" }
                 [PSCustomObject]@{
                     Name       = $_.TaskName
                     Path       = $_.TaskPath
                     State      = $_.State
                     Action     = $exec
                     Suspicious = ($exec -match "\\Temp\\|powershell|cmd|wscript|cscript|mshta|regsvr32")
                 }
             }

    $suspect = $tasks | Where-Object { $_.Suspicious }
    $normal  = $tasks | Where-Object { -not $_.Suspicious }

    Write-Host "  Total active tasks: $($tasks.Count)" -ForegroundColor White
    Write-Host "  Potentially suspicious: $($suspect.Count)" -ForegroundColor $(if ($suspect.Count -gt 0) { "Magenta" } else { "Green" })
    Write-Host ""

    if ($suspect.Count -gt 0) {
        Write-Host "  --- SUSPICIOUS ---" -ForegroundColor Magenta
        $suspect | Format-Table Name, Path, Action -AutoSize
        Write-Log "Suspicious scheduled tasks: $($suspect.Count)" "ALERT"
    }

    Write-Host "  --- NORMAL (first 10) ---" -ForegroundColor DarkGray
    $normal | Select-Object -First 10 | Format-Table Name, State, Action -AutoSize

    Pause-Screen
}

# =============================================================================
# 7. Generate security report
# =============================================================================
function Export-SecurityReport {
    Show-Header "GENERATE SECURITY REPORT"
    $reportPath = Get-ReportPath "Security"

    $lines = @()
    $lines += "=" * 60
    $lines += "SYSTEM SECURITY REPORT"
    $lines += "Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    $lines += "Server: $env:COMPUTERNAME"
    $lines += "=" * 60
    $lines += ""

    # Failed logins
    $lines += "FAILED LOGINS (last 100)"
    try {
        $failed = Get-WinEvent -FilterHashtable @{LogName="Security"; Id=4625} -MaxEvents 100 -ErrorAction Stop
        $lines += "  Total: $($failed.Count)"
        $summary = $failed | ForEach-Object { $_.Properties[5].Value } | Group-Object | Sort-Object Count -Descending
        foreach ($s in $summary) { $lines += "  $($s.Name): $($s.Count) failure(s)" }
    } catch { $lines += "  Could not retrieve data." }

    $lines += ""
    $lines += "LISTENING PORTS"
    Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
        Select-Object LocalPort, OwningProcess,
            @{N="Process"; E={ (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).Name }} |
        Sort-Object LocalPort | ForEach-Object {
            $lines += "  Port $($_.LocalPort)  ->  $($_.Process)"
        }

    $lines += ""
    $lines += "FIREWALL STATUS"
    Get-NetFirewallProfile -ErrorAction SilentlyContinue | ForEach-Object {
        $lines += "  $($_.Name): $(if ($_.Enabled) { 'ACTIVE' } else { 'INACTIVE' })"
    }

    $lines | Set-Content -Path $reportPath -Encoding UTF8
    Write-Host "  [OK] Report saved to: $reportPath" -ForegroundColor Green
    Write-Log "Security report generated: $reportPath" "INFO"
    Pause-Screen
}

# =============================================================================
# MODULE MENU
# =============================================================================
function Show-SecurityMenu {
    do {
        Show-Header "SECURITY & SYSTEM ANALYSIS"
        Write-Host "   AUTHENTICATION" -ForegroundColor DarkCyan
        Write-Host "   [1]  Failed login attempts" -ForegroundColor White
        Write-Host "   [2]  Recent successful logins" -ForegroundColor White
        Write-Host ""
        Write-Host "   MONITORING" -ForegroundColor DarkCyan
        Write-Host "   [3]  Open ports & active connections" -ForegroundColor White
        Write-Host "   [4]  Security log analysis" -ForegroundColor White
        Write-Host "   [5]  Firewall status" -ForegroundColor White
        Write-Host "   [6]  Scheduled tasks audit" -ForegroundColor White
        Write-Host ""
        Write-Host "  ------------------------------------------------------------" -ForegroundColor DarkGray
        Write-Host "   [7]  Generate report" -ForegroundColor DarkYellow
        Write-Host "   [0]  Back to main menu" -ForegroundColor DarkGray
        Write-Host ""

        $choice = Read-Host "  Option"
        switch ($choice) {
            "1" { Show-FailedLogins }
            "2" { Show-SuccessLogins }
            "3" { Show-OpenPorts }
            "4" { Show-SecurityLog }
            "5" { Show-FirewallStatus }
            "6" { Show-ScheduledTasksAudit }
            "7" { Export-SecurityReport }
            "0" { return }
            default { Write-Host "  Invalid option." -ForegroundColor Red; Start-Sleep 1 }
        }
    } while ($true)
}

Show-SecurityMenu
