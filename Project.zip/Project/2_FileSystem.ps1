# =============================================================================
# Modules/2_FileSystem.ps1 - File System
# Disk usage | Permissions | Large files | Auditing
# =============================================================================

. "$Global:ProjectRoot\Config.ps1"

# =============================================================================
# 1. Disk usage analysis
# =============================================================================
function Show-DiskUsage {
    Show-Header "DISK SPACE ANALYSIS"

    $disks = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3"
    foreach ($disk in $disks) {
        $total = [math]::Round($disk.Size / 1GB, 2)
        $free  = [math]::Round($disk.FreeSpace / 1GB, 2)
        $used  = [math]::Round($total - $free, 2)
        $pct   = [math]::Round(($used / $total) * 100, 1)
        $bar   = "#" * [int]($pct / 5) + "-" * (20 - [int]($pct / 5))
        $color = if ($pct -ge $Global:ThresholdDisk) { "Red" } elseif ($pct -ge 70) { "Yellow" } else { "Green" }

        Write-Host "  $($disk.DeviceID)  [$bar] $pct%  ($used GB / $total GB  |  $free GB free)" -ForegroundColor $color
    }

    Write-Log "Disk analysis completed." "INFO"
    Pause-Screen
}

# =============================================================================
# 2. Find large files
# =============================================================================
function Find-LargeFiles {
    Show-Header "LARGE FILES"

    Write-Host "  Directory to scan (Enter = C:\): " -NoNewline -ForegroundColor Cyan
    $path = Read-Host
    if ([string]::IsNullOrWhiteSpace($path)) { $path = "C:\" }

    Write-Host "  Minimum size in MB (Enter = 100): " -NoNewline -ForegroundColor Cyan
    $minMB = Read-Host
    if ($minMB -notmatch '^\d+$') { $minMB = 100 }
    $minBytes = [int]$minMB * 1MB

    Write-Host "`n  Searching in $path (>$minMB MB)... please wait..." -ForegroundColor DarkGray

    try {
        $files = Get-ChildItem -Path $path -Recurse -File -ErrorAction SilentlyContinue |
                 Where-Object { $_.Length -gt $minBytes } |
                 Select-Object FullName,
                     @{N="Size_MB"; E={ [math]::Round($_.Length / 1MB, 1) }},
                     LastWriteTime |
                 Sort-Object Size_MB -Descending |
                 Select-Object -First 30

        if ($files) {
            $files | Format-Table -AutoSize
            Write-Log "Large file search in $path (>$minMB MB): $($files.Count) found." "INFO"
        } else {
            Write-Host "  No files found above $minMB MB." -ForegroundColor Green
        }
    } catch {
        Write-Host "  Error searching: $($_.Exception.Message)" -ForegroundColor Red
        Write-Log "Error searching for large files: $($_.Exception.Message)" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 3. Create directory automatically
# =============================================================================
function New-DirectoryAuto {
    Show-Header "CREATE DIRECTORY"

    Write-Host "  Path for the new directory: " -NoNewline -ForegroundColor Cyan
    $path = Read-Host

    if ([string]::IsNullOrWhiteSpace($path)) {
        Write-Host "  Invalid path." -ForegroundColor Red
        Pause-Screen; return
    }

    try {
        if (Test-Path $path) {
            Write-Host "  [!] Directory already exists: $path" -ForegroundColor Yellow
        } else {
            New-Item -ItemType Directory -Path $path -Force | Out-Null
            Write-Host "  [OK] Directory created: $path" -ForegroundColor Green
            Write-Log "Directory created: $path" "INFO"
        }
    } catch {
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        Write-Log "Error creating directory ${path}: $($_.Exception.Message)" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 4. Manage permissions (view, add, remove, owner, inheritance)
# =============================================================================
function Manage-Permissions {
    do {
        Show-Header "PERMISSION MANAGEMENT"
        Write-Host "  [1] View permissions" -ForegroundColor White
        Write-Host "  [2] Add permission" -ForegroundColor White
        Write-Host "  [3] Remove permission" -ForegroundColor White
        Write-Host "  [4] Change owner" -ForegroundColor White
        Write-Host "  [5] Disable inheritance (convert to explicit)" -ForegroundColor White
        Write-Host "  [6] Enable inheritance" -ForegroundColor White
        Write-Host "  [0] Back" -ForegroundColor DarkGray
        Write-Host ""
        $sub = Read-Host "  Option"

        switch ($sub) {
            "1" {
                Write-Host "  Path: " -NoNewline -ForegroundColor Cyan
                $path = Read-Host
                if (Test-Path $path) {
                    $acl = Get-Acl $path
                    Write-Host ""
                    Write-Host "  Owner: $($acl.Owner)" -ForegroundColor White
                    Write-Host "  Inheritance: $(if($acl.AreAccessRulesProtected){'Disabled'}else{'Enabled'})" -ForegroundColor DarkGray
                    Write-Host ""
                    Write-Host "  Permissions:" -ForegroundColor White
                    $i = 1
                    foreach ($rule in $acl.Access) {
                        $color = if ($rule.AccessControlType -eq 'Allow') { 'Green' } else { 'Red' }
                        Write-Host "  [$i]" -NoNewline -ForegroundColor DarkGray
                        Write-Host "  $($rule.IdentityReference)" -NoNewline -ForegroundColor White
                        Write-Host "  $($rule.AccessControlType)" -NoNewline -ForegroundColor $color
                        Write-Host "  $($rule.FileSystemRights)" -NoNewline -ForegroundColor DarkGray
                        Write-Host "  $(if($rule.IsInherited){'(inherited)'}else{'(explicit)'})" -ForegroundColor DarkGray
                        $i++
                    }
                    Write-Log "Permissions viewed: $path" "INFO"
                } else {
                    Write-Host "  Path not found." -ForegroundColor Red
                }
                Pause-Screen
            }
            "2" {
                Write-Host "  Path: " -NoNewline -ForegroundColor Cyan
                $path = Read-Host
                if (-not (Test-Path $path)) { Write-Host "  Path not found." -ForegroundColor Red; Pause-Screen; continue }

                Write-Host "  User or group (e.g. BUILTIN\Users): " -NoNewline -ForegroundColor Cyan
                $identity = Read-Host
                Write-Host "  Rights [1] Read  [2] Write  [3] Modify  [4] FullControl: " -NoNewline -ForegroundColor Cyan
                $permChoice = Read-Host
                $perm = switch ($permChoice) { "1"{"Read"} "2"{"Write"} "3"{"Modify"} "4"{"FullControl"} default{$permChoice} }
                Write-Host "  Type [1] Allow  [2] Deny: " -NoNewline -ForegroundColor Cyan
                $typeChoice = Read-Host
                $type = if ($typeChoice -eq "2") { "Deny" } else { "Allow" }

                try {
                    $acl = Get-Acl $path
                    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                        $identity, $perm, "ContainerInherit,ObjectInherit", "None", $type)
                    $acl.SetAccessRule($rule)
                    Set-Acl -Path $path -AclObject $acl
                    Write-Host "  [OK] Permission added: $identity -> $type $perm" -ForegroundColor Green
                    Write-Log "Permission added: $identity -> $type $perm on $path" "INFO"
                } catch {
                    Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
                    Write-Log "Error adding permission on ${path}: $($_.Exception.Message)" "ERROR"
                }
                Pause-Screen
            }
            "3" {
                Write-Host "  Path: " -NoNewline -ForegroundColor Cyan
                $path = Read-Host
                if (-not (Test-Path $path)) { Write-Host "  Path not found." -ForegroundColor Red; Pause-Screen; continue }

                $acl = Get-Acl $path
                $explicit = @($acl.Access | Where-Object { -not $_.IsInherited })
                if ($explicit.Count -eq 0) {
                    Write-Host "  No explicit (non-inherited) permissions to remove." -ForegroundColor Yellow
                    Pause-Screen; continue
                }

                Write-Host ""
                $i = 1
                foreach ($rule in $explicit) {
                    $color = if ($rule.AccessControlType -eq 'Allow') { 'Green' } else { 'Red' }
                    Write-Host "  [$i]" -NoNewline -ForegroundColor White
                    Write-Host "  $($rule.IdentityReference)" -NoNewline -ForegroundColor White
                    Write-Host "  $($rule.AccessControlType)" -NoNewline -ForegroundColor $color
                    Write-Host "  $($rule.FileSystemRights)" -ForegroundColor DarkGray
                    $i++
                }
                Write-Host ""
                Write-Host "  Number to remove (0 to cancel): " -NoNewline -ForegroundColor Cyan
                $sel = Read-Host
                if ($sel -eq "0" -or [string]::IsNullOrWhiteSpace($sel)) { continue }
                if ($sel -notmatch '^\d+$' -or [int]$sel -lt 1 -or [int]$sel -gt $explicit.Count) {
                    Write-Host "  Invalid selection." -ForegroundColor Red; Pause-Screen; continue
                }

                try {
                    $ruleToRemove = $explicit[[int]$sel - 1]
                    $acl.RemoveAccessRule($ruleToRemove) | Out-Null
                    Set-Acl -Path $path -AclObject $acl
                    Write-Host "  [OK] Permission removed: $($ruleToRemove.IdentityReference) $($ruleToRemove.FileSystemRights)" -ForegroundColor Green
                    Write-Log "Permission removed: $($ruleToRemove.IdentityReference) from $path" "WARN"
                } catch {
                    Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
                    Write-Log "Error removing permission on ${path}: $($_.Exception.Message)" "ERROR"
                }
                Pause-Screen
            }
            "4" {
                Write-Host "  Path: " -NoNewline -ForegroundColor Cyan
                $path = Read-Host
                if (-not (Test-Path $path)) { Write-Host "  Path not found." -ForegroundColor Red; Pause-Screen; continue }

                $acl = Get-Acl $path
                Write-Host "  Current owner: $($acl.Owner)" -ForegroundColor DarkGray
                Write-Host "  New owner (e.g. DOMAIN\User or BUILTIN\Administrators): " -NoNewline -ForegroundColor Cyan
                $newOwner = Read-Host

                try {
                    $account = New-Object System.Security.Principal.NTAccount($newOwner)
                    $acl.SetOwner($account)
                    Set-Acl -Path $path -AclObject $acl
                    Write-Host "  [OK] Owner changed to: $newOwner" -ForegroundColor Green
                    Write-Log "Owner changed on $path to $newOwner" "INFO"
                } catch {
                    Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
                    Write-Log "Error changing owner on ${path}: $($_.Exception.Message)" "ERROR"
                }
                Pause-Screen
            }
            "5" {
                Write-Host "  Path: " -NoNewline -ForegroundColor Cyan
                $path = Read-Host
                if (-not (Test-Path $path)) { Write-Host "  Path not found." -ForegroundColor Red; Pause-Screen; continue }

                try {
                    $acl = Get-Acl $path
                    $acl.SetAccessRuleProtection($true, $true)
                    Set-Acl -Path $path -AclObject $acl
                    Write-Host "  [OK] Inheritance disabled. Inherited rules converted to explicit." -ForegroundColor Green
                    Write-Log "Inheritance disabled on $path" "WARN"
                } catch {
                    Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
                    Write-Log "Error disabling inheritance on ${path}: $($_.Exception.Message)" "ERROR"
                }
                Pause-Screen
            }
            "6" {
                Write-Host "  Path: " -NoNewline -ForegroundColor Cyan
                $path = Read-Host
                if (-not (Test-Path $path)) { Write-Host "  Path not found." -ForegroundColor Red; Pause-Screen; continue }

                try {
                    $acl = Get-Acl $path
                    $acl.SetAccessRuleProtection($false, $false)
                    Set-Acl -Path $path -AclObject $acl
                    Write-Host "  [OK] Inheritance enabled." -ForegroundColor Green
                    Write-Log "Inheritance enabled on $path" "INFO"
                } catch {
                    Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
                    Write-Log "Error enabling inheritance on ${path}: $($_.Exception.Message)" "ERROR"
                }
                Pause-Screen
            }
            "0" { return }
            default { Write-Host "  Invalid option." -ForegroundColor Red; Start-Sleep 1 }
        }
    } while ($true)
}

# =============================================================================
# 5. Find suspicious files (unusual extensions in system dirs)
# =============================================================================
function Find-SuspiciousFiles {
    Show-Header "SUSPICIOUS FILES"

    $suspiciousExt = @("*.exe","*.bat","*.vbs","*.ps1","*.cmd","*.scr","*.pif")
    $suspiciousDirs = @("$env:TEMP", "$env:APPDATA\Roaming", "C:\Users\Public")

    $found = @()
    foreach ($dir in $suspiciousDirs) {
        if (Test-Path $dir) {
            foreach ($ext in $suspiciousExt) {
                $files = Get-ChildItem -Path $dir -Filter $ext -Recurse -ErrorAction SilentlyContinue |
                         Select-Object FullName,
                             @{N="Size_KB"; E={ [math]::Round($_.Length / 1KB, 1) }},
                             LastWriteTime,
                             CreationTime
                $found += $files
            }
        }
    }

    if ($found.Count -eq 0) {
        Write-Host "  No suspicious files found in risk directories." -ForegroundColor Green
        Write-Log "Suspicious file search: none found." "INFO"
    } else {
        Write-Host "  WARNING: $($found.Count) suspicious files found:" -ForegroundColor Magenta
        $found | Format-Table -AutoSize
        Write-Log "Suspicious files detected: $($found.Count)" "ALERT"
    }
    Pause-Screen
}

# =============================================================================
# 6. File access audit (Windows Security Event Log)
# =============================================================================
function Show-FileAuditLog {
    Show-Header "FILE ACCESS AUDIT"
    Write-Host "  Reading file audit events (Event ID 4663)..." -ForegroundColor DarkGray
    Write-Host "  (Note: requires object auditing enabled via Group Policy)" -ForegroundColor DarkGray
    Write-Host ""

    try {
        $events = Get-WinEvent -FilterHashtable @{LogName="Security"; Id=4663} -MaxEvents 30 -ErrorAction Stop |
                  Select-Object TimeCreated,
                      @{N="User";    E={ $_.Properties[1].Value }},
                      @{N="Object";  E={ $_.Properties[6].Value }},
                      @{N="Access";  E={ $_.Properties[8].Value }}

        if ($events) {
            $events | Format-Table -AutoSize
            Write-Log "File audit queried: $($events.Count) events." "INFO"
        } else {
            Write-Host "  No file audit events recorded." -ForegroundColor DarkGray
        }
    } catch {
        Write-Host "  Could not read audit events." -ForegroundColor Yellow
        Write-Host "  Enable at: Group Policy > Audit Object Access" -ForegroundColor DarkGray
        Write-Log "Error reading file audit: $($_.Exception.Message)" "WARN"
    }
    Pause-Screen
}

# =============================================================================
# 7. Generate report
# =============================================================================
function Export-FileSystemReport {
    Show-Header "GENERATE REPORT - FILE SYSTEM"
    $reportPath = Get-ReportPath "FileSystem"

    $lines = @()
    $lines += "=" * 60
    $lines += "FILE SYSTEM REPORT"
    $lines += "Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    $lines += "Server: $env:COMPUTERNAME"
    $lines += "=" * 60
    $lines += ""
    $lines += "DISK SPACE"
    Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
        $total = [math]::Round($_.Size / 1GB, 2)
        $free  = [math]::Round($_.FreeSpace / 1GB, 2)
        $used  = [math]::Round($total - $free, 2)
        $pct   = [math]::Round(($used / $total) * 100, 1)
        $lines += "  $($_.DeviceID)  Total: $total GB  Used: $used GB ($pct%)  Free: $free GB"
    }
    $lines += ""
    $lines += "LARGEST FILES IN C:\ (Top 20, >50MB)"
    $big = Get-ChildItem -Path "C:\" -Recurse -File -ErrorAction SilentlyContinue |
           Where-Object { $_.Length -gt 50MB } |
           Select-Object FullName, @{N="Size_MB"; E={ [math]::Round($_.Length/1MB,1) }} |
           Sort-Object Size_MB -Descending | Select-Object -First 20
    $lines += ($big | Format-Table -AutoSize | Out-String)

    $lines | Set-Content -Path $reportPath -Encoding UTF8
    Write-Host "  [OK] Report saved to: $reportPath" -ForegroundColor Green
    Write-Log "File system report generated: $reportPath" "INFO"
    Pause-Screen
}

# =============================================================================
# MODULE MENU
# =============================================================================
function Show-FileSystemMenu {
    do {
        Show-Header "FILE SYSTEM"
        Write-Host "   ANALYSIS" -ForegroundColor DarkCyan
        Write-Host "   [1]  Disk space analysis" -ForegroundColor White
        Write-Host "   [2]  Find large files" -ForegroundColor White
        Write-Host "   [5]  Identify suspicious files" -ForegroundColor White
        Write-Host "   [6]  File access audit" -ForegroundColor White
        Write-Host ""
        Write-Host "   MANAGEMENT" -ForegroundColor DarkCyan
        Write-Host "   [3]  Create directory" -ForegroundColor White
        Write-Host "   [4]  Manage permissions" -ForegroundColor White
        Write-Host ""
        Write-Host "  ------------------------------------------------------------" -ForegroundColor DarkGray
        Write-Host "   [7]  Generate report" -ForegroundColor DarkYellow
        Write-Host "   [0]  Back to main menu" -ForegroundColor DarkGray
        Write-Host ""

        $choice = Read-Host "  Option"
        switch ($choice) {
            "1" { Show-DiskUsage }
            "2" { Find-LargeFiles }
            "3" { New-DirectoryAuto }
            "4" { Manage-Permissions }
            "5" { Find-SuspiciousFiles }
            "6" { Show-FileAuditLog }
            "7" { Export-FileSystemReport }
            "0" { return }
            default { Write-Host "  Invalid option." -ForegroundColor Red; Start-Sleep 1 }
        }
    } while ($true)
}

Show-FileSystemMenu
