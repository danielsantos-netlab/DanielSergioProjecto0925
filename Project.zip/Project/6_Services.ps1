# =============================================================================
# Modules/6_Services.ps1 - Servicos e Servidores
# Service monitoring | Auto-restart | File/Print server | Remote access
# =============================================================================

. "$Global:ProjectRoot\Config.ps1"

# =============================================================================
# 1. List all services with status
# =============================================================================
function Show-Services {
    Show-Header "LIST OF SERVICES"

    Write-Host "  [1] All  [2] Running  [3] Stopped  [4] Auto-start: " -NoNewline -ForegroundColor Cyan
    $filter = Read-Host

    $services = Get-Service | Select-Object Name, DisplayName, Status, StartType |
                Sort-Object Status, Name

    switch ($filter) {
        "2" { $services = $services | Where-Object { $_.Status -eq "Running" } }
        "3" { $services = $services | Where-Object { $_.Status -eq "Stopped" } }
        "4" { $services = $services | Where-Object { $_.StartType -eq "Automatic" } }
    }

    $services | Format-Table -AutoSize
    Write-Host "  Total: $($services.Count) services" -ForegroundColor DarkGray
    Write-Log "List of services consulted." "INFO"
    Pause-Screen
}

# =============================================================================
# 2. Start / Stop / Restart service
# =============================================================================
function Manage-Service {
    Show-Header "MANAGE SERVICE"

    Write-Host "  Service name (e.g., Spooler, W32Time): " -NoNewline -ForegroundColor Cyan
    $svcName = Read-Host

    $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
    if (-not $svc) {
        Write-Host "  Service not found: $svcName" -ForegroundColor Red
        Pause-Screen; return
    }

    Write-Host "  Service: $($svc.DisplayName)  |  Status: $($svc.Status)" -ForegroundColor White
    Write-Host "  [1] Start  [2] Stop  [3] Restart: " -NoNewline -ForegroundColor Cyan
    $action = Read-Host

    try {
        switch ($action) {
            "1" { Start-Service -Name $svcName;   Write-Host "  [OK] Service started." -ForegroundColor Green;    Write-Log "Service started: $svcName" "INFO" }
            "2" { Stop-Service  -Name $svcName -Force; Write-Host "  [OK] Service stopped." -ForegroundColor Yellow; Write-Log "Service stopped: $svcName" "WARN" }
            "3" { Restart-Service -Name $svcName; Write-Host "  [OK] Service restarted." -ForegroundColor Green;  Write-Log "Service restarted: $svcName" "INFO" }
            default { Write-Host "  Invalid option." -ForegroundColor Red }
        }
    } catch {
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        Write-Log "Error managing service ${svcName}: $($_.Exception.Message)" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 3. Monitor critical services and auto-restart if down
# =============================================================================
function Watch-CriticalServices {
    Show-Header "MONITORING OF CRITICAL SERVICES"

    # Default critical services for Windows Server
    $criticals = @("Spooler","W32Time","WinRM","LanmanServer","LanmanWorkstation","Dhcp","Dnscache","EventLog","PlugPlay","RpcSs","SamSs")

    Write-Host "  To be verified $($criticals.Count) critical services..." -ForegroundColor DarkGray
    Write-Host ""

    $issues = 0
    foreach ($name in $criticals) {
        $svc = Get-Service -Name $name -ErrorAction SilentlyContinue
        if (-not $svc) { continue }

        if ($svc.Status -ne "Running") {
            Write-Host "  [DOWN] $($svc.DisplayName) ($name)" -ForegroundColor Magenta
            Write-Log "Critical service stopped.: $name" "ALERT"
            $issues++

            Write-Host "         Attempting to restart..." -ForegroundColor Yellow
            try {
                Start-Service -Name $name -ErrorAction Stop
                Write-Host "         [OK] Successfully restarted.." -ForegroundColor Green
                Write-Log "Service $name restarted automatically." "WARN"
            } catch {
                Write-Host "         [FAILURE] It was not possible to restart.: $($_.Exception.Message)" -ForegroundColor Red
                Write-Log "Failed to restart ${name}: $($_.Exception.Message)" "ERROR"
            }
        } else {
            Write-Host "  [  OK] $($svc.DisplayName)" -ForegroundColor DarkGray
        }
    }

    Write-Host ""
    if ($issues -eq 0) {
        Write-Host "  All critical services are running.." -ForegroundColor Green
    } else {
        Write-Host "  $issues critical service(s) were down. Check the log for details." -ForegroundColor Yellow
    }
    Pause-Screen
}

# =============================================================================
# 4. File Server status
# =============================================================================
function Show-FileServer {
    Show-Header "FILE SERVER STATUS"

    # Check if File Server role is installed
    $role = Get-WindowsFeature -Name "FS-FileServer" -ErrorAction SilentlyContinue
    if ($role -and $role.Installed) {
        Write-Host "  File Server Feature: INSTALLED" -ForegroundColor Green
    } else {
        Write-Host "  File Server Feature: NOT INSTALLED" -ForegroundColor Yellow
        Write-Host "  To install: Install-WindowsFeature -Name FS-FileServer" -ForegroundColor DarkGray
    }

    Write-Host ""
    Write-Host "  SHARES:" -ForegroundColor Yellow
    Get-SmbShare -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -notmatch "\$$" } |
        Select-Object Name, Path, Description,
            @{N="Sessoes"; E={ (Get-SmbSession -ShareName $_.Name -ErrorAction SilentlyContinue).Count }} |
        Format-Table -AutoSize

    Write-Host "  ACTIVE SMB SESSIONS:" -ForegroundColor Yellow
    Get-SmbSession -ErrorAction SilentlyContinue |
        Select-Object ClientComputerName, ClientUserName, NumOpens, SecondsExists |
        Format-Table -AutoSize

    Write-Log "File Server status checked." "INFO"
    Pause-Screen
}

# =============================================================================
# 5. Print Server status
# =============================================================================
function Show-PrintServer {
    Show-Header "PRINT SERVER STATUS"

    $spooler = Get-Service -Name Spooler -ErrorAction SilentlyContinue
    $state   = if ($spooler) { $spooler.Status } else { "NOT FOUND" }
    $color   = if ($state -eq "Running") { "Green" } else { "Red" }
    Write-Host "  Spooler Service: $state" -ForegroundColor $color

    Write-Host ""
    Write-Host "  INSTALLED PRINTERS:" -ForegroundColor Yellow
    Get-Printer -ErrorAction SilentlyContinue |
        Select-Object Name, DriverName, PortName, Shared, PrinterStatus |
        Format-Table -AutoSize

    Write-Host "  PRINT QUEUES WITH PENDING JOBS:" -ForegroundColor Yellow
    Get-PrintJob -PrinterName * -ErrorAction SilentlyContinue |
        Select-Object PrinterName, Id, UserName, JobStatus, Size |
        Format-Table -AutoSize

    Write-Log "File Server status checked." "INFO"
    Pause-Screen
}

# =============================================================================
# 6. Remote access (RDP/WinRM) status
# =============================================================================
function Show-RemoteAccess {
    Show-Header "REMOTE ACCESS"

    # RDP
    $rdpReg = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server" -ErrorAction SilentlyContinue
    $rdpEnabled = ($rdpReg.fDenyTSConnections -eq 0)
    Write-Host "  RDP (Remote Desktop): $(if ($rdpEnabled) { 'ACTIVE' } else { 'INACTIVE' })" -ForegroundColor $(if ($rdpEnabled) { 'Green' } else { 'Yellow' })

    # WinRM
    $winrm = Get-Service -Name WinRM -ErrorAction SilentlyContinue
    Write-Host "  WinRM (PowerShell Remoting): $($winrm.Status)" -ForegroundColor $(if ($winrm.Status -eq 'Running') { 'Green' } else { 'Yellow' })

    Write-Host ""
    Write-Host "  ACTIVE RDP SESSIONS:" -ForegroundColor Yellow
    try {
        $sessions = query session 2>&1
        $sessions | ForEach-Object { Write-Host "  $_" -ForegroundColor DarkGray }
    } catch {
        Write-Host "  No active RDP sessions or error occurred." -ForegroundColor DarkGray
    }

    Write-Log "Remote access status checked." "INFO"
    Pause-Screen
}

# =============================================================================
# 7. Generate services report
# =============================================================================
function Export-ServicesReport {
    Show-Header "GENERATE SERVICES REPORT"
    $reportPath = Get-ReportPath "Servicos"

    $lines = @()
    $lines += "=" * 60
    $lines += "SERVICES AND SERVERS REPORT"
    $lines += "Data: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    $lines += "Server: $env:COMPUTERNAME"
    $lines += "=" * 60
    $lines += ""
    $lines += "SERVICES RUNNING"
    $lines += (Get-Service | Where-Object { $_.Status -eq "Running" } | Select-Object Name, DisplayName, StartType | Format-Table -AutoSize | Out-String)
    $lines += "STOPPED SERVICES (Automatic Start)"
    $lines += (Get-Service | Where-Object { $_.Status -eq "Stopped" -and $_.StartType -eq "Automatic" } | Select-Object Name, DisplayName | Format-Table -AutoSize | Out-String)
    $lines += "SHARED FOLDERS"
    $lines += (Get-SmbShare -ErrorAction SilentlyContinue | Select-Object Name, Path, Description | Format-Table -AutoSize | Out-String)

    $lines | Set-Content -Path $reportPath -Encoding UTF8
    Write-Host "  [OK] Report saved to: $reportPath" -ForegroundColor Green
    Write-Log "Services report generated: $reportPath" "INFO"
    Pause-Screen
}

# =============================================================================
# MODULE MENU
# =============================================================================
function Show-ServicesMenu {
    do {
        Show-Header "SERVICES & SERVERS"
        Write-Host "   SERVICE CONTROL" -ForegroundColor DarkCyan
        Write-Host "   [1]  List services" -ForegroundColor White
        Write-Host "   [2]  Start / Stop / Restart service" -ForegroundColor White
        Write-Host "   [3]  Monitor critical services (auto-restart)" -ForegroundColor White
        Write-Host ""
        Write-Host "   SERVER ROLES" -ForegroundColor DarkCyan
        Write-Host "   [4]  File Server (SMB / Shares)" -ForegroundColor White
        Write-Host "   [5]  Print Server (Print Spooler)" -ForegroundColor White
        Write-Host "   [6]  Remote Access (RDP / WinRM)" -ForegroundColor White
        Write-Host ""
        Write-Host "  ------------------------------------------------------------" -ForegroundColor DarkGray
        Write-Host "   [7]  Generate report" -ForegroundColor DarkYellow
        Write-Host "   [0]  Back to main menu" -ForegroundColor DarkGray
        Write-Host ""

        $choice = Read-Host "  Opcao"
        switch ($choice) {
            "1" { Show-Services }
            "2" { Manage-Service }
            "3" { Watch-CriticalServices }
            "4" { Show-FileServer }
            "5" { Show-PrintServer }
            "6" { Show-RemoteAccess }
            "7" { Export-ServicesReport }
            "0" { return }
            default { Write-Host "  Invalid option." -ForegroundColor Red; Start-Sleep 1 }
        }
    } while ($true)
}

Show-ServicesMenu
