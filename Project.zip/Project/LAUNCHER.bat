@echo off
chcp 65001 >nul 2>&1
title ATEC // SYSTEM_CORE_2026
color 0B

:: ============================================================
::  ATEC SYSTEM_CORE_2026 - LAUNCHER
:: ============================================================

:: --- Admin Check ---
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [!] Requesting Administrator privileges...
    echo.
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: --- Paths ---
set "SOURCE=%~dp0"
set "DEST=C:\Project"

:: --- Create destination ---
if not exist "%DEST%" mkdir "%DEST%"

:: --- Setup Display ---
cls
echo.
echo  ============================================================
echo   ATEC // SYSTEM_CORE_2026 - SETUP
echo  ============================================================
echo.

:: --- Copy files ---
echo   Copying files to %DEST%...
echo.

for %%f in ("%SOURCE%*.ps1") do (
    copy /Y "%%f" "%DEST%\" >nul 2>&1
    echo     [+] %%~nxf
)
for %%f in ("%SOURCE%*.html") do (
    copy /Y "%%f" "%DEST%\" >nul 2>&1
    echo     [+] %%~nxf
)
copy /Y "%~f0" "%DEST%\" >nul 2>&1

echo.
echo   [OK] Files copied.
echo.

:: --- Create subfolders ---
if not exist "%DEST%\Logs" mkdir "%DEST%\Logs"
if not exist "%DEST%\Reports" mkdir "%DEST%\Reports"
if not exist "%DEST%\Backups" mkdir "%DEST%\Backups"
if not exist "%DEST%\Backups\Full" mkdir "%DEST%\Backups\Full"
if not exist "%DEST%\Backups\Incremental" mkdir "%DEST%\Backups\Incremental"
if not exist "%DEST%\Backups\Differential" mkdir "%DEST%\Backups\Differential"
echo   [OK] Folder structure ready.

:: --- Execution Policy ---
powershell -Command "Set-ExecutionPolicy Bypass -Scope LocalMachine -Force" >nul 2>&1
echo   [OK] ExecutionPolicy: Bypass

:: --- Validate essential files ---
set "MISSING=0"
if not exist "%DEST%\Server.ps1"     set "MISSING=1"
if not exist "%DEST%\MainMenu.ps1"   set "MISSING=1"
if not exist "%DEST%\dashboard.html" set "MISSING=1"

if "%MISSING%"=="1" (
    echo.
    echo   [ERROR] Essential files missing in %DEST%!
    echo   Required: Server.ps1, MainMenu.ps1, dashboard.html
    pause
    exit /b 1
)
echo   [OK] All essential files verified.

echo.
echo  ============================================================
echo   SETUP COMPLETE
echo  ============================================================
echo.
timeout /t 2 /nobreak >nul

:: --- Launch PowerShell Mini Menu ---
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$dest = 'C:\Project'; " ^
 "while ($true) { " ^
 "  Clear-Host; " ^
 "  Write-Host ''; " ^
 "  Write-Host '  ============================================================' -ForegroundColor Cyan; " ^
 "  Write-Host '   ATEC // SYSTEM_CORE_2026 - LAUNCHER' -ForegroundColor Cyan; " ^
 "  Write-Host '  ============================================================' -ForegroundColor Cyan; " ^
 "  Write-Host ''; " ^
 "  Write-Host '   [1]  Main Menu          ' -NoNewline -ForegroundColor White; " ^
 "  Write-Host '// PowerShell CLI' -ForegroundColor DarkGray; " ^
 "  Write-Host '   [2]  Server + Dashboard ' -NoNewline -ForegroundColor White; " ^
 "  Write-Host '// API + Browser' -ForegroundColor DarkGray; " ^
 "  Write-Host ''; " ^
 "  Write-Host '   [0] Exit' -ForegroundColor DarkGray; " ^
 "  Write-Host ''; " ^
 "  Write-Host '  ============================================================' -ForegroundColor Cyan; " ^
 "  Write-Host ''; " ^
 "  $c = Read-Host '   >>'; " ^
 "  if ($c -eq '1') { " ^
 "    Write-Host '' ; " ^
 "    Write-Host '   [....] Launching Main Menu...' -ForegroundColor Yellow; " ^
 "    Start-Process powershell -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-NoExit','-Command',\"cd $dest; .\\MainMenu.ps1\"; " ^
 "    Write-Host '   [ OK ] Main Menu opened in new window.' -ForegroundColor Green; " ^
 "    Start-Sleep 2; " ^
 "  } elseif ($c -eq '2') { " ^
 "    Write-Host ''; " ^
 "    Write-Host '   [....] Cleaning port 8080...' -ForegroundColor Yellow; " ^
 "    Get-NetTCPConnection -LocalPort 8080 -ErrorAction SilentlyContinue | ForEach-Object { " ^
 "      Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue; " ^
 "    }; " ^
 "    Start-Sleep 1; " ^
 "    Write-Host '   [....] Starting API Server on port 8080...' -ForegroundColor Yellow; " ^
 "    Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-Command',\"cd $dest; .\\Server.ps1\"; " ^
 "    Write-Host '   [....] Waiting for server...' -ForegroundColor Yellow; " ^
 "    Start-Sleep 4; " ^
 "    Write-Host '   [....] Opening Dashboard in browser...' -ForegroundColor Yellow; " ^
 "    Start-Process 'http://localhost:8080/dashboard'; " ^
 "    Write-Host '   [ OK ] Server + Dashboard launched.' -ForegroundColor Green; " ^
 "    Start-Sleep 2; " ^
 "  } elseif ($c -eq '0') { " ^
 "    Write-Host ''; " ^
 "    Write-Host '   Shutting down...' -ForegroundColor DarkGray; " ^
 "    Start-Sleep 1; " ^
 "    break; " ^
 "  } else { " ^
 "    Write-Host '   [!] Invalid option.' -ForegroundColor Red; " ^
 "    Start-Sleep 1; " ^
 "  } " ^
 "}"

exit
