# =============================================================================
# Server.ps1 - Local HTTP API for the Web Dashboard
# All project endpoints (modules 1-8)
# Usage: .\Server.ps1  (as Administrator)
# Browser: http://localhost:8080/dashboard
# =============================================================================

#Requires -RunAsAdministrator

$Global:ProjectRoot = $PSScriptRoot
if (-not $Global:ProjectRoot) { $Global:ProjectRoot = (Get-Location).Path }
. "$Global:ProjectRoot\Config.ps1"

$port = 8080

# Force-release port via http.sys (handles cases where HttpListener didn't clean up)
$existing = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue
if ($existing) {
    $existing | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object {
        $proc = Get-Process -Id $_ -ErrorAction SilentlyContinue
        if ($proc -and $proc.Name -notin @("System","svchost")) {
            Write-Host "  [!] Killing process on port $port : $($proc.Name) (PID $_)" -ForegroundColor Yellow
            Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue
        }
    }
    Start-Sleep -Milliseconds 1200
}

# Also clean up http.sys reservations
$netshOut = netsh http show servicestate 2>&1
if ($netshOut -match ":$port") {
    Write-Host "  [!] Cleaning up http.sys registration on port $port..." -ForegroundColor Yellow
    # Abort any registered sessions on this port by restarting the http service
    net stop http /y 2>&1 | Out-Null
    net start http 2>&1 | Out-Null
    Start-Sleep -Milliseconds 500
}

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$port/")
try {
    $listener.Start()
    Write-Host "  [OK] Listening on port $port" -ForegroundColor Green
} catch {
    Write-Host "  [!] Port $port still in use. Run this to fix:" -ForegroundColor Red
    Write-Host "      Stop-Process -Name powershell -Force" -ForegroundColor Yellow
    Write-Host "      Then wait 5 seconds and re-run Server.ps1" -ForegroundColor Yellow
    Read-Host "  Press Enter to exit"
    exit 1
}

$dashboardPath = Join-Path $Global:ProjectRoot "dashboard.html"

function Write-ServerLog {
    param([string]$msg, [string]$color = "DarkGray")
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] $msg" -ForegroundColor $color
}

Write-Host ""
Write-Host "  ============================================================" -ForegroundColor DarkCyan
Write-Host "   SYSADMIN DASHBOARD - API SERVER" -ForegroundColor Cyan
Write-Host "   Listening on : http://localhost:$port" -ForegroundColor Green
Write-Host "   Dashboard    : http://localhost:$port/dashboard" -ForegroundColor Yellow
Write-Host "   CTRL+C       : stop the server" -ForegroundColor DarkGray
Write-Host "  ============================================================" -ForegroundColor DarkCyan
Write-Host ""

function ToJson { param($d) return ($d | ConvertTo-Json -Depth 6 -Compress) }
function ToJsonArray { param($arr) if ($null -eq $arr -or @($arr).Count -eq 0) { return '[]' }; $j = ConvertTo-Json @($arr) -Depth 6 -Compress; if ($j[0] -ne '[') { $j = "[$j]" }; return $j }
function OkJson  { param([string]$msg) return ToJson @{ok=$true;  msg=$msg} }
function ErrJson { param([string]$msg) return ToJson @{ok=$false; msg=$msg} }
function IsAD    { return $null -ne (Get-Module -ListAvailable -Name "ActiveDirectory" -ErrorAction SilentlyContinue) }

function Invoke-API {
    param([string]$path, [string]$method, [string]$body)

    switch -Regex ($path) {

        # -- DASHBOARD HTML -------------------------------------
        "^/$|^/dashboard$" {
            $html = if (Test-Path $dashboardPath) { Get-Content $dashboardPath -Raw -Encoding UTF8 } else { "<h1>dashboard.html not found</h1>" }
            return @{type='html'; data=$html}
        }

        # ======================================================
        # 1. PROCESSES
        # ======================================================

        "^/api/processes$" {
            # Sort: processes with CPU first, then rest (so notepad/new apps still appear)
            $allProcs = Get-Process | Sort-Object @{E={if($_.CPU -ne $null){$_.CPU}else{0}}} -Descending | Select-Object -First 120
            $items = @()
            foreach ($p in $allProcs) {
                $startStr = "N/A"
                try { $startStr = $p.StartTime.ToString("HH:mm:ss") } catch {}
                $nm  = ($p.Name  -replace '"','') -replace '[^ -~]',''
                $cpu = if ($p.CPU -ne $null) { [math]::Round($p.CPU, 1) } else { 0 }
                $ram = [math]::Round($p.WorkingSet64 / 1MB, 1)
                $thr = $p.Threads.Count
                $items += "{`"id`":$($p.Id),`"name`":`"$nm`",`"cpu`":$cpu,`"ramMB`":$ram,`"threads`":$thr,`"start`":`"$startStr`"}"
            }
            $json = "[" + ($items -join ",") + "]"
            return @{type='json'; data=$json}
        }

        "^/api/process/kill$" {
            $protected = @("System","Idle","svchost","lsass","csrss","wininit","services","smss","winlogon","dwm","powershell","ServerManager")
            try {
                $req = $body | ConvertFrom-Json
                $p   = Get-Process -Id ([int]$req.pid) -ErrorAction Stop
                if ($p.Name -in $protected) { return @{type='json'; data=ErrJson "Protected: $($p.Name)"} }
                Stop-Process -Id $p.Id -Force
                Write-Log "Dashboard kill PID $($p.Id) ($($p.Name))" "WARN"
                return @{type='json'; data=OkJson "Process '$($p.Name)' terminated."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/process/suspicious$" {
            $protected = @("System","Idle","svchost","lsass","csrss","wininit","services","smss","winlogon","dwm")
            $out = @()
            Get-Process | Where-Object {$_.Name -notin $protected} | ForEach-Object {
                $reasons = @()
                try {
                    $wmi   = Get-CimInstance Win32_Process -Filter "ProcessId=$($_.Id)" -ErrorAction Stop
                    $ppath = $wmi.ExecutablePath
                    if ($ppath) {
                        if ($ppath -match "\\Temp\\|\\AppData\\Local\\Temp\\") { $reasons += "Temp path" }
                        if ($ppath -match "\\Downloads\\")                     { $reasons += "Downloads path" }
                        if ($ppath -match "\\AppData\\Roaming\\")              { $reasons += "Roaming path" }
                    }
                    $ram = [math]::Round($_.WorkingSet64/1MB,1)
                    if ($ram -gt 300 -and $_.MainWindowHandle -eq 0) { $reasons += "High RAM no window ($($ram) MB)" }
                } catch {}
                if ($reasons.Count -gt 0) {
                    $nm  = $_.Name -replace '"',''
                    $rsn = ($reasons -join " | ") -replace '"',''
                    $ram2 = [math]::Round($_.WorkingSet64/1MB,1)
                    $out += "{`"pid`":$($_.Id),`"name`":`"$nm`",`"ramMB`":$ram2,`"reasons`":`"$rsn`"}"
                }
            }
            $json = if ($out.Count -gt 0) { "[" + ($out -join ",") + "]" } else { "[]" }
            return @{type='json'; data=$json}
        }

        "^/api/process/autokill$" {
            $protected = @("System","Idle","svchost","lsass","csrss","wininit","services","smss","winlogon","dwm","powershell")
            $killed = @()
            Get-Process | Where-Object {$_.CPU -gt 60 -and $_.Name -notin $protected} | ForEach-Object {
                try { Stop-Process -Id $_.Id -Force; $killed += $_.Name; Write-Log "Auto-kill: $($_.Name) PID $($_.Id)" "WARN" } catch {}
            }
            return @{type='json'; data=ToJson @{ok=$true; killed=@($killed); count=$killed.Count}}
        }

        "^/api/process/launch$" {
            try {
                $req = $body | ConvertFrom-Json
                $exe = $req.exe
                if (-not $exe) { return @{type='json'; data=ErrJson "No executable specified."} }
                $allowed = @("notepad","notepad.exe","calc","calc.exe","mspaint","mspaint.exe",
                             "taskmgr","taskmgr.exe","explorer","explorer.exe","wordpad","write",
                             "regedit","services","services.msc","eventvwr","compmgmt","compmgmt.msc","devmgmt","devmgmt.msc",
                             "diskmgmt","diskmgmt.msc","perfmon","resmon","mmc","control","cmd","powershell")
                $base = [System.IO.Path]::GetFileNameWithoutExtension($exe).ToLower()
                if ($base -notin $allowed) {
                    return @{type='json'; data=ErrJson "Not allowed: $exe. Only system tools permitted."}
                }
                $proc = Start-Process -FilePath $exe -PassThru -ErrorAction Stop
                Write-Log "Dashboard: launched $exe (PID $($proc.Id))" "INFO"
                return @{type='json'; data=ToJson @{ok=$true; msg="Started '$exe' (PID $($proc.Id))"; pid=$proc.Id}}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        # ======================================================
        # 2. FILE SYSTEM
        # ======================================================

        "^/api/filesystem/disks$" {
            $disks = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
                @{drive=$_.DeviceID; totalGB=[math]::Round($_.Size/1GB,1); freeGB=[math]::Round($_.FreeSpace/1GB,1); usedPct=[math]::Round((($_.Size-$_.FreeSpace)/$_.Size)*100,1)}
            }
            return @{type='json'; data=ToJson @($disks)}
        }

        "^/api/filesystem/largefiles$" {
            try {
                $req   = $body | ConvertFrom-Json
                $path2 = if ($req.path) {$req.path} else {"C:\"}
                $minMB = if ($req.minMB) {[int]$req.minMB} else {100}
                $files = Get-ChildItem -Path $path2 -Recurse -File -ErrorAction SilentlyContinue |
                    Where-Object {$_.Length -gt ($minMB * 1MB)} |
                    Select-Object FullName, @{N="sizeMB";E={[math]::Round($_.Length/1MB,1)}}, LastWriteTime |
                    Sort-Object sizeMB -Descending | Select-Object -First 25
                return @{type='json'; data=ToJson @($files)}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/filesystem/mkdir$" {
            try {
                $req = $body | ConvertFrom-Json
                if (Test-Path $req.path) { return @{type='json'; data=ErrJson "Folder already exists: $($req.path)"} }
                New-Item -ItemType Directory -Path $req.path -Force | Out-Null
                Write-Log "Dashboard mkdir: $($req.path)" "INFO"
                return @{type='json'; data=OkJson "Folder created: $($req.path)"}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/filesystem/suspicious$" {
            try {
                $exts = @("*.exe","*.bat","*.vbs","*.ps1","*.cmd","*.scr","*.pif","*.js","*.jar","*.hta")
                $dirs = @(
                    $env:TEMP,
                    "C:\Windows\Temp",
                    "C:\ProgramData",
                    "C:\Users\Public",
                    "$env:USERPROFILE\Desktop",
                    "$env:USERPROFILE\Downloads",
                    "$env:USERPROFILE\Documents",
                    $env:APPDATA,
                    $env:LOCALAPPDATA,
                    "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"
                ) | Where-Object { $_ -and $_.Trim() -ne "" } | Select-Object -Unique

                $found = @()

                foreach ($dir in $dirs) {
                    if (Test-Path $dir) {
                        foreach ($ext in $exts) {
                            Get-ChildItem -Path $dir -Filter $ext -File -Recurse -ErrorAction SilentlyContinue |
                                ForEach-Object {
                                    $found += [pscustomobject]@{
                                        path     = $_.FullName
                                        ext      = $_.Extension
                                        sizeKB   = [math]::Round($_.Length / 1KB, 1)
                                        modified = $_.LastWriteTime.ToString("yyyy-MM-dd HH:mm")
                                    }
                                }
                        }
                    }
                }

                $found = $found |
                    Sort-Object path -Unique |
                    Sort-Object modified -Descending |
                    Select-Object -First 200

                return @{type='json'; data=ToJson @($found)}
            } catch {
                Write-Log "Failed suspicious file scan: $($_.Exception.Message)" "ERROR"
                return @{type='json'; data='[]'}
            }
        }

        "^/api/filesystem/permissions$" {
            try {
                $req = $body | ConvertFrom-Json
                $acl = Get-Acl $req.path
                $rules = $acl.Access | ForEach-Object { @{identity=$_.IdentityReference.Value; rights=$_.FileSystemRights.ToString(); type=$_.AccessControlType.ToString(); inherited=$_.IsInherited} }
                return @{type='json'; data=ToJson @{owner=$acl.Owner; inheritanceDisabled=$acl.AreAccessRulesProtected; rules=@($rules)}}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/filesystem/permissions/add$" {
            try {
                $req = $body | ConvertFrom-Json
                $acl = Get-Acl $req.path
                $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                    $req.identity, $req.rights, "ContainerInherit,ObjectInherit", "None", $req.type)
                $acl.SetAccessRule($rule)
                Set-Acl -Path $req.path -AclObject $acl
                Write-ServerLog "Permission added: $($req.identity) -> $($req.type) $($req.rights) on $($req.path)" "Green"
                return @{type='json'; data=OkJson "Permission added: $($req.identity) -> $($req.type) $($req.rights)"}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/filesystem/permissions/remove$" {
            try {
                $req = $body | ConvertFrom-Json
                $acl = Get-Acl $req.path
                $target = $acl.Access | Where-Object {
                    $_.IdentityReference.Value -eq $req.identity -and
                    $_.FileSystemRights.ToString() -eq $req.rights -and
                    $_.AccessControlType.ToString() -eq $req.type -and
                    -not $_.IsInherited
                } | Select-Object -First 1
                if (-not $target) { return @{type='json'; data=ErrJson "Rule not found or is inherited."} }
                $acl.RemoveAccessRule($target) | Out-Null
                Set-Acl -Path $req.path -AclObject $acl
                Write-ServerLog "Permission removed: $($req.identity) from $($req.path)" "Yellow"
                return @{type='json'; data=OkJson "Permission removed: $($req.identity)"}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/filesystem/permissions/owner$" {
            try {
                $req = $body | ConvertFrom-Json
                $acl = Get-Acl $req.path
                $account = New-Object System.Security.Principal.NTAccount($req.owner)
                $acl.SetOwner($account)
                Set-Acl -Path $req.path -AclObject $acl
                Write-ServerLog "Owner changed on $($req.path) to $($req.owner)" "Green"
                return @{type='json'; data=OkJson "Owner changed to $($req.owner)"}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/filesystem/permissions/inheritance$" {
            try {
                $req = $body | ConvertFrom-Json
                $acl = Get-Acl $req.path
                if ($req.disable) {
                    $acl.SetAccessRuleProtection($true, $true)
                    Set-Acl -Path $req.path -AclObject $acl
                    Write-ServerLog "Inheritance disabled on $($req.path)" "Yellow"
                    return @{type='json'; data=OkJson "Inheritance disabled. Inherited rules converted to explicit."}
                } else {
                    $acl.SetAccessRuleProtection($false, $false)
                    Set-Acl -Path $req.path -AclObject $acl
                    Write-ServerLog "Inheritance enabled on $($req.path)" "Green"
                    return @{type='json'; data=OkJson "Inheritance enabled."}
                }
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/filesystem/audit$" {
            try {
                $events = @(
                    Get-WinEvent -FilterHashtable @{LogName="Security";Id=4663} -MaxEvents 20 -ErrorAction Stop |
                        ForEach-Object {
                            [pscustomobject]@{
                                time   = $_.TimeCreated.ToString("HH:mm:ss")
                                user   = if ($_.Properties.Count -gt 1 -and $null -ne $_.Properties[1].Value -and "$($_.Properties[1].Value)".Trim() -ne "") { "$($_.Properties[1].Value)" } else { "Unknown" }
                                object = if ($_.Properties.Count -gt 6 -and $null -ne $_.Properties[6].Value -and "$($_.Properties[6].Value)".Trim() -ne "") { "$($_.Properties[6].Value)" } else { "Unknown object" }
                                access = if ($_.Properties.Count -gt 8 -and $null -ne $_.Properties[8].Value -and "$($_.Properties[8].Value)".Trim() -ne "") { "$($_.Properties[8].Value)" } else { "" }
                            }
                        }
                )
                return @{type='json'; data=ToJsonArray $events}
            } catch {
                return @{type='json'; data='[]'}
            }
        }

        # ======================================================
        # 3. RESOURCES
        # ======================================================

        "^/api/resources$" {
            $cpu  = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
            $os   = Get-CimInstance Win32_OperatingSystem
            $ramT = [math]::Round($os.TotalVisibleMemorySize/1MB,2)
            $ramF = [math]::Round($os.FreePhysicalMemory/1MB,2)
            $ramU = [math]::Round($ramT-$ramF,2)
            $ramP = [math]::Round(($ramU/$ramT)*100,1)
            $disks = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
                @{drive=$_.DeviceID; totalGB=[math]::Round($_.Size/1GB,1); freeGB=[math]::Round($_.FreeSpace/1GB,1); usedPct=[math]::Round((($_.Size-$_.FreeSpace)/$_.Size)*100,1)}
            }
            $nics = Get-NetAdapter | Where-Object {$_.Status -eq "Up"} | ForEach-Object {
                $spd = $_.ReceiveLinkSpeed; $spdM = if($spd -and $spd -gt 0){[math]::Round($spd/1000000,0)}else{0}
                $ip = (Get-NetIPAddress -InterfaceIndex $_.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -First 1).IPAddress
                @{name=$_.Name; speedMbps=$spdM; mac=$_.MacAddress; ip=$ip}
            }
            # Alerts
            $alerts = @()
            if ($cpu -ge $Global:ThresholdCPU)   { $alerts += "CPU at $($cpu)% (threshold $($Global:ThresholdCPU)%)" }
            if ($ramP -ge $Global:ThresholdRAM)   { $alerts += "RAM at $($ramP)% (threshold $($Global:ThresholdRAM)%)" }
            foreach ($d in $disks) { if ($d.usedPct -ge $Global:ThresholdDisk) { $alerts += "Disk $($d.drive) at $($d.usedPct)%" } }

            return @{type='json'; data=ToJson @{
                cpu=$cpu; ramUsed=$ramU; ramTotal=$ramT; ramFree=$ramF; ramPct=$ramP
                disks=@($disks); nics=@($nics); host=$env:COMPUTERNAME; user=$env:USERNAME
                time=(Get-Date -Format "yyyy-MM-dd HH:mm:ss"); alerts=@($alerts)
                thresholds=@{cpu=$Global:ThresholdCPU; ram=$Global:ThresholdRAM; disk=$Global:ThresholdDisk}
            }}
        }

        "^/api/resources/history$" {
            try {
                $histFile = Join-Path $Global:LogDir "resource_history.csv"
                if (-not (Test-Path $histFile)) {
                    return @{type='json'; data='[]'}
                }

                $rows = @(
                    Import-Csv $histFile -ErrorAction Stop |
                    Where-Object { $_.Timestamp } |
                    Select-Object -Last 30
                )

                $json = ConvertTo-Json $rows -Depth 6 -Compress
                if (-not $json) { $json = '[]' }
                if ($json -notmatch '^\[') { $json = "[$json]" }

                return @{type='json'; data=$json}
            } catch {
                Write-ServerLog "Failed to load resource history: $($_.Exception.Message)" "Red"
                return @{type='json'; data='[]'}
            }
        }

        "^/api/resources/record$" {
            $histFile = Join-Path $Global:LogDir "resource_history.csv"
            if (-not (Test-Path $histFile)) { "Timestamp,CPU_Pct,RAM_Pct,RAM_Used_GB,RAM_Total_GB,DiskC_Pct" | Set-Content $histFile -Encoding UTF8 }
            $cpu  = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
            $os   = Get-CimInstance Win32_OperatingSystem
            $ramT = [math]::Round($os.TotalVisibleMemorySize/1MB,2)
            $ramF = [math]::Round($os.FreePhysicalMemory/1MB,2)
            $ramU = [math]::Round($ramT-$ramF,2)
            $ramP = [math]::Round(($ramU/$ramT)*100,1)
            $diskC = (Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" | Select-Object -First 1)
            $diskP = if($diskC){[math]::Round((($diskC.Size-$diskC.FreeSpace)/$diskC.Size)*100,1)}else{0}
            "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$cpu,$ramP,$ramU,$ramT,$diskP" | Add-Content $histFile -Encoding UTF8
            return @{type='json'; data=OkJson "Entry recorded."}
        }

        # ======================================================
        # 4. SECURITY
        # ======================================================

        "^/api/security/ports$" {
            $risky = @(23,135,137,138,139,445,3389,4444,5900,6667)
            $ports = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
                Select-Object @{N="port";E={$_.LocalPort}}, @{N="addr";E={$_.LocalAddress}},
                    @{N="process";E={(Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).Name}},
                    @{N="risky";E={$_.LocalPort -in $risky}} |
                Sort-Object port
            return @{type='json'; data=ToJson @($ports)}
        }

        "^/api/security/failedlogins$" {
            try {
                $events = Get-WinEvent -FilterHashtable @{LogName="Security";Id=4625} -MaxEvents 30 -ErrorAction Stop |
                    ForEach-Object { @{time=$_.TimeCreated.ToString("yyyy-MM-dd HH:mm:ss"); user=$_.Properties[5].Value; domain=$_.Properties[6].Value; ip=$_.Properties[19].Value} }
                $summary = $events | Group-Object {$_.user} | Sort-Object Count -Descending |
                    Select-Object @{N="user";E={$_.Name}}, @{N="count";E={$_.Count}}, @{N="alert";E={$_.Count -ge 5}}
                return @{type='json'; data=ToJson @{events=@($events); summary=@($summary)}}
            } catch { return @{type='json'; data=ToJson @{events=@(); summary=@()}} }
        }

        "^/api/security/logins$" {
            try {
                $events = Get-WinEvent -FilterHashtable @{LogName="Security";Id=4624} -MaxEvents 20 -ErrorAction Stop |
                    ForEach-Object {
                        $t = switch([int]$_.Properties[8].Value){2{"Interactive"};3{"Network"};10{"RDP"};5{"Service"};7{"Unlock"};default{"Type $($_.Properties[8].Value)"}}
                        @{time=$_.TimeCreated.ToString("HH:mm:ss"); user=$_.Properties[5].Value; type=$t; ip=$_.Properties[18].Value}
                    } | Where-Object {$_.user -notmatch "SYSTEM|ANONYMOUS|DWM|UMFD|-$"}
                return @{type='json'; data=ToJson @($events)}
            } catch { return @{type='json'; data=ToJson @()} }
        }

        "^/api/security/events$" {
            $checks = @(
                @{id=4720;desc="User created"},@{id=4726;desc="User deleted"},
                @{id=4728;desc="Added to privileged group"},@{id=4740;desc="Account locked out"},
                @{id=4625;desc="Failed login"},@{id=1102;desc="Audit log cleared"}
            )
            $results = $checks | ForEach-Object {
                $ev = $_; $count = 0
                try { $count = (Get-WinEvent -FilterHashtable @{LogName="Security";Id=$ev.id} -MaxEvents 50 -ErrorAction Stop).Count } catch {}
                @{id=$ev.id; desc=$ev.desc; count=$count; alert=($count -gt 0)}
            }
            return @{type='json'; data=ToJson @($results)}
        }

        "^/api/security/firewall$" {
            try {
                $profiles = Get-NetFirewallProfile -ErrorAction Stop | ForEach-Object {
                    @{name=$_.Name; enabled=$_.Enabled}
                }
                $rules = Get-NetFirewallRule -Direction Inbound -Enabled True -ErrorAction SilentlyContinue |
                    Select-Object DisplayName, Profile, Action | Select-Object -First 15
                return @{type='json'; data=ToJson @{profiles=@($profiles); rules=@($rules)}}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/security/tasks$" {
            $tasks = Get-ScheduledTask -ErrorAction SilentlyContinue |
                Where-Object {$_.State -eq "Ready" -or $_.State -eq "Running"} |
                ForEach-Object {
                    $exec = ($_.Actions | Select-Object -First 1).Execute
                    @{name=$_.TaskName; path=$_.TaskPath; state=$_.State.ToString(); exec=$exec;
                      suspicious=($exec -match "\\Temp\\|powershell|cmd|wscript|cscript|mshta")}
                }
            return @{type='json'; data=ToJson @($tasks)}
        }

        # ======================================================
        # 5. USERS AND GROUPS
        # ======================================================

        "^/api/users$" {
            $adAvail = IsAD
            if ($adAvail) {
                Import-Module ActiveDirectory -ErrorAction SilentlyContinue
                $users = Get-ADUser -Filter * -Properties DisplayName,Enabled,LastLogonDate,PasswordLastSet |
                    Select-Object @{N="name";E={$_.SamAccountName}},@{N="display";E={$_.DisplayName}},
                        @{N="enabled";E={$_.Enabled}},
                        @{N="lastLogon";E={if($_.LastLogonDate){$_.LastLogonDate.ToString("yyyy-MM-dd")}else{"Never"}}},
                        @{N="pwdSet";E={if($_.PasswordLastSet){$_.PasswordLastSet.ToString("yyyy-MM-dd")}else{"N/A"}}}
                return @{type='json'; data=ToJson @{mode="AD"; users=@($users)}}
            } else {
                $users = Get-LocalUser | Select-Object @{N="name";E={$_.Name}},@{N="display";E={$_.FullName}},
                    @{N="enabled";E={$_.Enabled}},
                    @{N="lastLogon";E={if($_.LastLogon){$_.LastLogon.ToString("yyyy-MM-dd")}else{"Never"}}},
                    @{N="pwdSet";E={"N/A"}}
                return @{type='json'; data=ToJson @{mode="Local"; users=@($users)}}
            }
        }

        "^/api/user/create$" {
            try {
                $req  = $body | ConvertFrom-Json
                $pass = ConvertTo-SecureString $req.password -AsPlainText -Force
                if (IsAD) {
                    Import-Module ActiveDirectory
                    New-ADUser -SamAccountName $req.username -Name $req.fullname -DisplayName $req.fullname -AccountPassword $pass -Enabled $true -Description $req.desc
                } else {
                    New-LocalUser -Name $req.username -Password $pass -FullName $req.fullname -Description $req.desc
                }
                Write-Log "Dashboard: user created $($req.username)" "INFO"
                return @{type='json'; data=OkJson "User '$($req.username)' created."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/user/delete$" {
            try {
                $req = $body | ConvertFrom-Json
                if (IsAD) { Import-Module ActiveDirectory; Remove-ADUser -Identity $req.username -Confirm:$false }
                else       { Remove-LocalUser -Name $req.username }
                Write-Log "Dashboard: user removed $($req.username)" "WARN"
                return @{type='json'; data=OkJson "User '$($req.username)' removed."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/user/toggle$" {
            try {
                $req = $body | ConvertFrom-Json
                if (IsAD) {
                    Import-Module ActiveDirectory
                    if ($req.enable) { Enable-ADAccount -Identity $req.username } else { Disable-ADAccount -Identity $req.username }
                } else {
                    if ($req.enable) { Enable-LocalUser -Name $req.username } else { Disable-LocalUser -Name $req.username }
                }
                $state = if($req.enable){"enabled"}else{"disabled"}
                Write-Log "Dashboard: user $($req.username) $state" "INFO"
                return @{type='json'; data=OkJson "User '$($req.username)' $state."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/groups$" {
            if (IsAD) {
                Import-Module ActiveDirectory -ErrorAction SilentlyContinue
                $groups = Get-ADGroup -Filter * | Select-Object @{N="name";E={$_.Name}},@{N="scope";E={$_.GroupScope.ToString()}},@{N="category";E={$_.GroupCategory.ToString()}}
                return @{type='json'; data=ToJson @{mode="AD"; groups=@($groups)}}
            } else {
                $groups = Get-LocalGroup | Select-Object @{N="name";E={$_.Name}},@{N="scope";E={"Local"}},@{N="category";E={$_.Description}}
                return @{type='json'; data=ToJson @{mode="Local"; groups=@($groups)}}
            }
        }

        "^/api/group/create$" {
            try {
                $req = $body | ConvertFrom-Json
                if (IsAD) { Import-Module ActiveDirectory; New-ADGroup -Name $req.name -GroupScope Global -Description $req.desc }
                else       { New-LocalGroup -Name $req.name -Description $req.desc }
                Write-Log "Dashboard: group created $($req.name)" "INFO"
                return @{type='json'; data=OkJson "Group '$($req.name)' created."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/group/adduser$" {
            try {
                $req = $body | ConvertFrom-Json
                if (IsAD) { Import-Module ActiveDirectory; Add-ADGroupMember -Identity $req.group -Members $req.username }
                else       { Add-LocalGroupMember -Group $req.group -Member $req.username }
                Write-Log "Dashboard: $($req.username) -> group $($req.group)" "INFO"
                return @{type='json'; data=OkJson "User '$($req.username)' added to group '$($req.group)'."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        # ======================================================
        # 6. SERVICES
        # ======================================================

        "^/api/services$" {
            $svcs = Get-Service | Select-Object Name, DisplayName,
                @{N="status";E={$_.Status.ToString()}},
                @{N="startType";E={$_.StartType.ToString()}} |
                Sort-Object status, Name
            return @{type='json'; data=ToJson @($svcs)}
        }

        "^/api/service/(start|stop|restart)$" {
            try {
                $req    = $body | ConvertFrom-Json
                $action = ($path -split "/")[-1]
                switch($action){
                    "start"   {Start-Service   -Name $req.name -ErrorAction Stop}
                    "stop"    {Stop-Service    -Name $req.name -Force -ErrorAction Stop}
                    "restart" {Restart-Service -Name $req.name -ErrorAction Stop}
                }
                Write-Log "Dashboard: service $action -> $($req.name)" "INFO"
                return @{type='json'; data=OkJson "Service '$($req.name)' -> $action OK."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/services/critical$" {
            $criticals = @("Spooler","W32Time","WinRM","LanmanServer","LanmanWorkstation","Dhcp","Dnscache","EventLog","RpcSs")
            $results = @()
            foreach ($name in $criticals) {
                $svc = Get-Service -Name $name -ErrorAction SilentlyContinue
                if (-not $svc) { continue }
                $restarted = $false
                if ($svc.Status -ne "Running") {
                    try { Start-Service -Name $name -ErrorAction Stop; $restarted = $true; Write-Log "Auto-restart: $name" "WARN" } catch {}
                }
                $results += @{name=$svc.Name; display=$svc.DisplayName; status=$svc.Status.ToString(); restarted=$restarted}
            }
            return @{type='json'; data=ToJson @($results)}
        }

        "^/api/services/fileserver$" {
            try {
                $installed = $false

                if (Get-Command Get-WindowsFeature -ErrorAction SilentlyContinue) {
                    $role = Get-WindowsFeature -Name "FS-FileServer" -ErrorAction SilentlyContinue
                    $installed = [bool]($role -and $role.Installed)
                }

                $shares = @()
                if (Get-Command Get-SmbShare -ErrorAction SilentlyContinue) {
                    $shares = @(
                        Get-SmbShare -ErrorAction SilentlyContinue |
                            Where-Object { $_.Name -notlike '*$' } |
                            Select-Object @{N="name";E={$_.Name}},
                                        @{N="path";E={$_.Path}},
                                        @{N="desc";E={$_.Description}}
                    )
                }

                $sessions = @()
                if (Get-Command Get-SmbSession -ErrorAction SilentlyContinue) {
                    $sessions = @(
                        Get-SmbSession -ErrorAction SilentlyContinue |
                            Select-Object @{N="client";E={$_.ClientComputerName}},
                                        @{N="user";E={$_.ClientUserName}},
                                        @{N="opens";E={$_.NumOpens}}
                    )
                }

                return @{type='json'; data=ToJson @{
                    installed = $installed
                    shares    = @($shares)
                    sessions  = @($sessions)
                }}
            } catch {
                Write-Log "File Server load failed: $($_.Exception.Message)" "ERROR"
                return @{type='json'; data=ToJson @{
                    installed = $false
                    shares    = @()
                    sessions  = @()
                    error     = $_.Exception.Message
                }}
            }
        }

        "^/api/services/fileserver/quickshare$" {
            try {
                $sharePath = Join-Path $Global:ProjectRoot "SharedFiles"
                if (-not (Test-Path $sharePath)) { New-Item -ItemType Directory -Path $sharePath -Force | Out-Null }
                $existing = Get-SmbShare -Name "SharedFiles" -ErrorAction SilentlyContinue
                if ($existing) { return @{type='json'; data=OkJson "Share 'SharedFiles' already exists at $sharePath."} }
                New-SmbShare -Name "SharedFiles" -Path $sharePath -FullAccess "Everyone" -ErrorAction Stop | Out-Null
                Write-Log "Quick share created via dashboard: SharedFiles -> $sharePath" "INFO"
                return @{type='json'; data=OkJson "Share 'SharedFiles' created at $sharePath (Full Access: Everyone)."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/services/printserver$" {
            $spooler   = Get-Service -Name Spooler -ErrorAction SilentlyContinue
            $printers  = Get-Printer -ErrorAction SilentlyContinue |
                Select-Object @{N="name";E={$_.Name}},@{N="driver";E={$_.DriverName}},@{N="port";E={$_.PortName}},@{N="shared";E={$_.Shared}}
            $jobs = Get-PrintJob -PrinterName * -ErrorAction SilentlyContinue |
                Select-Object @{N="printer";E={$_.PrinterName}},@{N="user";E={$_.UserName}},@{N="status";E={$_.JobStatus.ToString()}}
            return @{type='json'; data=ToJson @{
                spooler=$spooler.Status.ToString()
                printers=@($printers); jobs=@($jobs)
            }}
        }

        "^/api/services/remote$" {
            $rdpReg   = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server" -ErrorAction SilentlyContinue
            $rdpOn    = ($rdpReg.fDenyTSConnections -eq 0)
            $winrm    = (Get-Service -Name WinRM -ErrorAction SilentlyContinue).Status.ToString()
            try { $sessions = (query session 2>&1) | Where-Object {$_ -match "\S"} } catch { $sessions = @("N/A") }
            return @{type='json'; data=ToJson @{rdp=$rdpOn; winrm=$winrm; sessions=@($sessions)}}
        }

        # ======================================================
        # 7. NETWORK
        # ======================================================

        "^/api/network$" {
            $adapters = Get-NetAdapter | ForEach-Object {
                $ips = (Get-NetIPAddress -InterfaceIndex $_.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).IPAddress
                $gw  = (Get-NetRoute -InterfaceIndex $_.ifIndex -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue | Select-Object -First 1).NextHop
                $spd = $_.ReceiveLinkSpeed; $spdM = if($spd -gt 0){[math]::Round($spd/1000000,0)}else{0}
                @{name=$_.Name; status=$_.Status.ToString(); mac=$_.MacAddress; ip=($ips -join ", "); gw=$gw; speedMbps=$spdM}
            }
            $gw = (Get-NetRoute -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue | Sort-Object RouteMetric | Select-Object -First 1).NextHop
            $dns = Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                Where-Object {$_.ServerAddresses.Count -gt 0} |
                Select-Object @{N="iface";E={$_.InterfaceAlias}},@{N="servers";E={$_.ServerAddresses -join ", "}}
            return @{type='json'; data=ToJson @{adapters=@($adapters); gateway=$gw; dns=@($dns)}}
        }

        "^/api/network/connections$" {
            $conns = Get-NetTCPConnection -ErrorAction SilentlyContinue |
                Where-Object {$_.State -in @("Listen","Established")} |
                Select-Object @{N="state";E={$_.State.ToString()}},
                    @{N="localAddr";E={$_.LocalAddress}},@{N="localPort";E={$_.LocalPort}},
                    @{N="remoteAddr";E={$_.RemoteAddress}},@{N="remotePort";E={$_.RemotePort}},
                    @{N="process";E={(Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).Name}} |
                Sort-Object state, localPort
            return @{type='json'; data=ToJson @($conns)}
        }

        "^/api/network/ping$" {
            try {
                $req = $body | ConvertFrom-Json
                # Force targets to a plain string array regardless of how JSON deserialized it
                $rawTargets = if ($req.targets) { $req.targets } else { @("8.8.8.8","1.1.1.1") }
                $targets = @($rawTargets) | ForEach-Object { "$_" } | Where-Object { $_ -ne "" }
                if (-not $targets) { $targets = @("8.8.8.8","1.1.1.1") }

                $items = @()
                foreach ($t in $targets) {
                    $ht = $t.Trim()
                    try {
                        $r = Test-Connection -ComputerName $ht -Count 3 -ErrorAction Stop
                        $times = @($r) | ForEach-Object {
                            $rt = $_.ResponseTime; if ($rt -eq $null) { $rt = $_.Latency }
                            if ($rt -eq $null) { $rt = 0 }; [int]$rt
                        }
                        $avg = [math]::Round(($times | Measure-Object -Average).Average, 1)
                        $items += "{`"host`":`"$ht`",`"ok`":true,`"ms`":$avg}"
                    } catch {
                        $items += "{`"host`":`"$ht`",`"ok`":false,`"ms`":0}"
                    }
                }
                $json = "[" + ($items -join ",") + "]"
                return @{type='json'; data=$json}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/network/dns$" {
            try {
                $req = $body | ConvertFrom-Json
                $rawNames = if ($req.names) { $req.names } else { @("google.com","microsoft.com") }
                $names = @($rawNames) | ForEach-Object { "$_" } | Where-Object { $_ -ne "" }
                if (-not $names) { $names = @("google.com","microsoft.com") }

                $items = @()
                foreach ($n in $names) {
                    $hn = $n.Trim()
                    try {
                        $r = Resolve-DnsName -Name $hn -ErrorAction Stop
                        $ips = @($r | Where-Object { $null -ne $_.IPAddress } | ForEach-Object { "$($_.IPAddress)" } | Select-Object -First 5)
                        if (-not $ips) { $ips = @($r | Where-Object { $null -ne $_.NameHost } | ForEach-Object { "$($_.NameHost)" } | Select-Object -First 2) }
                        $ipList = ($ips | Where-Object { $_ -ne "" }) -join ", "
                        $items += "{`"name`":`"$hn`",`"ok`":true,`"ips`":`"$ipList`"}"
                    } catch {
                        $items += "{`"name`":`"$hn`",`"ok`":false,`"ips`":`"`"}"
                    }
                }
                $json = "[" + ($items -join ",") + "]"
                return @{type='json'; data=$json}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/network/arp$" {
            $arp = Get-NetNeighbor -ErrorAction SilentlyContinue |
                Where-Object {$_.State -ne "Unreachable" -and $_.LinkLayerAddress -ne "00-00-00-00-00-00"} |
                Select-Object @{N="ip";E={$_.IPAddress}},@{N="mac";E={$_.LinkLayerAddress}},@{N="state";E={$_.State.ToString()}},@{N="iface";E={$_.InterfaceAlias}} |
                Sort-Object iface, ip
            return @{type='json'; data=ToJson @($arp)}
        }

        "^/api/network/routes$" {
            $routes = Get-NetRoute -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                Select-Object @{N="dest";E={$_.DestinationPrefix}},@{N="gw";E={$_.NextHop}},@{N="metric";E={$_.RouteMetric}},@{N="iface";E={$_.InterfaceAlias}} |
                Sort-Object metric
            return @{type='json'; data=ToJson @($routes)}
        }

        # ======================================================
        # 8. BACKUP
        # ======================================================

        "^/api/backup/list$" {
            $backupBase = $Global:BackupDir
            $result = @{}
            foreach ($type in @("Full","Incremental","Differential")) {
                $dir = Join-Path $backupBase $type
                if (Test-Path $dir) {
                    $items = Get-ChildItem -Path $dir -Directory | Sort-Object CreationTime -Descending | ForEach-Object {
                        $mf = Join-Path $_.FullName "backup_manifest.json"
                        $info = if(Test-Path $mf){Get-Content $mf -Raw | ConvertFrom-Json}else{$null}
                        @{folder=$_.Name; path=$_.FullName; date=$_.CreationTime.ToString("yyyy-MM-dd HH:mm");
                          files=if($info){$info.FileCount}else{"?"};
                          sizeMB=if($info){[math]::Round($info.TotalSize/1MB,1)}else{"?"}}
                    }
                    $result[$type] = @($items)
                } else { $result[$type] = @() }
            }
            $stateFile = Join-Path $Global:LogDir "backup_state.json"
            $state = if(Test-Path $stateFile){Get-Content $stateFile -Raw | ConvertFrom-Json}else{@{LastFull=$null;LastIncremental=$null}}
            return @{type='json'; data=ToJson @{backups=$result; state=$state}}
        }

        "^/api/backup/run$" {
            try {
                $req    = $body | ConvertFrom-Json
                $type   = $req.type   # Full | Incremental | Differential
                $source = if($req.source -and (Test-Path $req.source)){$req.source}else{$Global:ProjectRoot}

                $stateFile = Join-Path $Global:LogDir "backup_state.json"
                $state = if(Test-Path $stateFile){Get-Content $stateFile -Raw | ConvertFrom-Json}else{[PSCustomObject]@{LastFull=$null;LastIncremental=$null}}

                if ($type -ne "Full" -and -not $state.LastFull) {
                    return @{type='json'; data=ErrJson "No previous full backup found. Run a Full backup first."}
                }

                $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm"
                $dest = Join-Path (Join-Path $Global:BackupDir $type) "backup_$timestamp"
                New-Item -ItemType Directory -Path $dest -Force | Out-Null

                $startTime = Get-Date
                $refDate = switch($type){
                    "Full"          {$null}
                    "Incremental"   {if($state.LastIncremental){[datetime]$state.LastIncremental}else{[datetime]$state.LastFull}}
                    "Differential"  {[datetime]$state.LastFull}
                }

                $files = Get-ChildItem -Path $source -Recurse -File -ErrorAction SilentlyContinue
                if ($refDate) { $files = $files | Where-Object {$_.LastWriteTime -gt $refDate} }

                $count = 0
                foreach ($f in $files) {
                    $rel  = $f.FullName.Substring($source.Length).TrimStart("\")
                    $dst  = Join-Path $dest $rel
                    $ddir = Split-Path $dst -Parent
                    if (-not (Test-Path $ddir)) { New-Item -ItemType Directory -Path $ddir -Force | Out-Null }
                    Copy-Item -Path $f.FullName -Destination $dst -Force
                    $count++
                }

                $sz = ($files | Measure-Object Length -Sum).Sum
                @{Type=$type; Source=$source; Destination=$dest; Date=(Get-Date).ToString("o");
                  FileCount=$count; TotalSize=$sz; Duration=((Get-Date)-$startTime).TotalSeconds} |
                    ConvertTo-Json | Set-Content (Join-Path $dest "backup_manifest.json")

                # Update state
                switch($type){
                    "Full"         {$state | Add-Member -Force -NotePropertyName LastFull         -NotePropertyValue (Get-Date).ToString("o")}
                    "Incremental"  {$state | Add-Member -Force -NotePropertyName LastIncremental  -NotePropertyValue (Get-Date).ToString("o")}
                    "Differential" {$state | Add-Member -Force -NotePropertyName LastDifferential -NotePropertyValue (Get-Date).ToString("o")}
                }
                $state | ConvertTo-Json | Set-Content $stateFile

                Write-Log "Dashboard: $type backup completed - $count files" "INFO"
                return @{type='json'; data=ToJson @{ok=$true; type=$type; files=$count; sizeMB=[math]::Round($sz/1MB,1); dest=$dest}}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/backup/verify$" {
            try {
                $req  = $body | ConvertFrom-Json
                $mf   = Join-Path $req.path "backup_manifest.json"
                if (-not (Test-Path $mf)) { return @{type='json'; data=ErrJson "Manifest not found."} }
                $manifest = Get-Content $mf -Raw | ConvertFrom-Json
                $actual   = Get-ChildItem -Path $req.path -Recurse -File | Where-Object {$_.Name -ne "backup_manifest.json"}
                $ok = ($actual.Count -eq $manifest.FileCount)
                return @{type='json'; data=ToJson @{ok=$ok; expected=$manifest.FileCount; found=$actual.Count; type=$manifest.Type; date=$manifest.Date}}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/backup/schedule$" {
            try {
                $req    = $body | ConvertFrom-Json
                $btype  = $req.type
                $time   = $req.time
                $launcher = Join-Path $Global:LogDir "run_backup_${btype}.ps1"
                ". '$Global:ProjectRoot\Config.ps1'`n. '$Global:ProjectRoot\Modules\8_Backup.ps1'`nStart-$(if($btype -eq 'Full'){'FullBackup'}else{'IncrementalBackup'})" | Set-Content $launcher
                $action   = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NonInteractive -File `"$launcher`""
                $trigger  = New-ScheduledTaskTrigger -Daily -At $time
                $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable
                Register-ScheduledTask -TaskName "SysAdmin_Backup_$btype" -Action $action -Trigger $trigger -Settings $settings -RunLevel Highest -Force | Out-Null
                return @{type='json'; data=OkJson "$btype backup scheduled daily at $time."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/backup/restore$" {
            try {
                $req = $body | ConvertFrom-Json
                $backupPath = $req.path
                $dest = $req.destination

                if (-not (Test-Path $backupPath)) { return @{type='json'; data=ErrJson "Backup path not found."} }

                # Read manifest for default destination
                $mPath = Join-Path $backupPath "backup_manifest.json"
                if ([string]::IsNullOrWhiteSpace($dest) -and (Test-Path $mPath)) {
                    $m = Get-Content $mPath -Raw | ConvertFrom-Json
                    $dest = $m.Source
                }
                if ([string]::IsNullOrWhiteSpace($dest)) { return @{type='json'; data=ErrJson "No destination specified."} }

                $files = Get-ChildItem -Path $backupPath -Recurse -File | Where-Object { $_.Name -ne "backup_manifest.json" }
                $count = 0
                foreach ($file in $files) {
                    $relPath  = $file.FullName.Substring($backupPath.Length).TrimStart("\")
                    $destFile = Join-Path $dest $relPath
                    $destDir  = Split-Path $destFile -Parent
                    if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
                    Copy-Item -Path $file.FullName -Destination $destFile -Force
                    $count++
                }
                Write-ServerLog "Restore completed: $count files from $backupPath to $dest" "Green"
                return @{type='json'; data=OkJson "Restore completed: $count files restored to $dest"}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        # ======================================================
        # LOGS & REPORTS
        # ======================================================

        # ======================================================
        # LOGS & REPORTS - Full Management
        # ======================================================

        "^/api/logs$" {
            $files = Get-ChildItem -Path $Global:LogDir -Filter "*.log" -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTime -Descending | Select-Object -First 30
            if (-not $files) { return @{type='json'; data='[]'} }
            $items = @()
            foreach ($f in @($files)) {
                $n = $f.Name -replace '"','\"'
                $p = $f.FullName -replace '\\','/' -replace '"','\"'
                $d = $f.LastWriteTime.ToString("yyyy-MM-dd HH:mm")
                $s = [math]::Round($f.Length/1KB,1)
                $items += "{`"name`":`"$n`",`"path`":`"$p`",`"date`":`"$d`",`"sizeKB`":$s}"
            }
            $json = "[" + ($items -join ",") + "]"
            return @{type='json'; data=$json}
        }

        "^/api/logs/read$" {
            try {
                $req = $body | ConvertFrom-Json
                $p = $req.path -replace '/','\'
                if (-not (Test-Path $p)) { return @{type='json'; data=ErrJson "File not found."} }
                $lines = @(Get-Content $p -ErrorAction SilentlyContinue | Select-Object -Last 200)
                return @{type='json'; data=(ToJsonArray $lines)}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/logs/delete$" {
            try {
                $req = $body | ConvertFrom-Json
                $p = $req.path -replace '/','\'
                if (Test-Path $p) { Remove-Item $p -Force }
                return @{type='json'; data=OkJson "Log deleted."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/logs/clear$" {
            try {
                Get-ChildItem -Path $Global:LogDir -Filter "*.log" -ErrorAction SilentlyContinue | Remove-Item -Force
                return @{type='json'; data=OkJson "All logs cleared."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/logs/download$" {
            try {
                $req = $body | ConvertFrom-Json
                $p = $req.path -replace '/','\'
                if (-not (Test-Path $p)) { return @{type='json'; data=ErrJson "File not found."} }
                $raw = Get-Content $p -Raw -Encoding UTF8
                $escaped = $raw -replace '\\','\\' -replace '"','\"' -replace "`r`n",'\n' -replace "`n",'\n' -replace "`r",'\n' -replace "`t",'\t'
                $fname = (Split-Path $p -Leaf) -replace '"','\"'
                return @{type='json'; data="{`"content`":`"$escaped`",`"name`":`"$fname`"}"}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/reports$" {
            $files = Get-ChildItem -Path $Global:ReportDir -Filter "*.txt" -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTime -Descending | Select-Object -First 30
            if (-not $files) { return @{type='json'; data='[]'} }
            $items = @()
            foreach ($f in @($files)) {
                $n = $f.Name -replace '"','\"'
                $p = $f.FullName -replace '\\','/' -replace '"','\"'
                $d = $f.LastWriteTime.ToString("yyyy-MM-dd HH:mm")
                $s = [math]::Round($f.Length/1KB,1)
                $items += "{`"name`":`"$n`",`"path`":`"$p`",`"date`":`"$d`",`"sizeKB`":$s}"
            }
            $json = "[" + ($items -join ",") + "]"
            return @{type='json'; data=$json}
        }

        "^/api/report/read$" {
            try {
                $req = $body | ConvertFrom-Json
                $p = $req.path -replace '/','\' 
                if (-not (Test-Path $p)) { return @{type='json'; data=ErrJson "File not found."} }
                $raw = Get-Content $p -Raw -Encoding UTF8
                $escaped = $raw -replace '\\','\\' -replace '"','\"' -replace "`r`n",'\n' -replace "`n",'\n' -replace "`r",'\n' -replace "`t",'\t'
                return @{type='json'; data="{`"content`":`"$escaped`"}"}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/reports/delete$" {
            try {
                $req = $body | ConvertFrom-Json
                $p = $req.path -replace '/','\'
                if (Test-Path $p) { Remove-Item $p -Force }
                return @{type='json'; data=OkJson "Report deleted."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/reports/clear$" {
            try {
                Get-ChildItem -Path $Global:ReportDir -Filter "*.txt" -ErrorAction SilentlyContinue | Remove-Item -Force
                return @{type='json'; data=OkJson "All reports cleared."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/reports/download$" {
            try {
                $req = $body | ConvertFrom-Json
                $p = $req.path -replace '/','\' 
                if (-not (Test-Path $p)) { return @{type='json'; data=ErrJson "File not found."} }
                $raw = Get-Content $p -Raw -Encoding UTF8
                $escaped = $raw -replace '\\','\\' -replace '"','\"' -replace "`r`n",'\n' -replace "`n",'\n' -replace "`r",'\n' -replace "`t",'\t'
                $fname = (Split-Path $p -Leaf) -replace '"','\"'
                return @{type='json'; data="{`"content`":`"$escaped`",`"name`":`"$fname`"}"}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        # --- On-demand report generation ---
        "^/api/report/generate$" {
            try {
                $req = $body | ConvertFrom-Json
                $reportType = $req.type
                $ts = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
                $reportPath = Join-Path $Global:ReportDir "${reportType}_${ts}.txt"
                $lines = @()
                $lines += "=" * 60
                $lines += "$($reportType.ToUpper()) REPORT"
                $lines += "Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
                $lines += "Server: $env:COMPUTERNAME"
                $lines += "=" * 60
                $lines += ""

                switch ($reportType) {
                    "Processes" {
                        $procs = Get-Process | Sort-Object CPU -Descending | Select-Object -First 50 |
                            Select-Object Id, Name, @{N='CPU_s';E={[math]::Round($_.CPU,1)}}, @{N='RAM_MB';E={[math]::Round($_.WorkingSet64/1MB,1)}}
                        $lines += "TOTAL PROCESSES: $((Get-Process).Count)"
                        $lines += ""
                        $lines += "--- TOP 50 BY CPU ---"
                        $lines += ($procs | Format-Table -AutoSize | Out-String)
                    }
                    "Resources" {
                        $cpu = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
                        $os = Get-CimInstance Win32_OperatingSystem
                        $ramTotal = [math]::Round($os.TotalVisibleMemorySize/1MB,2)
                        $ramFree = [math]::Round($os.FreePhysicalMemory/1MB,2)
                        $ramUsed = $ramTotal - $ramFree
                        $ramPct = [math]::Round(($ramUsed/$ramTotal)*100,1)
                        $lines += "CPU: ${cpu}%"
                        $lines += ""
                        $lines += "RAM: ${ramUsed} GB / ${ramTotal} GB (${ramPct}%)"
                        $lines += "Free: ${ramFree} GB"
                        $lines += ""
                        $lines += "DISKS"
                        Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
                            $total = [math]::Round($_.Size/1GB,2)
                            $free = [math]::Round($_.FreeSpace/1GB,2)
                            $used = $total - $free
                            $pct = if($total -gt 0){[math]::Round(($used/$total)*100,1)}else{0}
                            $lines += "  $($_.DeviceID) Total: ${total} GB | Used: ${used} GB (${pct}%) | Free: ${free} GB"
                        }
                    }
                    "Security" {
                        $lines += "FIREWALL PROFILES"
                        Get-NetFirewallProfile | ForEach-Object { $lines += "  $($_.Name): $(if($_.Enabled){'Enabled'}else{'Disabled'})" }
                        $lines += ""
                        $lines += "RECENT SECURITY EVENTS (Last 30)"
                        $events = Get-WinEvent -LogName Security -MaxEvents 30 -ErrorAction SilentlyContinue |
                            Select-Object TimeCreated, Id, LevelDisplayName, Message
                        if ($events) { $lines += ($events | Format-Table TimeCreated, Id, LevelDisplayName -AutoSize | Out-String) }
                        else { $lines += "  No recent security events." }
                    }
                    "Network" {
                        $lines += "ACTIVE ADAPTERS"
                        Get-NetAdapter | Where-Object Status -eq 'Up' | ForEach-Object {
                            $ip = (Get-NetIPAddress -InterfaceIndex $_.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -First 1).IPAddress
                            $lines += "  $($_.Name) | IP: $ip | Speed: $($_.LinkSpeed) | MAC: $($_.MacAddress)"
                        }
                        $lines += ""
                        $lines += "DNS CONFIGURATION"
                        Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                            Where-Object ServerAddresses | ForEach-Object {
                            $lines += "  $($_.InterfaceAlias): $($_.ServerAddresses -join ', ')"
                        }
                        $lines += ""
                        $lines += "ROUTING TABLE (Default Routes)"
                        $lines += (Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue | Format-Table -AutoSize | Out-String)
                    }
                    "FileSystem" {
                        $lines += "DISK VOLUMES"
                        Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
                            $total = [math]::Round($_.Size/1GB,2)
                            $free = [math]::Round($_.FreeSpace/1GB,2)
                            $lines += "  $($_.DeviceID) Total: ${total} GB | Free: ${free} GB | Label: $($_.VolumeName)"
                        }
                        $lines += ""
                        $lines += "SHARED FOLDERS"
                        $shares = Get-SmbShare -ErrorAction SilentlyContinue | Where-Object Name -notlike '*$'
                        if ($shares) { $lines += ($shares | Format-Table Name, Path, Description -AutoSize | Out-String) }
                        else { $lines += "  No user shares found." }
                    }
                    "Services" {
                        $lines += "RUNNING SERVICES"
                        $running = Get-Service | Where-Object Status -eq 'Running' | Sort-Object DisplayName
                        $lines += "Total running: $($running.Count)"
                        $lines += ""
                        $lines += ($running | Format-Table Name, DisplayName, StartType -AutoSize | Out-String)
                        $lines += ""
                        $lines += "STOPPED (Auto-start) SERVICES"
                        $stopped = Get-Service | Where-Object { $_.Status -eq 'Stopped' -and $_.StartType -eq 'Automatic' }
                        if ($stopped) { $lines += ($stopped | Format-Table Name, DisplayName -AutoSize | Out-String) }
                        else { $lines += "  None." }
                    }
                    "Users" {
                        $lines += "LOCAL USERS"
                        $lines += (Get-LocalUser | Format-Table Name, Enabled, LastLogon, Description -AutoSize | Out-String)
                        $lines += ""
                        $lines += "LOCAL GROUPS"
                        $lines += (Get-LocalGroup | Format-Table Name, Description -AutoSize | Out-String)
                    }
                    "Backup" {
                        $lines += "BACKUP DIRECTORY CONTENTS"
                        $bkDir = Join-Path $Global:ProjectRoot "Backups"
                        foreach ($sub in @("Full","Incremental","Differential")) {
                            $subPath = Join-Path $bkDir $sub
                            $files = Get-ChildItem -Path $subPath -ErrorAction SilentlyContinue
                            $lines += ""
                            $lines += "--- $sub ---"
                            if ($files) {
                                $files | ForEach-Object { $lines += "  $($_.Name)  ($([math]::Round($_.Length/1KB,1)) KB)  $($_.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))" }
                            } else { $lines += "  (empty)" }
                        }
                    }
                    "ServerConfig" {
                        $cs = Get-CimInstance Win32_ComputerSystem
                        $os = Get-CimInstance Win32_OperatingSystem
                        $lines += "HOSTNAME: $($cs.Name)"
                        $lines += "DOMAIN: $(if($cs.PartOfDomain){$cs.Domain}else{'WORKGROUP'})"
                        $lines += "OS: $($os.Caption) $($os.Version)"
                        $lines += "TIMEZONE: $((Get-TimeZone).Id)"
                        $lines += ""
                        $lines += "NETWORK INTERFACES"
                        Get-NetAdapter | Where-Object Status -eq 'Up' | ForEach-Object {
                            $ip = (Get-NetIPAddress -InterfaceIndex $_.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -First 1).IPAddress
                            $lines += "  $($_.Name): $ip"
                        }
                        $lines += ""
                        $rdpVal = (Get-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -ErrorAction SilentlyContinue).fDenyTSConnections
                        $lines += "RDP: $(if($rdpVal -eq 0){'Enabled'}else{'Disabled'})"
                        $lines += ""
                        $lines += "FIREWALL"
                        Get-NetFirewallProfile | ForEach-Object { $lines += "  $($_.Name): $(if($_.Enabled){'ON'}else{'OFF'})" }
                    }
                    default { $lines += "Unknown report type: $reportType" }
                }

                $lines | Set-Content -Path $reportPath -Encoding UTF8
                Write-ServerLog "Report generated: $reportPath" "Green"
                return @{type='json'; data=ToJson @{ok=$true; msg="Report generated: $(Split-Path $reportPath -Leaf)"; name=(Split-Path $reportPath -Leaf)}}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        # --- Schedule management ---
        "^/api/schedule/list$" {
            $schedFile = Join-Path $Global:ProjectRoot "schedules.json"
            if (Test-Path $schedFile) {
                $content = Get-Content $schedFile -Raw -Encoding UTF8
                return @{type='json'; data=$content}
            }
            return @{type='json'; data='[]'}
        }

        "^/api/schedule/add$" {
            try {
                $req = $body | ConvertFrom-Json
                $schedFile = Join-Path $Global:ProjectRoot "schedules.json"
                $schedules = @()
                if (Test-Path $schedFile) {
                    $existing = Get-Content $schedFile -Raw -Encoding UTF8 | ConvertFrom-Json
                    if ($existing) { $schedules = @($existing) }
                }
                $newSched = @{
                    id        = [guid]::NewGuid().ToString().Substring(0,8)
                    type      = $req.type
                    mode      = $req.mode
                    interval  = $req.interval
                    time      = $req.time
                    nextRun   = ""
                    lastRun   = ""
                    enabled   = $true
                    created   = (Get-Date -Format "yyyy-MM-dd HH:mm")
                }
                # Calculate next run
                if ($req.mode -eq "interval") {
                    $newSched.nextRun = (Get-Date).AddMinutes([int]$req.interval).ToString("yyyy-MM-dd HH:mm")
                } elseif ($req.mode -eq "daily") {
                    $today = Get-Date
                    $runTime = [DateTime]::ParseExact($req.time, "HH:mm", $null)
                    $nextRun = Get-Date -Year $today.Year -Month $today.Month -Day $today.Day -Hour $runTime.Hour -Minute $runTime.Minute -Second 0
                    if ($nextRun -lt $today) { $nextRun = $nextRun.AddDays(1) }
                    $newSched.nextRun = $nextRun.ToString("yyyy-MM-dd HH:mm")
                }
                $schedules += $newSched
                $json = ConvertTo-Json @($schedules) -Depth 4
                if (@($schedules).Count -eq 1) { $json = "[$json]" }
                $json | Set-Content $schedFile -Encoding UTF8
                return @{type='json'; data=OkJson "Schedule created."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/schedule/remove$" {
            try {
                $req = $body | ConvertFrom-Json
                $schedFile = Join-Path $Global:ProjectRoot "schedules.json"
                if (Test-Path $schedFile) {
                    $schedules = @(Get-Content $schedFile -Raw -Encoding UTF8 | ConvertFrom-Json)
                    $schedules = @($schedules | Where-Object { $_.id -ne $req.id })
                    if ($schedules.Count -gt 0) {
                        $json = ConvertTo-Json @($schedules) -Depth 4
                        if (@($schedules).Count -eq 1) { $json = "[$json]" }
                        $json | Set-Content $schedFile -Encoding UTF8
                    } else {
                        Remove-Item $schedFile -Force
                    }
                }
                return @{type='json'; data=OkJson "Schedule removed."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        # ======================================================
        # SERVER CONFIG (Module 9)
        # ======================================================

        "^/api/serverconfig$" {
            try {
                $cs = Get-CimInstance Win32_ComputerSystem
                $os = Get-CimInstance Win32_OperatingSystem
                $tz = Get-TimeZone

                # Interfaces
                [array]$ifaces = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }
                $ifList = @()
                $mainIP = $null; $mainPrefix = $null; $mainGW = $null; $mainDNS = @(); $mainDHCP = "N/A"; $mainIfName = $null

                foreach ($iface in $ifaces) {
                    $ipObj = Get-NetIPAddress -InterfaceIndex $iface.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                             Where-Object { $_.IPAddress -notlike "169.254.*" } | Select-Object -First 1
                    $ifList += @{ name=$iface.Name; ip=if($ipObj){$ipObj.IPAddress}else{$null} }

                    if (-not $mainIP -and $ipObj) {
                        $mainIP = $ipObj.IPAddress
                        $mainPrefix = $ipObj.PrefixLength
                        $mainIfName = $iface.Name
                        $mainGW = (Get-NetRoute -InterfaceIndex $iface.ifIndex -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue | Select-Object -First 1).NextHop
                        $mainDNS = @((Get-DnsClientServerAddress -InterfaceIndex $iface.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).ServerAddresses)
                        $mainDHCP = (Get-NetIPInterface -InterfaceIndex $iface.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).Dhcp
                    }
                }

                # RDP
                $rdpVal = (Get-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -ErrorAction SilentlyContinue).fDenyTSConnections
                $rdpOn = ($rdpVal -eq 0)

                # Firewall
                $fwProfiles = Get-NetFirewallProfile | ForEach-Object { @{ name=$_.Name; enabled=[bool]$_.Enabled } }

                $data = @{
                    hostname      = $cs.Name
                    domain        = $cs.Domain
                    inDomain      = $cs.PartOfDomain
                    os            = $os.Caption
                    ip            = $mainIP
                    prefix        = $mainPrefix
                    gateway       = $mainGW
                    dnsServers    = $mainDNS
                    dhcp          = "$mainDHCP"
                    interfaceName = $mainIfName
                    timezone      = $tz.Id
                    rdpEnabled    = $rdpOn
                    firewall      = @($fwProfiles)
                    interfaces    = @($ifList)
                    ramGB         = [math]::Round($os.TotalVisibleMemorySize/1MB, 1)
                }
                return @{type='json'; data=ToJson $data}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/serverconfig/hostname$" {
            try {
                $req = $body | ConvertFrom-Json
                $newName = $req.name
                if (-not $newName) { return @{type='json'; data=ErrJson "Empty name."} }
                if ($newName -match '[^a-zA-Z0-9\-]') { return @{type='json'; data=ErrJson "Invalid name. Use only letters, numbers and hyphens."} }
                Rename-Computer -NewName $newName -Force
                Write-Log "Hostname changed to '$newName' via dashboard." "INFO"
                return @{type='json'; data=OkJson "Hostname changed to '$newName'. Restart required."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/serverconfig/ip$" {
            try {
                $req = $body | ConvertFrom-Json
                $ifName = $req.iface
                $newIP  = $req.ip
                $prefix = [int]$req.prefix
                $gw     = $req.gateway
                $dns1   = $req.dns1
                $dns2   = $req.dns2

                if (-not $newIP -or -not $gw) { return @{type='json'; data=ErrJson "IP and Gateway are required."} }

                # Convert prefix to subnet mask
                $maskBin = ('1' * $prefix).PadRight(32, '0')
                $subnetMask = [string]::Join('.', @(
                    [Convert]::ToInt32($maskBin.Substring(0, 8), 2),
                    [Convert]::ToInt32($maskBin.Substring(8, 8), 2),
                    [Convert]::ToInt32($maskBin.Substring(16, 8), 2),
                    [Convert]::ToInt32($maskBin.Substring(24, 8), 2)
                ))

                netsh interface ipv4 set address name="$ifName" static $newIP $subnetMask $gw 2>&1 | Out-Null
                netsh interface ipv4 set dns name="$ifName" static $dns1 primary 2>&1 | Out-Null
                if ($dns2) { netsh interface ipv4 add dns name="$ifName" $dns2 index=2 2>&1 | Out-Null }

                Write-Log "IP configured: $ifName -> $newIP/$prefix GW:$gw DNS:$dns1 via dashboard." "INFO"
                return @{type='json'; data=OkJson "IP configured: $newIP/$prefix (GW: $gw)"}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/serverconfig/timezone$" {
            try {
                $req = $body | ConvertFrom-Json
                Set-TimeZone -Id $req.timezone
                Write-Log "Timezone changed to '$($req.timezone)' via dashboard." "INFO"
                return @{type='json'; data=OkJson "Timezone changed to '$($req.timezone)'."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/serverconfig/domain/create$" {
            try {
                $req = $body | ConvertFrom-Json
                if (-not $req.domain -or -not $req.netbios) { return @{type='json'; data=ErrJson "Domain and NETBIOS are required."} }

                Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools -ErrorAction Stop | Out-Null

                # Generate a temporary DSRM password
                $dsrmPass = ConvertTo-SecureString "P@ssw0rd2026!" -AsPlainText -Force

                Install-ADDSForest `
                    -DomainName $req.domain `
                    -DomainNetbiosName $req.netbios `
                    -SafeModeAdministratorPassword $dsrmPass `
                    -InstallDns:$true `
                    -CreateDnsDelegation:$false `
                    -NoRebootOnCompletion:$true `
                    -Force:$true | Out-Null

                Write-Log "Domain '$($req.domain)' created via dashboard. Restart pending." "INFO"
                return @{type='json'; data=OkJson "Domain '$($req.domain)' created! Restart the server to complete."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/serverconfig/domain/join$" {
            try {
                $req = $body | ConvertFrom-Json
                if (-not $req.domain) { return @{type='json'; data=ErrJson "Domain is required."} }
                return @{type='json'; data=ErrJson "Joining a domain requires interactive credentials. Use module 9 in PowerShell (MainMenu > 9 > 2)."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/serverconfig/rdp$" {
            try {
                $req = $body | ConvertFrom-Json
                if ($req.enable) {
                    Set-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -Value 0
                    Enable-NetFirewallRule -DisplayGroup "Remote Desktop" -ErrorAction SilentlyContinue
                    Set-NetFirewallRule -Name "RemoteDesktop-UserMode-In-TCP" -Enabled True -ErrorAction SilentlyContinue
                    Write-Log "RDP enabled via dashboard." "INFO"
                    return @{type='json'; data=OkJson "Remote Desktop enabled."}
                } else {
                    Set-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -Value 1
                    Disable-NetFirewallRule -DisplayGroup "Remote Desktop" -ErrorAction SilentlyContinue
                    Write-Log "RDP disabled via dashboard." "INFO"
                    return @{type='json'; data=OkJson "Remote Desktop disabled."}
                }
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/serverconfig/firewall/toggle$" {
            try {
                $req = $body | ConvertFrom-Json
                $state = [bool]$req.enable
                Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled $state
                $action = if($state){"enabled"}else{"disabled"}
                Write-Log "Firewall $action via dashboard." $(if($state){"INFO"}else{"WARN"})
                return @{type='json'; data=OkJson "Firewall $action on all profiles."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/serverconfig/firewall/rule$" {
            try {
                $req = $body | ConvertFrom-Json
                if (-not $req.name -or -not $req.port) { return @{type='json'; data=ErrJson "Name and port are required."} }
                New-NetFirewallRule -DisplayName $req.name -Direction Inbound -Protocol $req.protocol -LocalPort $req.port -Action Allow | Out-Null
                Write-Log "Firewall rule created: $($req.name) ($($req.port)/$($req.protocol)) via dashboard." "INFO"
                return @{type='json'; data=OkJson "Rule '$($req.name)' created ($($req.port)/$($req.protocol))."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/serverconfig/dns/record$" {
            try {
                $req = $body | ConvertFrom-Json
                if (-not $req.zone -or -not $req.host -or -not $req.ip) { return @{type='json'; data=ErrJson "Zone, hostname and IP are required."} }
                Add-DnsServerResourceRecordA -ZoneName $req.zone -Name $req.host -IPv4Address $req.ip -ErrorAction Stop
                Write-Log "DNS record created: $($req.host).$($req.zone) -> $($req.ip) via dashboard." "INFO"
                return @{type='json'; data=OkJson "A record created: $($req.host).$($req.zone) -> $($req.ip)"}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        # -- ROLES & FEATURES --

        "^/api/serverconfig/roles$" {
            try {
                $all = Get-WindowsFeature -ErrorAction Stop
                $list = $all | ForEach-Object {
                    @{
                        name        = $_.Name
                        displayName = $_.DisplayName
                        type        = "$($_.FeatureType)"
                        installed   = [bool]$_.Installed
                        parent      = "$($_.Parent)"
                    }
                }
                return @{type='json'; data=ToJson @{roles=@($list)}}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/serverconfig/roles/search$" {
            try {
                $req = $body | ConvertFrom-Json
                $q = $req.query
                if (-not $q) { return @{type='json'; data=ErrJson "Query is required."} }
                $results = Get-WindowsFeature -ErrorAction Stop |
                    Where-Object { $_.DisplayName -like "*$q*" -or $_.Name -like "*$q*" } |
                    Sort-Object @{Expression={$_.Installed};Descending=$true}, FeatureType, DisplayName |
                    Select-Object -First 30 |
                    ForEach-Object {
                        @{
                            name        = $_.Name
                            displayName = $_.DisplayName
                            type        = "$($_.FeatureType)"
                            installed   = [bool]$_.Installed
                        }
                    }
                return @{type='json'; data=ToJson @{results=@($results)}}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/serverconfig/roles/install$" {
            try {
                $req = $body | ConvertFrom-Json
                if (-not $req.name) { return @{type='json'; data=ErrJson "Feature name is required."} }

                $feature = Get-WindowsFeature -Name $req.name -ErrorAction SilentlyContinue
                if (-not $feature) { return @{type='json'; data=ErrJson "Feature '$($req.name)' not found."} }
                if ($feature.Installed) { return @{type='json'; data=ErrJson "'$($feature.DisplayName)' is already installed."} }

                $params = @{ Name = $req.name; ErrorAction = "Stop" }
                if ($req.includeTools) { $params["IncludeManagementTools"] = $true }

                $result = Install-WindowsFeature @params
                $restartMsg = if ($result.RestartNeeded -eq "Yes") { " Restart required." } else { "" }

                Write-Log "Role/Feature installed via dashboard: $($feature.DisplayName) ($($req.name))" "INFO"
                return @{type='json'; data=ToJson @{ok=$true; msg="'$($feature.DisplayName)' installed successfully.$restartMsg"; restartNeeded=($result.RestartNeeded -eq "Yes")}}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/serverconfig/roles/remove$" {
            try {
                $req = $body | ConvertFrom-Json
                if (-not $req.name) { return @{type='json'; data=ErrJson "Feature name is required."} }

                $feature = Get-WindowsFeature -Name $req.name -ErrorAction SilentlyContinue
                if (-not $feature) { return @{type='json'; data=ErrJson "Feature '$($req.name)' not found."} }
                if (-not $feature.Installed) { return @{type='json'; data=ErrJson "'$($feature.DisplayName)' is not installed."} }

                $result = Remove-WindowsFeature -Name $req.name -ErrorAction Stop
                $restartMsg = if ($result.RestartNeeded -eq "Yes") { " Restart required." } else { "" }

                Write-Log "Role/Feature removed via dashboard: $($feature.DisplayName) ($($req.name))" "WARN"
                return @{type='json'; data=ToJson @{ok=$true; msg="'$($feature.DisplayName)' removed.$restartMsg"; restartNeeded=($result.RestartNeeded -eq "Yes")}}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        # ======================================================
        # VIRTUALIZATION (HYPER-V)
        # ======================================================

        "^/api/vms$" {
            try {
                $hvInstalled = (Get-WindowsFeature -Name Hyper-V -ErrorAction SilentlyContinue).Installed
                if (-not $hvInstalled) {
                    return @{type='json'; data=ToJson @{installed=$false; vms=@()}}
                }
                $vms = Get-VM -ErrorAction SilentlyContinue | ForEach-Object {
                    $snaps = (Get-VMSnapshot -VMName $_.Name -ErrorAction SilentlyContinue | Measure-Object).Count
                    @{
                        name       = $_.Name
                        state      = "$($_.State)"
                        cpu        = $_.ProcessorCount
                        ramMB      = [math]::Round($_.MemoryStartupBytes / 1MB)
                        ramAssigned = [math]::Round($_.MemoryAssigned / 1MB)
                        generation = $_.Generation
                        uptime     = if($_.Uptime.TotalSeconds -gt 0){"{0:hh\:mm\:ss}" -f $_.Uptime}else{"-"}
                        snapshots  = $snaps
                        path       = $_.Path
                    }
                }
                $vmHost = Get-VMHost -ErrorAction SilentlyContinue
                return @{type='json'; data=ToJson @{
                    installed=$true
                    vms=@($vms)
                    defaultPath=if($vmHost){$vmHost.VirtualMachinePath}else{""}
                    switches=@(Get-VMSwitch -ErrorAction SilentlyContinue | ForEach-Object { $_.Name })
                }}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/vms/create$" {
            try {
                $req = $body | ConvertFrom-Json
                if (-not $req.name) { return @{type='json'; data=ErrJson "VM name is required."} }
                $name   = $req.name
                $gen    = if($req.generation){[int]$req.generation}else{2}
                $ramMB  = if($req.ramMB){[int]$req.ramMB}else{2048}
                $diskGB = if($req.diskGB){[int]$req.diskGB}else{40}

                $vmPath = (Get-VMHost).VirtualMachinePath
                $vhdPath = Join-Path $vmPath "$name\Virtual Hard Disks\$name.vhdx"

                $params = @{
                    Name = $name; Generation = $gen
                    MemoryStartupBytes = $ramMB * 1MB
                    NewVHDPath = $vhdPath; NewVHDSizeBytes = $diskGB * 1GB
                    ErrorAction = "Stop"
                }
                if ($req.switchName) { $params["SwitchName"] = $req.switchName }

                if (Test-Path $vhdPath) {
    			Remove-Item -Path $vhdPath -Force -ErrorAction SilentlyContinue
		}
		New-VM @params | Out-Null
                Write-Log "VM created via dashboard: $name (Gen $gen, $ramMB MB, $diskGB GB)" "INFO"
                return @{type='json'; data=OkJson "VM '$name' created (Gen $gen, $ramMB MB RAM, $diskGB GB disk)."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/vms/start$" {
            try {
                $req = $body | ConvertFrom-Json
                Start-VM -Name $req.name -ErrorAction Stop
                Write-Log "VM started via dashboard: $($req.name)" "INFO"
                return @{type='json'; data=OkJson "VM '$($req.name)' started."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/vms/stop$" {
            try {
                $req = $body | ConvertFrom-Json
                Stop-VM -Name $req.name -Force -ErrorAction Stop
                Write-Log "VM stopped via dashboard: $($req.name)" "INFO"
                return @{type='json'; data=OkJson "VM '$($req.name)' stopped."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/vms/snapshot$" {
            try {
                $req = $body | ConvertFrom-Json
                $snapName = if($req.snapName){$req.snapName}else{"Snapshot_$(Get-Date -Format 'yyyyMMdd_HHmmss')"}
                Checkpoint-VM -Name $req.name -SnapshotName $snapName -ErrorAction Stop
                Write-Log "Snapshot created via dashboard: $snapName on $($req.name)" "INFO"
                return @{type='json'; data=OkJson "Snapshot '$snapName' created for '$($req.name)'."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/vms/snapshots$" {
            try {
                $req = $body | ConvertFrom-Json
                $snaps = Get-VMSnapshot -VMName $req.name -ErrorAction SilentlyContinue | ForEach-Object {
                    @{ name=$_.Name; created=$_.CreationTime.ToString("yyyy-MM-dd HH:mm"); type="$($_.SnapshotType)" }
                }
                return @{type='json'; data=ToJson @{snapshots=@($snaps)}}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/vms/snapshot/restore$" {
            try {
                $req = $body | ConvertFrom-Json
                Restore-VMSnapshot -VMName $req.name -Name $req.snapName -Confirm:$false -ErrorAction Stop
                Write-Log "VM '$($req.name)' restored to snapshot '$($req.snapName)' via dashboard." "INFO"
                return @{type='json'; data=OkJson "VM '$($req.name)' restored to '$($req.snapName)'."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/vms/snapshot/delete$" {
            try {
                $req = $body | ConvertFrom-Json
                Remove-VMSnapshot -VMName $req.name -Name $req.snapName -ErrorAction Stop
                Write-Log "Snapshot deleted via dashboard: $($req.snapName) from $($req.name)" "WARN"
                return @{type='json'; data=OkJson "Snapshot '$($req.snapName)' deleted."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/vms/delete$" {
            try {
                $req = $body | ConvertFrom-Json
                $vm = Get-VM -Name $req.name -ErrorAction Stop
                if ($vm.State -ne 'Off') { Stop-VM -Name $req.name -Force -ErrorAction SilentlyContinue; Start-Sleep -Seconds 2 }
                $vmPath = $vm.Path
                Remove-VM -Name $req.name -Force -ErrorAction Stop
                if ($vmPath -and (Test-Path $vmPath)) { Remove-Item -Path $vmPath -Recurse -Force -ErrorAction SilentlyContinue }
                Write-Log "VM deleted via dashboard: $($req.name)" "WARN"
                return @{type='json'; data=OkJson "VM '$($req.name)' deleted."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/vms/export$" {
            try {
                $req = $body | ConvertFrom-Json
                $exportPath = if($req.path){$req.path}else{Join-Path $Global:BackupDir "VM_Exports"}
                if (-not (Test-Path $exportPath)) { New-Item -ItemType Directory -Path $exportPath -Force | Out-Null }
                Export-VM -Name $req.name -Path $exportPath -ErrorAction Stop
                Write-Log "VM exported via dashboard: $($req.name) -> $exportPath" "INFO"
                return @{type='json'; data=OkJson "VM '$($req.name)' exported to '$exportPath'."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/vms/attach-iso$" {
            try {
                $req = $body | ConvertFrom-Json
                $vmName = $req.name
                $isoPath = $req.isoPath
                if (-not (Test-Path $isoPath)) {
                    return @{type='json'; data=ErrJson "ISO file not found: $isoPath"}
                }
                # Check if DVD drive exists, add if not
                $dvd = Get-VMDvdDrive -VMName $vmName -ErrorAction SilentlyContinue
                if (-not $dvd) {
                    Add-VMDvdDrive -VMName $vmName -ErrorAction Stop
                    $dvd = Get-VMDvdDrive -VMName $vmName
                }
                Set-VMDvdDrive -VMName $vmName -ControllerNumber $dvd.ControllerNumber -ControllerLocation $dvd.ControllerLocation -Path $isoPath -ErrorAction Stop
                Write-Log "ISO attached to VM '$vmName': $isoPath" "INFO"
                # Set DVD Drive as first boot device
                $dvdBoot = Get-VMDvdDrive -VMName $vmName -ErrorAction SilentlyContinue
                if ($dvdBoot) {
                    Set-VMFirmware -VMName $vmName -FirstBootDevice $dvdBoot -ErrorAction SilentlyContinue
                }
                return @{type='json'; data=OkJson "ISO attached to '$vmName' successfully."}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        "^/api/vms/open-manager$" {
            try {
                Start-Process "virtmgmt.msc" -ErrorAction Stop
                return @{type='json'; data=OkJson "Hyper-V Manager opened."}
            } catch { return @{type='json'; data=ErrJson "Could not open Hyper-V Manager: $($_.Exception.Message)"} }
        }
        
        "^/api/vms/install-hyperv$" {
            try {
                $feature = Get-WindowsFeature -Name Hyper-V -ErrorAction SilentlyContinue
                if ($feature -and $feature.Installed) {
                    return @{type='json'; data=ToJson @{ok=$true; msg="Hyper-V already installed."; restartNeeded=$false}}
                }
                # Run in background so the HTTP server doesn't block
                Start-Job -ScriptBlock {
                    Install-WindowsFeature -Name Hyper-V -IncludeManagementTools
                } | Out-Null
                Write-Log "Hyper-V installation started in background via dashboard." "INFO"
                return @{type='json'; data=ToJson @{ok=$true; msg="Hyper-V installation started. This takes 2-4 minutes. The page will refresh automatically."; restartNeeded=$true; pending=$true}}
            } catch { return @{type='json'; data=ErrJson $_.Exception.Message} }
        }

        default {
            return @{type='json'; data=ToJson @{error="Endpoint not found: $path"}}
        }
    }
}

# -- MAIN LOOP ----------------------------------------------
Write-ServerLog "Server started. Waiting for requests..." "Green"

while ($listener.IsListening) {
    try {
        $ctx     = $listener.GetContext()
        $req     = $ctx.Request
        $res     = $ctx.Response
        $urlPath = $req.Url.AbsolutePath
        $method  = $req.HttpMethod
        $bodyStr = ""

        if ($method -eq "POST" -and $req.HasEntityBody) {
            $reader  = [System.IO.StreamReader]::new($req.InputStream, $req.ContentEncoding)
            $bodyStr = $reader.ReadToEnd()
            $reader.Close()
        }

        if ($urlPath -notmatch "favicon") { Write-ServerLog "$method $urlPath" }

        $res.Headers.Add("Access-Control-Allow-Origin","*")
        $res.Headers.Add("Access-Control-Allow-Methods","GET, POST, OPTIONS")
        $res.Headers.Add("Access-Control-Allow-Headers","Content-Type")

        if ($method -eq "OPTIONS") { $res.StatusCode = 204; $res.Close(); continue }

        $result      = Invoke-API -path $urlPath -method $method -body $bodyStr
        $contentType = if($result.type -eq "html"){"text/html; charset=utf-8"}else{"application/json; charset=utf-8"}
        $payload     = if ($result.data) { $result.data } else { '{}' }
        $bytes       = [System.Text.Encoding]::UTF8.GetBytes($payload)
        $res.ContentType     = $contentType
        $res.ContentLength64 = $bytes.Length
        $res.OutputStream.Write($bytes,0,$bytes.Length)
        $res.Close()

    } catch [System.Net.HttpListenerException] { break
    } catch { Write-ServerLog "Error: $($_.Exception.Message)" "Red"; try{$ctx.Response.StatusCode=500;$ctx.Response.Close()}catch{} }
}

try { $listener.Stop() } catch {}
Write-ServerLog "Server stopped." "Yellow"
