# =============================================================================
# Modules/8_Backup.ps1 - Backup and Recovery
# Full | Incremental | Differential | Integrity check | Restore
# =============================================================================

. "$Global:ProjectRoot\Config.ps1"

# State file to track last full backup date (for incremental/differential logic)
$BackupStateFile = Join-Path $Global:LogDir "backup_state.json"

function Get-BackupState {
    if (Test-Path $BackupStateFile) {
        return (Get-Content $BackupStateFile -Raw | ConvertFrom-Json)
    }
    return [PSCustomObject]@{ LastFull = $null; LastIncremental = $null }
}

function Save-BackupState {
    param([string]$Type)
    $state = Get-BackupState
    switch ($Type) {
        "Full"          { $state.LastFull          = (Get-Date).ToString("o") }
        "Incremental"   { $state.LastIncremental   = (Get-Date).ToString("o") }
        "Differential"  { $state.LastDifferential  = (Get-Date).ToString("o") }
    }
    $state | ConvertTo-Json | Set-Content $BackupStateFile
}

function Get-BackupDestination {
    param([string]$Type)
    $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm"
    $dest = Join-Path $Global:BackupDir "$Type\backup_$timestamp"
    New-Item -ItemType Directory -Path $dest -Force | Out-Null
    return $dest
}

# =============================================================================
# 1. Full backup
# =============================================================================
function Start-FullBackup {
    Show-Header "FULL BACKUP"

    Write-Host "  Source (folder to back up, Enter = C:\SysAdmin\): " -NoNewline -ForegroundColor Cyan
    $source = Read-Host
    if ([string]::IsNullOrWhiteSpace($source)) { $source = $Global:ProjectRoot }

    if (-not (Test-Path $source)) {
        Write-Host "  Source not found: $source" -ForegroundColor Red
        Pause-Screen; return
    }

    $dest = Get-BackupDestination "Full"
    Write-Host "  Destination: $dest" -ForegroundColor DarkGray
    Write-Host "  Starting full backup..." -ForegroundColor Yellow

    try {
        $startTime = Get-Date
        Copy-Item -Path "$source\*" -Destination $dest -Recurse -Force -ErrorAction Stop

        # Create manifest
        $files = Get-ChildItem -Path $dest -Recurse -File
        $manifest = @{
            Type        = "Full"
            Source      = $source
            Destination = $dest
            Date        = (Get-Date).ToString("o")
            FileCount   = $files.Count
            TotalSize   = ($files | Measure-Object Length -Sum).Sum
            Duration    = ((Get-Date) - $startTime).TotalSeconds
        }
        $manifest | ConvertTo-Json | Set-Content (Join-Path $dest "backup_manifest.json")

        Save-BackupState "Full"
        Write-Host "  [OK] Full backup completed!" -ForegroundColor Green
        Write-Host "  Files: $($manifest.FileCount)  |  Size: $([math]::Round($manifest.TotalSize/1MB,1)) MB  |  Duration: $([math]::Round($manifest.Duration,1))s" -ForegroundColor White
        Write-Log "Full backup completed: $dest ($($manifest.FileCount) files)" "INFO"
    } catch {
        Write-Host "  Error during backup: $($_.Exception.Message)" -ForegroundColor Red
        Write-Log "Error in full backup: $($_.Exception.Message)" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 2. Incremental backup (only files changed since last backup)
# =============================================================================
function Start-IncrementalBackup {
    Show-Header "INCREMENTAL BACKUP"

    $state = Get-BackupState
    $refDate = if ($state.LastIncremental) { [datetime]$state.LastIncremental }
               elseif ($state.LastFull)    { [datetime]$state.LastFull }
               else                        { $null }

    if (-not $refDate) {
        Write-Host "  No previous backup found. Run a Full Backup first." -ForegroundColor Yellow
        Pause-Screen; return
    }

    Write-Host "  Reference: $($refDate.ToString('yyyy-MM-dd HH:mm:ss'))" -ForegroundColor DarkGray

    Write-Host "  Source (Enter = project): " -NoNewline -ForegroundColor Cyan
    $source = Read-Host
    if ([string]::IsNullOrWhiteSpace($source)) { $source = $Global:ProjectRoot }

    $dest = Get-BackupDestination "Incremental"
    Write-Host "  Copying files modified since $($refDate.ToString('yyyy-MM-dd HH:mm'))..." -ForegroundColor Yellow

    try {
        $startTime = Get-Date
        $changedFiles = Get-ChildItem -Path $source -Recurse -File -ErrorAction SilentlyContinue |
                        Where-Object { $_.LastWriteTime -gt $refDate }

        if ($changedFiles.Count -eq 0) {
            Write-Host "  No files modified since the last backup." -ForegroundColor Green
            Remove-Item -Path $dest -Force -Recurse
            Pause-Screen; return
        }

        foreach ($file in $changedFiles) {
            $relPath  = $file.FullName.Substring($source.Length).TrimStart("\")
            $destFile = Join-Path $dest $relPath
            $destDir  = Split-Path $destFile -Parent
            if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
            Copy-Item -Path $file.FullName -Destination $destFile -Force
        }

        $manifest = @{
            Type        = "Incremental"
            Source      = $source
            Destination = $dest
            Reference   = $refDate.ToString("o")
            Date        = (Get-Date).ToString("o")
            FileCount   = $changedFiles.Count
            TotalSize   = ($changedFiles | Measure-Object Length -Sum).Sum
            Duration    = ((Get-Date) - $startTime).TotalSeconds
        }
        $manifest | ConvertTo-Json | Set-Content (Join-Path $dest "backup_manifest.json")

        Save-BackupState "Incremental"
        Write-Host "  [OK] Incremental backup completed!" -ForegroundColor Green
        Write-Host "  Files: $($changedFiles.Count)  |  Size: $([math]::Round($manifest.TotalSize/1MB,1)) MB" -ForegroundColor White
        Write-Log "Incremental backup completed: $dest ($($changedFiles.Count) files)" "INFO"
    } catch {
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        Write-Log "Error in incremental backup: $($_.Exception.Message)" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 3. Differential backup (changed since last FULL)
# =============================================================================
function Start-DifferentialBackup {
    Show-Header "DIFFERENTIAL BACKUP"

    $state = Get-BackupState
    if (-not $state.LastFull) {
        Write-Host "  No full backup found. Run a Full Backup first." -ForegroundColor Yellow
        Pause-Screen; return
    }
    $refDate = [datetime]$state.LastFull
    Write-Host "  Reference (last full backup): $($refDate.ToString('yyyy-MM-dd HH:mm:ss'))" -ForegroundColor DarkGray

    Write-Host "  Source (Enter = project): " -NoNewline -ForegroundColor Cyan
    $source = Read-Host
    if ([string]::IsNullOrWhiteSpace($source)) { $source = $Global:ProjectRoot }

    $dest = Get-BackupDestination "Differential"
    Write-Host "  Copying files modified since the last full backup..." -ForegroundColor Yellow

    try {
        $startTime = Get-Date
        $changedFiles = Get-ChildItem -Path $source -Recurse -File -ErrorAction SilentlyContinue |
                        Where-Object { $_.LastWriteTime -gt $refDate }

        if ($changedFiles.Count -eq 0) {
            Write-Host "  No modified files." -ForegroundColor Green
            Remove-Item -Path $dest -Force -Recurse
            Pause-Screen; return
        }

        foreach ($file in $changedFiles) {
            $relPath  = $file.FullName.Substring($source.Length).TrimStart("\")
            $destFile = Join-Path $dest $relPath
            $destDir  = Split-Path $destFile -Parent
            if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
            Copy-Item -Path $file.FullName -Destination $destFile -Force
        }

        $manifest = @{
            Type        = "Differential"
            Source      = $source
            Destination = $dest
            Reference   = $refDate.ToString("o")
            Date        = (Get-Date).ToString("o")
            FileCount   = $changedFiles.Count
            TotalSize   = ($changedFiles | Measure-Object Length -Sum).Sum
            Duration    = ((Get-Date) - $startTime).TotalSeconds
        }
        $manifest | ConvertTo-Json | Set-Content (Join-Path $dest "backup_manifest.json")

        Save-BackupState "Differential"
        Write-Host "  [OK] Differential backup completed!" -ForegroundColor Green
        Write-Host "  Files: $($changedFiles.Count)  |  Size: $([math]::Round($manifest.TotalSize/1MB,1)) MB" -ForegroundColor White
        Write-Log "Differential backup completed: $dest ($($changedFiles.Count) files)" "INFO"
    } catch {
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        Write-Log "Error in differential backup: $($_.Exception.Message)" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 4. List existing backups
# =============================================================================
function Show-Backups {
    Show-Header "EXISTING BACKUPS"

    foreach ($type in @("Full","Incremental","Differential")) {
        $typeDir = Join-Path $Global:BackupDir $type
        Write-Host "  --- $type ---" -ForegroundColor Yellow
        if (Test-Path $typeDir) {
            $backups = Get-ChildItem -Path $typeDir -Directory | Sort-Object CreationTime -Descending
            if ($backups.Count -eq 0) {
                Write-Host "  No backups." -ForegroundColor DarkGray
            } else {
                foreach ($b in $backups) {
                    $manifestPath = Join-Path $b.FullName "backup_manifest.json"
                    if (Test-Path $manifestPath) {
                        $m = Get-Content $manifestPath -Raw | ConvertFrom-Json
                        Write-Host ("  {0,-35} Files: {1,5}  Size: {2,6} MB" -f `
                            $b.Name, $m.FileCount, [math]::Round($m.TotalSize/1MB, 1)) -ForegroundColor White
                    } else {
                        Write-Host "  $($b.Name)" -ForegroundColor White
                    }
                }
            }
        } else {
            Write-Host "  No backups." -ForegroundColor DarkGray
        }
        Write-Host ""
    }

    Write-Log "Backup list queried." "INFO"
    Pause-Screen
}

# =============================================================================
# 5. Verify backup integrity
# =============================================================================
function Test-BackupIntegrity {
    Show-Header "VERIFY BACKUP INTEGRITY"

    Write-Host "  Path of the backup to verify: " -NoNewline -ForegroundColor Cyan
    $backupPath = Read-Host

    if (-not (Test-Path $backupPath)) {
        Write-Host "  Path not found." -ForegroundColor Red
        Pause-Screen; return
    }

    $manifestPath = Join-Path $backupPath "backup_manifest.json"
    if (-not (Test-Path $manifestPath)) {
        Write-Host "  Manifest not found. Cannot verify." -ForegroundColor Yellow
        Pause-Screen; return
    }

    $manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
    $actualFiles = Get-ChildItem -Path $backupPath -Recurse -File | Where-Object { $_.Name -ne "backup_manifest.json" }
    $actualCount = $actualFiles.Count
    $actualSize  = ($actualFiles | Measure-Object Length -Sum).Sum

    Write-Host ""
    Write-Host "  Manifest:" -ForegroundColor White
    Write-Host "    Type      : $($manifest.Type)" -ForegroundColor DarkGray
    Write-Host "    Date      : $($manifest.Date)" -ForegroundColor DarkGray
    Write-Host "    Files     : $($manifest.FileCount)" -ForegroundColor DarkGray
    Write-Host "    Size      : $([math]::Round($manifest.TotalSize/1MB,1)) MB" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  Actual on disk:" -ForegroundColor White
    Write-Host "    Files     : $actualCount" -ForegroundColor DarkGray
    Write-Host "    Size      : $([math]::Round($actualSize/1MB,1)) MB" -ForegroundColor DarkGray
    Write-Host ""

    $ok = $true
    if ($actualCount -ne $manifest.FileCount) { Write-Host "  [WARNING] File count mismatch!" -ForegroundColor Yellow; $ok = $false }
    if ([math]::Abs($actualSize - $manifest.TotalSize) -gt 1MB) { Write-Host "  [WARNING] Size mismatch!" -ForegroundColor Yellow; $ok = $false }

    if ($ok) {
        Write-Host "  [OK] Backup integrity verified." -ForegroundColor Green
        Write-Log "Backup integrity check OK: $backupPath" "INFO"
    } else {
        Write-Log "Backup integrity check with discrepancies: $backupPath" "WARN"
    }
    Pause-Screen
}

# =============================================================================
# 6. Restore from backup
# =============================================================================
function Start-Restore {
    Show-Header "DATA RESTORE"

    # Find all backups with manifests
    $allBackups = @()
    foreach ($type in @("Full","Incremental","Differential")) {
        $typeDir = Join-Path $Global:BackupDir $type
        if (Test-Path $typeDir) {
            $dirs = Get-ChildItem -Path $typeDir -Directory -ErrorAction SilentlyContinue
            foreach ($dir in $dirs) {
                $mPath = Join-Path $dir.FullName "backup_manifest.json"
                if (Test-Path $mPath) {
                    $m = Get-Content $mPath -Raw | ConvertFrom-Json
                    $allBackups += [PSCustomObject]@{
                        Path      = $dir.FullName
                        Type      = $m.Type
                        Date      = $m.Date
                        Source    = $m.Source
                        FileCount = $m.FileCount
                        SizeMB    = [math]::Round($m.TotalSize/1MB,1)
                    }
                }
            }
        }
    }

    if ($allBackups.Count -eq 0) {
        Write-Host "  No backups found with manifests." -ForegroundColor Yellow
        Write-Host "  Run a Full, Incremental or Differential backup first." -ForegroundColor DarkGray
        Pause-Screen; return
    }

    # Sort by date descending
    $allBackups = $allBackups | Sort-Object Date -Descending

    # Display list
    Write-Host "  Available backups:" -ForegroundColor White
    Write-Host ""
    $i = 1
    foreach ($bk in $allBackups) {
        $dateStr = try { ([datetime]$bk.Date).ToString("yyyy-MM-dd HH:mm") } catch { $bk.Date }
        $typeColor = switch ($bk.Type) { "Full" { "Green" } "Incremental" { "Yellow" } "Differential" { "Cyan" } default { "White" } }
        Write-Host "  [$i]" -NoNewline -ForegroundColor White
        Write-Host "  $($bk.Type.PadRight(14))" -NoNewline -ForegroundColor $typeColor
        Write-Host "  $dateStr" -NoNewline -ForegroundColor DarkGray
        Write-Host "  $($bk.FileCount) files" -NoNewline -ForegroundColor DarkGray
        Write-Host "  $($bk.SizeMB) MB" -ForegroundColor DarkGray
        $i++
    }

    Write-Host ""
    Write-Host "  Select backup to restore (0 to cancel): " -NoNewline -ForegroundColor Cyan
    $choice = Read-Host

    if ($choice -eq "0" -or [string]::IsNullOrWhiteSpace($choice)) {
        Write-Host "  Cancelled." -ForegroundColor DarkGray
        Pause-Screen; return
    }

    if ($choice -notmatch '^\d+$' -or [int]$choice -lt 1 -or [int]$choice -gt $allBackups.Count) {
        Write-Host "  Invalid selection." -ForegroundColor Red
        Pause-Screen; return
    }

    $selected = $allBackups[[int]$choice - 1]
    $backupPath = $selected.Path

    # Show details
    Write-Host ""
    Write-Host "  Selected backup:" -ForegroundColor White
    Write-Host "    Type    : $($selected.Type)" -ForegroundColor DarkGray
    Write-Host "    Date    : $($selected.Date)" -ForegroundColor DarkGray
    Write-Host "    Source  : $($selected.Source)" -ForegroundColor DarkGray
    Write-Host "    Files   : $($selected.FileCount)" -ForegroundColor DarkGray
    Write-Host "    Size    : $($selected.SizeMB) MB" -ForegroundColor DarkGray
    Write-Host ""

    Write-Host "  Restore destination (Enter = $($selected.Source)): " -NoNewline -ForegroundColor Cyan
    $dest = Read-Host
    if ([string]::IsNullOrWhiteSpace($dest)) { $dest = $selected.Source }
    if ([string]::IsNullOrWhiteSpace($dest)) { Write-Host "  Invalid destination." -ForegroundColor Red; Pause-Screen; return }

    Write-Host ""
    Write-Host "  WARNING: This will overwrite files in '$dest'." -ForegroundColor Yellow
    Write-Host "  Confirm? (Y/N): " -NoNewline -ForegroundColor Yellow
    $confirm = Read-Host
    if ($confirm.ToUpper() -ne "Y") { Write-Host "  Cancelled." -ForegroundColor DarkGray; Pause-Screen; return }

    try {
        $files = Get-ChildItem -Path $backupPath -Recurse -File | Where-Object { $_.Name -ne "backup_manifest.json" }
        $count = 0
        foreach ($file in $files) {
            $relPath  = $file.FullName.Substring($backupPath.Length).TrimStart("\")
            $destFile = Join-Path $dest $relPath
            $destDir  = Split-Path $destFile -Parent
            if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
            Copy-Item -Path $file.FullName -Destination $destFile -Force
            $count++
        }
        Write-Host "  [OK] Restore completed: $count files restored to $dest" -ForegroundColor Green
        Write-Log "Restore completed: $count files from $backupPath to $dest" "INFO"
    } catch {
        Write-Host "  Error during restore: $($_.Exception.Message)" -ForegroundColor Red
        Write-Log "Error in restore: $($_.Exception.Message)" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 7. Schedule backup via Windows Task Scheduler
# =============================================================================
function Schedule-Backup {
    Show-Header "SCHEDULE AUTOMATIC BACKUP"

    Write-Host "  Backup type  [1] Full  [2] Incremental: " -NoNewline -ForegroundColor Cyan
    $type = Read-Host
    $backupType = if ($type -eq "1") { "Full" } else { "Incremental" }

    Write-Host "  Execution time (HH:MM, e.g. 02:00): " -NoNewline -ForegroundColor Cyan
    $time = Read-Host
    if ($time -notmatch '^\d{2}:\d{2}$') { $time = "02:00" }

    $taskName   = "SysAdmin_Backup_$backupType"
    $scriptPath = Join-Path $Global:ModuleDir "8_Backup.ps1"
    $mainPath   = Join-Path $Global:ProjectRoot "MainMenu.ps1"

    # Create a small launcher script that runs the backup directly
    $launcherPath = Join-Path $Global:LogDir "run_backup_$backupType.ps1"
    @"
. '$($Global:ProjectRoot)\Config.ps1'
. '$scriptPath'
$(if ($backupType -eq "Full") { "Start-FullBackup" } else { "Start-IncrementalBackup" })
"@ | Set-Content $launcherPath

    try {
        $action  = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NonInteractive -File `"$launcherPath`""
        $trigger = New-ScheduledTaskTrigger -Daily -At $time
        $settings = New-ScheduledTaskSettingsSet -RunOnlyIfNetworkAvailable:$false -StartWhenAvailable

        Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger `
            -Settings $settings -RunLevel Highest -Force | Out-Null

        Write-Host "  [OK] Task scheduled: '$taskName' every day at $time" -ForegroundColor Green
        Write-Log "Backup scheduled: $backupType at $time" "INFO"
    } catch {
        Write-Host "  Error scheduling: $($_.Exception.Message)" -ForegroundColor Red
        Write-Log "Error scheduling backup: $($_.Exception.Message)" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# MODULE MENU
# =============================================================================
function Show-BackupMenu {
    do {
        Show-Header "BACKUP AND RECOVERY"

        $state = Get-BackupState
        $lastFull = if ($state.LastFull) { ([datetime]$state.LastFull).ToString("yyyy-MM-dd HH:mm") } else { "None" }
        $lastInc  = if ($state.LastIncremental) { ([datetime]$state.LastIncremental).ToString("yyyy-MM-dd HH:mm") } else { "None" }
        Write-Host "  Last full backup         : $lastFull" -ForegroundColor DarkGray
        Write-Host "  Last incremental backup  : $lastInc" -ForegroundColor DarkGray
        Write-Host ""
        Write-Host "   RUN BACKUP" -ForegroundColor DarkCyan
        Write-Host "   [1]  Full Backup" -ForegroundColor White
        Write-Host "   [2]  Incremental Backup" -ForegroundColor White
        Write-Host "   [3]  Differential Backup" -ForegroundColor White
        Write-Host ""
        Write-Host "   MANAGE" -ForegroundColor DarkCyan
        Write-Host "   [4]  View existing backups" -ForegroundColor White
        Write-Host "   [5]  Verify backup integrity" -ForegroundColor White
        Write-Host "   [6]  Restore backup" -ForegroundColor White
        Write-Host "   [7]  Schedule automatic backup" -ForegroundColor White
        Write-Host ""
        Write-Host "  ------------------------------------------------------------" -ForegroundColor DarkGray
        Write-Host "   [0]  Back to main menu" -ForegroundColor DarkGray
        Write-Host ""

        $choice = Read-Host "  Option"
        switch ($choice) {
            "1" { Start-FullBackup }
            "2" { Start-IncrementalBackup }
            "3" { Start-DifferentialBackup }
            "4" { Show-Backups }
            "5" { Test-BackupIntegrity }
            "6" { Start-Restore }
            "7" { Schedule-Backup }
            "0" { return }
            default { Write-Host "  Invalid option." -ForegroundColor Red; Start-Sleep 1 }
        }
    } while ($true)
}

Show-BackupMenu
