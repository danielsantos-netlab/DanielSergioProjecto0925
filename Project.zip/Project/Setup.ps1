# =============================================================================
# Setup.ps1 - Auto Setup (called by MainMenu.ps1 on first run)
# Creates all required folders, checks dependencies, writes marker file
# =============================================================================

function Write-SetupMsg {
    param([string]$Msg, [string]$Color = "Cyan")
    $ts = Get-Date -Format "HH:mm:ss"
    Write-Host "  [$ts] $Msg" -ForegroundColor $Color
}

function Run-Setup {
    param([string]$ProjectRoot)

    Clear-Host
    Write-Host ""
    Write-Host "  ============================================================" -ForegroundColor DarkCyan
    Write-Host "   INITIAL SYSTEM CONFIGURATION" -ForegroundColor Cyan
    Write-Host "   Preparing the environment for the first time..." -ForegroundColor DarkGray
    Write-Host "  ============================================================" -ForegroundColor DarkCyan
    Write-Host ""

    # --- 1. Create directory structure ---
    $dirs = @(
        "$ProjectRoot\Logs",
        "$ProjectRoot\Reports",
        "$ProjectRoot\Backups",
        "$ProjectRoot\Backups\Full",
        "$ProjectRoot\Backups\Incremental",
        "$ProjectRoot\Backups\Differential",
        "$ProjectRoot\Modules"
    )

    foreach ($dir in $dirs) {
        if (-not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
            Write-SetupMsg "Folder created: $dir" "Green"
        } else {
            Write-SetupMsg "Folder already exists: $dir" "DarkGray"
        }
    }

    Write-Host ""

    # --- 2. Check PowerShell version ---
    $psVer = $PSVersionTable.PSVersion.Major
    if ($psVer -lt 5) {
        Write-SetupMsg "WARNING: PowerShell $psVer detected. Version 5.1 or higher recommended." "Yellow"
    } else {
        Write-SetupMsg "PowerShell $($PSVersionTable.PSVersion) detected. OK." "Green"
    }

    # --- 3. Check execution policy ---
    $policy = Get-ExecutionPolicy
    Write-SetupMsg "Current execution policy: $policy" "DarkGray"
    if ($policy -eq "Restricted") {
        Write-SetupMsg "Adjusting policy to RemoteSigned..." "Yellow"
        try {
            Set-ExecutionPolicy RemoteSigned -Scope LocalMachine -Force
            Write-SetupMsg "Policy updated to RemoteSigned." "Green"
        } catch {
            Write-SetupMsg "Could not change policy. Continuing anyway." "Yellow"
        }
    } else {
        Write-SetupMsg "Execution policy OK ($policy)." "Green"
    }

    # --- 4. Check admin rights ---
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
    if ($isAdmin) {
        Write-SetupMsg "Running with Administrator privileges. OK." "Green"
    } else {
        Write-SetupMsg "WARNING: Not running as Administrator. Some features may fail." "Yellow"
    }

    # --- 5. Check Windows Server ---
    $os = (Get-CimInstance Win32_OperatingSystem).Caption
    Write-SetupMsg "Operating system: $os" "DarkGray"

    # --- 6. Check required modules (ActiveDirectory optional) ---
    Write-SetupMsg "Checking available PowerShell modules..." "DarkGray"

    $modules = @("NetTCPIP","NetAdapter","Storage","PrintManagement")
    foreach ($mod in $modules) {
        if (Get-Module -ListAvailable -Name $mod -ErrorAction SilentlyContinue) {
            Write-SetupMsg "Module '$mod' available." "Green"
        } else {
            Write-SetupMsg "Module '$mod' not found (some features may be limited)." "Yellow"
        }
    }

    # ActiveDirectory - optional
    if (Get-Module -ListAvailable -Name "ActiveDirectory" -ErrorAction SilentlyContinue) {
        Write-SetupMsg "Module 'ActiveDirectory' available. AD management enabled." "Green"
        $Global:ADAvailable = $true
    } else {
        Write-SetupMsg "Module 'ActiveDirectory' not available. Using local users." "Yellow"
        $Global:ADAvailable = $false
    }

    # --- 7. Create setup marker ---
    $marker = Join-Path $ProjectRoot ".setup_done"
    "Setup completed: $(Get-Date)" | Set-Content $marker
    Write-SetupMsg "Setup marker created." "DarkGray"

    # --- 8. Create initial log ---
    $logFile = Join-Path (Join-Path $ProjectRoot "Logs") ("sysadmin_" + (Get-Date -Format "yyyy-MM-dd") + ".log")
    "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')][INFO] Initial setup completed. OS: $os | PS: $($PSVersionTable.PSVersion) | Admin: $isAdmin | AD: $($Global:ADAvailable)" |
        Set-Content $logFile

    Write-Host ""
    Write-Host "  ============================================================" -ForegroundColor DarkCyan
    Write-SetupMsg "Setup completed successfully!" "Green"
    Write-Host "  ============================================================" -ForegroundColor DarkCyan
    Write-Host ""
    Write-Host "  Press any key to enter the main menu..." -ForegroundColor DarkGray
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
