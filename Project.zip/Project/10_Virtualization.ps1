﻿# =============================================================================
# 10_Virtualization.ps1 - Virtualization & Hyper-V Management
# Module for ATEC System Administration Toolkit
# VM creation, snapshots, migration, recovery
# =============================================================================

# =============================================================================
# HELPERS
# =============================================================================

function Test-HyperVReady {
    $feature = Get-WindowsFeature -Name Hyper-V -ErrorAction SilentlyContinue
    if (-not $feature) { return $false }
    return $feature.Installed
}

function Get-VMOverview {
    Write-Host ""
    Write-Host "  Hyper-V Status" -ForegroundColor DarkCyan
    Write-Host "  $('-' * 50)" -ForegroundColor DarkGray

    $feature = Get-WindowsFeature -Name Hyper-V -ErrorAction SilentlyContinue
    if ($feature -and $feature.Installed) {
        Write-Host "  Role:        " -NoNewline -ForegroundColor DarkGray; Write-Host "Installed" -ForegroundColor Green
    } else {
        Write-Host "  Role:        " -NoNewline -ForegroundColor DarkGray; Write-Host "Not Installed" -ForegroundColor Yellow
        Write-Host "  $('-' * 50)" -ForegroundColor DarkGray
        Write-Host ""
        return
    }

    $vms = Get-VM -ErrorAction SilentlyContinue
    $running = ($vms | Where-Object { $_.State -eq 'Running' }).Count
    $off = ($vms | Where-Object { $_.State -eq 'Off' }).Count
    $total = ($vms | Measure-Object).Count

    Write-Host "  VMs:         " -NoNewline -ForegroundColor DarkGray; Write-Host "$total total ($running running, $off off)" -ForegroundColor White
    Write-Host "  Default Path:" -NoNewline -ForegroundColor DarkGray; Write-Host " $(Get-VMHost -ErrorAction SilentlyContinue | Select-Object -ExpandProperty VirtualMachinePath)" -ForegroundColor White
    Write-Host "  $('-' * 50)" -ForegroundColor DarkGray
    Write-Host ""
}

# =============================================================================
# 1. INSTALL HYPER-V
# =============================================================================
function Install-HyperVRole {
    Show-Header "INSTALL HYPER-V"

    $feature = Get-WindowsFeature -Name Hyper-V -ErrorAction SilentlyContinue
    if ($feature -and $feature.Installed) {
        Write-Host "  [OK] Hyper-V is already installed." -ForegroundColor Green
        Pause-Screen; return
    }

    Write-Host "  Hyper-V role is not installed." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  NOTE: Nested virtualization must be enabled in VMware" -ForegroundColor DarkGray
    Write-Host "  (VM Settings > Processors > Virtualize Intel VT-x/EPT)" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  Install Hyper-V now? (s/n): " -NoNewline -ForegroundColor Cyan
    if ((Read-Host) -ne "s") { return }

    try {
        Write-Host "  Installing (this may take a few minutes)..." -ForegroundColor DarkGray
        $result = Install-WindowsFeature -Name Hyper-V -IncludeManagementTools -ErrorAction Stop
        Write-Host "  [OK] Hyper-V installed." -ForegroundColor Green
        Write-Log "Hyper-V role installed." "INFO"

        if ($result.RestartNeeded -eq "Yes") {
            Write-Host "  [!] RESTART REQUIRED." -ForegroundColor Yellow
            Write-Host "  Restart now? (s/n): " -NoNewline -ForegroundColor Cyan
            if ((Read-Host) -eq "s") { Restart-Computer -Force }
        }
    }
    catch {
        Write-Host "  [ERROR] $_" -ForegroundColor Red
        Write-Log "Failed to install Hyper-V: $_" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 2. LIST VMs
# =============================================================================
function Show-VMList {
    Show-Header "VIRTUAL MACHINES"

    if (-not (Test-HyperVReady)) {
        Write-Host "  [!] Hyper-V not installed. Use option 1 first." -ForegroundColor Yellow
        Pause-Screen; return
    }

    $vms = Get-VM -ErrorAction SilentlyContinue
    if (-not $vms) {
        Write-Host "  No virtual machines found." -ForegroundColor DarkGray
        Pause-Screen; return
    }

    Write-Host ""
    Write-Host "  NAME                 STATE      CPU   RAM (MB)   UPTIME" -ForegroundColor DarkCyan
    Write-Host "  ----------------------------------------------------------------" -ForegroundColor DarkGray

    foreach ($vm in $vms) {
        $state = $vm.State.ToString()
        $color = switch ($state) { "Running" { "Green" } "Off" { "DarkGray" } "Saved" { "Yellow" } default { "White" } }
        $ram = [math]::Round($vm.MemoryAssigned / 1MB)
        $uptime = if ($vm.Uptime.TotalMinutes -gt 0) { $vm.Uptime.ToString("hh\:mm\:ss") } else { "-" }
        $line = "  " + $vm.Name.PadRight(22) + $state.PadRight(11) + "$($vm.ProcessorCount)".PadRight(6) + "$ram".PadRight(11) + $uptime
        Write-Host $line -ForegroundColor $color
    }
    Pause-Screen
}

# =============================================================================
# 3. CREATE VM
# =============================================================================
function New-VMInteractive {
    Show-Header "CREATE VIRTUAL MACHINE"

    if (-not (Test-HyperVReady)) {
        Write-Host "  [!] Hyper-V not installed." -ForegroundColor Yellow
        Pause-Screen; return
    }

    Write-Host "  VM Name: " -NoNewline -ForegroundColor Cyan; $name = Read-Host
    if ([string]::IsNullOrWhiteSpace($name)) { return }

    Write-Host "  Generation (1 or 2, Enter for 2): " -NoNewline -ForegroundColor Cyan
    $genInput = Read-Host
    $gen = if ($genInput -eq "1") { 1 } else { 2 }

    Write-Host "  RAM in MB (Enter for 2048): " -NoNewline -ForegroundColor Cyan
    $ramInput = Read-Host
    $ramMB = if ([string]::IsNullOrWhiteSpace($ramInput)) { 2048 } else { [int]$ramInput }

    Write-Host "  Disk size in GB (Enter for 40): " -NoNewline -ForegroundColor Cyan
    $diskInput = Read-Host
    $diskGB = if ([string]::IsNullOrWhiteSpace($diskInput)) { 40 } else { [int]$diskInput }

    Write-Host "  vSwitch name (Enter to skip): " -NoNewline -ForegroundColor Cyan
    $switchName = Read-Host

    Write-Host ""
    Write-Host "  VM:     $name" -ForegroundColor White
    Write-Host "  Gen:    $gen | RAM: ${ramMB}MB | Disk: ${diskGB}GB" -ForegroundColor White
    if ($switchName) { Write-Host "  Switch: $switchName" -ForegroundColor White }
    Write-Host ""
    Write-Host "  Create? (s/n): " -NoNewline -ForegroundColor Yellow
    if ((Read-Host) -ne "s") { return }

    try {
        $vmPath = (Get-VMHost).VirtualMachinePath
        $vhdPath = Join-Path $vmPath "$name\Virtual Hard Disks\$name.vhdx"

        $params = @{
            Name               = $name
            Generation         = $gen
            MemoryStartupBytes = $ramMB * 1MB
            NewVHDPath         = $vhdPath
            NewVHDSizeBytes    = $diskGB * 1GB
            ErrorAction        = "Stop"
        }
        if ($switchName) { $params["SwitchName"] = $switchName }

        New-VM @params | Out-Null
        Write-Host "  [OK] VM '$name' created." -ForegroundColor Green
        Write-Log "VM created: $name (Gen$gen, ${ramMB}MB RAM, ${diskGB}GB disk)" "INFO"
    }
    catch {
        Write-Host "  [ERROR] $_" -ForegroundColor Red
        Write-Log "Failed to create VM '$name': $_" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 4. START / STOP / RESTART VM
# =============================================================================
function Set-VMState {
    param([string]$Action)

    Show-Header "$($Action.ToUpper()) VIRTUAL MACHINE"

    if (-not (Test-HyperVReady)) {
        Write-Host "  [!] Hyper-V not installed." -ForegroundColor Yellow
        Pause-Screen; return
    }

    $vms = Get-VM -ErrorAction SilentlyContinue
    if (-not $vms) { Write-Host "  No VMs found." -ForegroundColor DarkGray; Pause-Screen; return }

    $i = 1
    foreach ($vm in $vms) {
        $color = if ($vm.State -eq 'Running') { "Green" } else { "DarkGray" }
        Write-Host "  [$i] $($vm.Name) ($($vm.State))" -ForegroundColor $color
        $i++
    }
    Write-Host ""
    Write-Host "  Number (Enter to cancel): " -NoNewline -ForegroundColor Cyan
    $sel = Read-Host
    if ([string]::IsNullOrWhiteSpace($sel)) { return }

    $idx = [int]$sel - 1
    if ($idx -lt 0 -or $idx -ge ([array]$vms).Count) {
        Write-Host "  [!] Invalid." -ForegroundColor Red; Pause-Screen; return
    }
    $vm = ([array]$vms)[$idx]

    try {
        switch ($Action) {
            "Start"   { Start-VM -Name $vm.Name -ErrorAction Stop; Write-Host "  [OK] '$($vm.Name)' started." -ForegroundColor Green }
            "Stop"    { Stop-VM -Name $vm.Name -Force -ErrorAction Stop; Write-Host "  [OK] '$($vm.Name)' stopped." -ForegroundColor Green }
            "Restart" { Restart-VM -Name $vm.Name -Force -ErrorAction Stop; Write-Host "  [OK] '$($vm.Name)' restarted." -ForegroundColor Green }
        }
        Write-Log "VM '$($vm.Name)' $Action." "INFO"
    }
    catch {
        Write-Host "  [ERROR] $_" -ForegroundColor Red
        Write-Log "Failed to $Action VM '$($vm.Name)': $_" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 5. SNAPSHOTS (CHECKPOINTS)
# =============================================================================
function Manage-VMSnapshots {
    Show-Header "VM SNAPSHOTS (CHECKPOINTS)"

    if (-not (Test-HyperVReady)) {
        Write-Host "  [!] Hyper-V not installed." -ForegroundColor Yellow
        Pause-Screen; return
    }

    $vms = Get-VM -ErrorAction SilentlyContinue
    if (-not $vms) { Write-Host "  No VMs found." -ForegroundColor DarkGray; Pause-Screen; return }

    Write-Host "  [1] Create snapshot" -ForegroundColor White
    Write-Host "  [2] List snapshots" -ForegroundColor White
    Write-Host "  [3] Restore snapshot" -ForegroundColor White
    Write-Host "  [4] Delete snapshot" -ForegroundColor White
    Write-Host ""
    Write-Host "  Option: " -NoNewline -ForegroundColor Cyan
    $action = Read-Host

    # Select VM
    Write-Host ""
    $i = 1
    foreach ($vm in $vms) {
        Write-Host "  [$i] $($vm.Name) ($($vm.State))" -ForegroundColor White
        $i++
    }
    Write-Host ""
    Write-Host "  VM number: " -NoNewline -ForegroundColor Cyan
    $sel = Read-Host
    if ([string]::IsNullOrWhiteSpace($sel)) { return }
    $idx = [int]$sel - 1
    if ($idx -lt 0 -or $idx -ge ([array]$vms).Count) {
        Write-Host "  [!] Invalid." -ForegroundColor Red; Pause-Screen; return
    }
    $vm = ([array]$vms)[$idx]

    switch ($action) {
        "1" {
            Write-Host "  Snapshot name (Enter for auto): " -NoNewline -ForegroundColor Cyan
            $snapName = Read-Host
            if ([string]::IsNullOrWhiteSpace($snapName)) { $snapName = "Snapshot_$(Get-Date -Format 'yyyyMMdd_HHmmss')" }
            try {
                Checkpoint-VM -Name $vm.Name -SnapshotName $snapName -ErrorAction Stop
                Write-Host "  [OK] Snapshot '$snapName' created for '$($vm.Name)'." -ForegroundColor Green
                Write-Log "Snapshot created: $snapName on $($vm.Name)" "INFO"
            }
            catch { Write-Host "  [ERROR] $_" -ForegroundColor Red }
        }
        "2" {
            $snaps = Get-VMSnapshot -VMName $vm.Name -ErrorAction SilentlyContinue
            if (-not $snaps) {
                Write-Host "  No snapshots for '$($vm.Name)'." -ForegroundColor DarkGray
            } else {
                Write-Host ""
                Write-Host "  NAME                           CREATED              TYPE" -ForegroundColor DarkCyan
                Write-Host "  ------------------------------------------------------------" -ForegroundColor DarkGray
                foreach ($s in $snaps) {
                    $created = $s.CreationTime.ToString("yyyy-MM-dd HH:mm")
                    $line = "  " + $s.Name.PadRight(32) + $created.PadRight(21) + $s.SnapshotType
                    Write-Host $line -ForegroundColor White
                }
            }
        }
        "3" {
            $snaps = Get-VMSnapshot -VMName $vm.Name -ErrorAction SilentlyContinue
            if (-not $snaps) { Write-Host "  No snapshots to restore." -ForegroundColor DarkGray; Pause-Screen; return }

            $j = 1
            foreach ($s in $snaps) {
                Write-Host "  [$j] $($s.Name) ($($s.CreationTime.ToString('yyyy-MM-dd HH:mm')))" -ForegroundColor White
                $j++
            }
            Write-Host ""
            Write-Host "  Snapshot to restore: " -NoNewline -ForegroundColor Cyan
            $sSel = Read-Host
            $sIdx = [int]$sSel - 1
            if ($sIdx -lt 0 -or $sIdx -ge ([array]$snaps).Count) { Write-Host "  [!] Invalid." -ForegroundColor Red; Pause-Screen; return }
            $snap = ([array]$snaps)[$sIdx]

            Write-Host "  Restore '$($vm.Name)' to '$($snap.Name)'? (s/n): " -NoNewline -ForegroundColor Yellow
            if ((Read-Host) -ne "s") { return }

            try {
                Restore-VMSnapshot -VMName $vm.Name -Name $snap.Name -Confirm:$false -ErrorAction Stop
                Write-Host "  [OK] Restored to '$($snap.Name)'." -ForegroundColor Green
                Write-Log "VM '$($vm.Name)' restored to snapshot '$($snap.Name)'" "INFO"
            }
            catch { Write-Host "  [ERROR] $_" -ForegroundColor Red }
        }
        "4" {
            $snaps = Get-VMSnapshot -VMName $vm.Name -ErrorAction SilentlyContinue
            if (-not $snaps) { Write-Host "  No snapshots." -ForegroundColor DarkGray; Pause-Screen; return }

            $j = 1
            foreach ($s in $snaps) {
                Write-Host "  [$j] $($s.Name)" -ForegroundColor White
                $j++
            }
            Write-Host ""
            Write-Host "  Snapshot to delete: " -NoNewline -ForegroundColor Cyan
            $sSel = Read-Host
            $sIdx = [int]$sSel - 1
            if ($sIdx -lt 0 -or $sIdx -ge ([array]$snaps).Count) { return }
            $snap = ([array]$snaps)[$sIdx]

            Write-Host "  DELETE snapshot '$($snap.Name)'? (type YES): " -NoNewline -ForegroundColor Yellow
            if ((Read-Host) -ne "YES") { return }

            try {
                Remove-VMSnapshot -VMName $vm.Name -Name $snap.Name -ErrorAction Stop
                Write-Host "  [OK] Snapshot deleted." -ForegroundColor Green
                Write-Log "Snapshot deleted: $($snap.Name) from $($vm.Name)" "WARN"
            }
            catch { Write-Host "  [ERROR] $_" -ForegroundColor Red }
        }
    }
    Pause-Screen
}

# =============================================================================
# 6. DELETE VM
# =============================================================================
function Remove-VMInteractive {
    Show-Header "DELETE VIRTUAL MACHINE"

    if (-not (Test-HyperVReady)) {
        Write-Host "  [!] Hyper-V not installed." -ForegroundColor Yellow
        Pause-Screen; return
    }

    $vms = Get-VM -ErrorAction SilentlyContinue
    if (-not $vms) { Write-Host "  No VMs found." -ForegroundColor DarkGray; Pause-Screen; return }

    $i = 1
    foreach ($vm in $vms) {
        Write-Host "  [$i] $($vm.Name) ($($vm.State))" -ForegroundColor White
        $i++
    }
    Write-Host ""
    Write-Host "  VM to delete: " -NoNewline -ForegroundColor Cyan
    $sel = Read-Host
    if ([string]::IsNullOrWhiteSpace($sel)) { return }
    $idx = [int]$sel - 1
    if ($idx -lt 0 -or $idx -ge ([array]$vms).Count) { Write-Host "  [!] Invalid." -ForegroundColor Red; Pause-Screen; return }
    $vm = ([array]$vms)[$idx]

    Write-Host ""
    Write-Host "  DELETE '$($vm.Name)' and all its files? (type YES): " -NoNewline -ForegroundColor Yellow
    if ((Read-Host) -ne "YES") { return }

    try {
        if ($vm.State -ne 'Off') { Stop-VM -Name $vm.Name -Force -ErrorAction SilentlyContinue }
        $vmPath = $vm.Path
        Remove-VM -Name $vm.Name -Force -ErrorAction Stop
        if ($vmPath -and (Test-Path $vmPath)) {
            Remove-Item -Path $vmPath -Recurse -Force -ErrorAction SilentlyContinue
        }
        Write-Host "  [OK] VM '$($vm.Name)' deleted." -ForegroundColor Green
        Write-Log "VM deleted: $($vm.Name)" "WARN"
    }
    catch {
        Write-Host "  [ERROR] $_" -ForegroundColor Red
        Write-Log "Failed to delete VM '$($vm.Name)': $_" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 7. EXPORT VM (MIGRATION)
# =============================================================================
function Export-VMInteractive {
    Show-Header "EXPORT VM (MIGRATION)"

    if (-not (Test-HyperVReady)) {
        Write-Host "  [!] Hyper-V not installed." -ForegroundColor Yellow
        Pause-Screen; return
    }

    $vms = Get-VM -ErrorAction SilentlyContinue
    if (-not $vms) { Write-Host "  No VMs found." -ForegroundColor DarkGray; Pause-Screen; return }

    $i = 1
    foreach ($vm in $vms) {
        Write-Host "  [$i] $($vm.Name) ($($vm.State))" -ForegroundColor White
        $i++
    }
    Write-Host ""
    Write-Host "  VM to export: " -NoNewline -ForegroundColor Cyan
    $sel = Read-Host
    if ([string]::IsNullOrWhiteSpace($sel)) { return }
    $idx = [int]$sel - 1
    if ($idx -lt 0 -or $idx -ge ([array]$vms).Count) { return }
    $vm = ([array]$vms)[$idx]

    $defaultPath = Join-Path $Global:BackupDir "VM_Exports"
    Write-Host "  Export path (Enter for $defaultPath): " -NoNewline -ForegroundColor Cyan
    $pathInput = Read-Host
    $exportPath = if ([string]::IsNullOrWhiteSpace($pathInput)) { $defaultPath } else { $pathInput }

    if (-not (Test-Path $exportPath)) { New-Item -ItemType Directory -Path $exportPath -Force | Out-Null }

    Write-Host ""
    Write-Host "  Export '$($vm.Name)' to '$exportPath'? (s/n): " -NoNewline -ForegroundColor Yellow
    if ((Read-Host) -ne "s") { return }

    try {
        Write-Host "  Exporting (may take a while)..." -ForegroundColor DarkGray
        Export-VM -Name $vm.Name -Path $exportPath -ErrorAction Stop
        Write-Host "  [OK] VM '$($vm.Name)' exported to '$exportPath'." -ForegroundColor Green
        Write-Log "VM exported: $($vm.Name) -> $exportPath" "INFO"
    }
    catch {
        Write-Host "  [ERROR] $_" -ForegroundColor Red
        Write-Log "Failed to export VM '$($vm.Name)': $_" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# SUBMENU
# =============================================================================
function Show-VirtualizationMenu {
    do {
        Show-Header "VIRTUALIZATION (HYPER-V)"
        Get-VMOverview

        Write-Host "   SETUP" -ForegroundColor DarkCyan
        Write-Host "   [1]  Install Hyper-V Role" -ForegroundColor White
        Write-Host ""
        Write-Host "   VIRTUAL MACHINES" -ForegroundColor DarkCyan
        Write-Host "   [2]  List Virtual Machines" -ForegroundColor White
        Write-Host "   [3]  Create New VM" -ForegroundColor White
        Write-Host "   [4]  Start VM" -ForegroundColor White
        Write-Host "   [5]  Stop VM" -ForegroundColor White
        Write-Host "   [6]  Restart VM" -ForegroundColor White
        Write-Host "   [8]  Delete VM" -ForegroundColor White
        Write-Host ""
        Write-Host "   RECOVERY & MIGRATION" -ForegroundColor DarkCyan
        Write-Host "   [7]  Snapshots (Create/List/Restore/Delete)" -ForegroundColor White
        Write-Host "   [9]  Export VM (Migration)" -ForegroundColor White
        Write-Host "   [10] Attach ISO to VM" -ForegroundColor White
        Write-Host ""
        Write-Host "  [B]  Back to Main Menu" -ForegroundColor DarkYellow
        Write-Host ""
        Write-Host ("=" * 60) -ForegroundColor DarkCyan
        Write-Host ""

        $choice = Read-Host "  Option"

        switch ($choice.ToUpper()) {
            "1" { Install-HyperVRole }
            "2" { Show-VMList }
            "3" { New-VMInteractive }
            "4" { Set-VMState -Action "Start" }
            "5" { Set-VMState -Action "Stop" }
            "6" { Set-VMState -Action "Restart" }
            "7" { Manage-VMSnapshots }
            "8" { Remove-VMInteractive }
            "9" { Export-VMInteractive }
            "B" { return }
            default { Write-Host "`n  Invalid option." -ForegroundColor Red; Start-Sleep -Seconds 1 }
        }
    } while ($true)
}

# --- Entry point ---
Show-VirtualizationMenu
