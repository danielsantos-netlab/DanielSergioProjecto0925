# =============================================================================
# Modules/1_Processes.ps1 - Process & Memory Management
# =============================================================================

. "$Global:ProjectRoot\Config.ps1"

# =============================================================================
# HELPER: Get enriched process list (fast - no per-process WMI)
# =============================================================================
function Get-ProcessList {
    # Build owner lookup table in ONE WMI call instead of per-process
    $owners = @{}
    try {
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | ForEach-Object {
            try { $owners[$_.ProcessId] = $_.GetOwner().User } catch { $owners[$_.ProcessId] = "N/A" }
        }
    } catch {}

    Get-Process | Where-Object { $_.CPU -ne $null } |
    Select-Object `
        Id,
        Name,
        @{N="CPU_s";    E={ [math]::Round($_.CPU, 2) }},
        @{N="RAM_MB";   E={ [math]::Round($_.WorkingSet64 / 1MB, 1) }},
        @{N="Threads";  E={ $_.Threads.Count }},
        @{N="StartTime";E={ try { $_.StartTime.ToString("HH:mm:ss") } catch { "N/A" } }},
        @{N="User";     E={ if ($owners.ContainsKey($_.Id)) { $owners[$_.Id] } else { "N/A" } }} |
    Sort-Object CPU_s -Descending
}

# =============================================================================
# 1. List all processes
# =============================================================================
function Show-AllProcesses {
    Show-Header "ACTIVE PROCESSES"
    $procs = Get-ProcessList
    $procs | Format-Table -AutoSize
    Write-Log "Process listing executed. Total: $($procs.Count)" "INFO"
    Pause-Screen
}

# =============================================================================
# 2. Top N by CPU and RAM
# =============================================================================
function Show-TopProcesses {
    Show-Header "TOP $Global:TopProcessCount PROCESSES (CPU & RAM)"

    $procs = Get-ProcessList

    Write-Host "  --- TOP CPU ---" -ForegroundColor Yellow
    $procs | Select-Object -First $Global:TopProcessCount |
        Format-Table Id, Name, CPU_s, RAM_MB, User -AutoSize

    Write-Host "  --- TOP RAM ---" -ForegroundColor Yellow
    $procs | Sort-Object RAM_MB -Descending | Select-Object -First $Global:TopProcessCount |
        Format-Table Id, Name, CPU_s, RAM_MB, User -AutoSize

    Write-Log "Top processes viewed." "INFO"
    Pause-Screen
}

# =============================================================================
# 3. Kill a process
# =============================================================================
function Stop-ProcessInteractive {
    Show-Header "TERMINATE PROCESS"

    Write-Host "  Enter process name or PID to terminate: " -NoNewline -ForegroundColor Cyan
    $input = Read-Host

    $target = $null
    if ($input -match '^\d+$') {
        $target = Get-Process -Id ([int]$input) -ErrorAction SilentlyContinue
    } else {
        $target = Get-Process -Name $input -ErrorAction SilentlyContinue
    }

    if (-not $target) {
        Write-Host "`n  [!] Process not found: $input" -ForegroundColor Red
        Write-Log "Attempted to terminate non-existent process: $input" "WARN"
    } else {
        foreach ($p in $target) {
            Write-Host "`n  Process found: $($p.Name) (PID $($p.Id))" -ForegroundColor White
            Write-Host "  Confirm termination? (Y/N): " -NoNewline -ForegroundColor Yellow
            $confirm = Read-Host
            if ($confirm.ToUpper() -eq "Y") {
                try {
                    Stop-Process -Id $p.Id -Force
                    Write-Host "  [OK] Process terminated." -ForegroundColor Green
                    Write-Log "Process terminated: $($p.Name) PID $($p.Id)" "WARN"
                } catch {
                    Write-Host "  [!] Error terminating: $($_.Exception.Message)" -ForegroundColor Red
                    Write-Log "Error terminating process $($p.Name) PID $($p.Id): $($_.Exception.Message)" "ERROR"
                }
            } else {
                Write-Host "  Cancelled." -ForegroundColor DarkGray
            }
        }
    }
    Pause-Screen
}

# =============================================================================
# 4. Auto-kill processes exceeding CPU threshold
# =============================================================================
function Stop-HighCPUProcesses {
    Show-Header "AUTO-KILL - HIGH CPU PROCESSES"

    $protected = @("System","Idle","svchost","lsass","csrss","wininit","services","smss","winlogon","dwm")

    $procs = Get-ProcessList | Where-Object { $_.CPU_s -gt 60 -and $_.Name -notin $protected }

    if (-not $procs) {
        Write-Host "  No processes above CPU threshold (60s accumulated CPU)." -ForegroundColor Green
    } else {
        Write-Host "  Processes identified for termination:" -ForegroundColor Yellow
        $procs | Format-Table Id, Name, CPU_s, RAM_MB -AutoSize

        Write-Host "  Confirm termination of all? (Y/N): " -NoNewline -ForegroundColor Yellow
        $confirm = Read-Host

        if ($confirm.ToUpper() -eq "Y") {
            foreach ($p in $procs) {
                try {
                    Stop-Process -Id $p.Id -Force
                    Write-Host "  [OK] Terminated: $($p.Name) (PID $($p.Id))" -ForegroundColor Green
                    Write-Log "Auto-kill: $($p.Name) PID $($p.Id) CPU=$($p.CPU_s)s" "ALERT"
                } catch {
                    Write-Log "Error terminating $($p.Name): $($_.Exception.Message)" "ERROR"
                }
            }
        }
    }
    Pause-Screen
}

# =============================================================================
# 5. Identify suspicious processes
# =============================================================================
function Find-SuspiciousProcesses {
    Show-Header "SUSPICIOUS PROCESSES"

    $suspicious = @()

    Get-Process | ForEach-Object {
        $proc = $_
        $reason = @()

        try {
            $wmi = Get-CimInstance Win32_Process -Filter "ProcessId=$($proc.Id)" -ErrorAction Stop
            $path = $wmi.ExecutablePath

            if ($path) {
                if ($path -match "\\Temp\\|\\AppData\\Local\\Temp\\") { $reason += "Suspicious path (Temp)" }
                if ($path -match "\\Downloads\\")                      { $reason += "Suspicious path (Downloads)" }
                if ($path -match "\\AppData\\Roaming\\")               { $reason += "Suspicious path (Roaming)" }
            }

            $ramMB = [math]::Round($proc.WorkingSet64 / 1MB, 1)
            if ($ramMB -gt 500 -and $proc.MainWindowHandle -eq 0)     { $reason += "High RAM no window ($($ramMB)MB)" }

        } catch {}

        if ($reason.Count -gt 0) {
            $suspicious += [PSCustomObject]@{
                PID    = $proc.Id
                Name   = $proc.Name
                RAM_MB = [math]::Round($proc.WorkingSet64 / 1MB, 1)
                Reason = ($reason -join "; ")
            }
        }
    }

    if ($suspicious.Count -eq 0) {
        Write-Host "  No suspicious processes detected." -ForegroundColor Green
        Write-Log "Suspicious process scan: none found." "INFO"
    } else {
        Write-Host "  WARNING: Potentially suspicious processes:" -ForegroundColor Magenta
        $suspicious | Format-Table -AutoSize
        Write-Log "Suspicious processes detected: $($suspicious.Count)" "ALERT"
    }
    Pause-Screen
}

# =============================================================================
# 6. Generate report
# =============================================================================
function Export-ProcessReport {
    Show-Header "GENERATE PROCESS REPORT"

    $reportPath = Get-ReportPath "Processes"
    $procs = Get-ProcessList

    $lines = @()
    $lines += "=" * 60
    $lines += "PROCESS & MEMORY REPORT"
    $lines += "Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    $lines += "Server: $env:COMPUTERNAME"
    $lines += "=" * 60
    $lines += ""
    $lines += "TOTAL PROCESSES: $($procs.Count)"
    $lines += ""
    $lines += "--- TOP 10 CPU ---"
    $lines += ($procs | Select-Object -First 10 | Format-Table Id, Name, CPU_s, RAM_MB, User -AutoSize | Out-String)
    $lines += "--- TOP 10 RAM ---"
    $lines += ($procs | Sort-Object RAM_MB -Descending | Select-Object -First 10 | Format-Table Id, Name, CPU_s, RAM_MB, User -AutoSize | Out-String)
    $lines += "--- ALL PROCESSES ---"
    $lines += ($procs | Format-Table -AutoSize | Out-String)

    $lines | Set-Content -Path $reportPath -Encoding UTF8
    Write-Host "  [OK] Report saved to: $reportPath" -ForegroundColor Green
    Write-Log "Process report generated: $reportPath" "INFO"
    Pause-Screen
}

# =============================================================================
# 7. Launch system tool
# =============================================================================
function Start-SystemTool {
    Show-Header "LAUNCH SYSTEM TOOL"

    $allowed = @{
        "1" = @{ name = "Notepad";          exe = "notepad" }
        "2" = @{ name = "Calculator";       exe = "calc" }
        "3" = @{ name = "Paint";            exe = "mspaint" }
        "4" = @{ name = "Task Manager";     exe = "taskmgr" }
        "5" = @{ name = "Event Viewer";     exe = "eventvwr" }
        "6" = @{ name = "Services";         exe = "services.msc" }
        "7" = @{ name = "Disk Management";  exe = "diskmgmt.msc" }
        "8" = @{ name = "Computer Mgmt";    exe = "compmgmt.msc" }
        "9" = @{ name = "Resource Monitor";  exe = "resmon" }
    }

    Write-Host "  Available tools:" -ForegroundColor DarkGray
    Write-Host ""
    foreach ($key in ($allowed.Keys | Sort-Object)) {
        Write-Host "  [$key]  $($allowed[$key].name)" -ForegroundColor White
    }
    Write-Host ""
    Write-Host "  [C]  Custom executable" -ForegroundColor DarkYellow
    Write-Host "  [0]  Back" -ForegroundColor DarkGray
    Write-Host ""

    $pick = Read-Host "  Option"
    if ($pick -eq "0") { return }

    $exe = $null
    if ($pick.ToUpper() -eq "C") {
        Write-Host "  Executable name (e.g. notepad.exe): " -NoNewline -ForegroundColor Cyan
        $exe = Read-Host
    } elseif ($allowed.ContainsKey($pick)) {
        $exe = $allowed[$pick].exe
    } else {
        Write-Host "  Invalid option." -ForegroundColor Red
        Pause-Screen; return
    }

    if (-not $exe) { Write-Host "  No executable specified." -ForegroundColor Red; Pause-Screen; return }

    try {
        $proc = Start-Process -FilePath $exe -PassThru -ErrorAction Stop
        Write-Host "  [OK] Started '$exe' (PID $($proc.Id))" -ForegroundColor Green
        Write-Log "Launched system tool: $exe (PID $($proc.Id))" "INFO"
    } catch {
        Write-Host "  [ERROR] $($_.Exception.Message)" -ForegroundColor Red
        Write-Log "Failed to launch: $exe - $($_.Exception.Message)" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# MODULE MENU
# =============================================================================
function Show-ProcessMenu {
    do {
        Show-Header "PROCESS & MEMORY MANAGEMENT"

        Write-Host "   VIEW" -ForegroundColor DarkCyan
        Write-Host "   [1]  List all processes" -ForegroundColor White
        Write-Host "   [2]  Top processes (CPU & RAM)" -ForegroundColor White
        Write-Host "   [5]  Identify suspicious processes" -ForegroundColor White
        Write-Host ""
        Write-Host "   ACTIONS" -ForegroundColor DarkCyan
        Write-Host "   [3]  Terminate process (manual)" -ForegroundColor White
        Write-Host "   [4]  Auto-kill high CPU processes" -ForegroundColor White
        Write-Host "   [7]  Launch System Tool" -ForegroundColor White
        Write-Host ""
        Write-Host "  ------------------------------------------------------------" -ForegroundColor DarkGray
        Write-Host "   [6]  Generate report" -ForegroundColor DarkYellow
        Write-Host "   [0]  Back to main menu" -ForegroundColor DarkGray
        Write-Host ""

        $choice = Read-Host "  Option"
        switch ($choice) {
            "1" { Show-AllProcesses }
            "2" { Show-TopProcesses }
            "3" { Stop-ProcessInteractive }
            "4" { Stop-HighCPUProcesses }
            "5" { Find-SuspiciousProcesses }
            "6" { Export-ProcessReport }
            "7" { Start-SystemTool }
            "0" { return }
            default { Write-Host "  Invalid option." -ForegroundColor Red; Start-Sleep 1 }
        }
    } while ($true)
}

Show-ProcessMenu
