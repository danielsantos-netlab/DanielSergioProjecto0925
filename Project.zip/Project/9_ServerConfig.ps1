﻿# =============================================================================
# 9_ServerConfig.ps1 - Initial Server Configuration
# ATEC Administration System Module
# Hostname, IP, Timezone, Domain (AD DS), DNS, Remote Desktop, Firewall, Updates
# =============================================================================

# =============================================================================
# HELPERS
# =============================================================================

function Get-ServerOverview {
    $cs = Get-CimInstance Win32_ComputerSystem
    $os = Get-CimInstance Win32_OperatingSystem
    $tz = Get-TimeZone

    # Interface principal
    $iface = Get-NetAdapter | Where-Object { $_.Status -eq "Up" } | Select-Object -First 1
    $ip = $null; $gw = $null; $dns = $null; $dhcp = "N/A"
    if ($iface) {
        $ip = Get-NetIPAddress -InterfaceIndex $iface.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue |
              Where-Object { $_.IPAddress -notlike "169.254.*" } | Select-Object -First 1
        $gw = (Get-NetRoute -InterfaceIndex $iface.ifIndex -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue).NextHop
        $dns = (Get-DnsClientServerAddress -InterfaceIndex $iface.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).ServerAddresses
        $dhcp = (Get-NetIPInterface -InterfaceIndex $iface.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).Dhcp
    }

    # RDP
    $rdp = (Get-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -ErrorAction SilentlyContinue).fDenyTSConnections
    $rdpStatus = if ($rdp -eq 0) { "Enabled" } else { "Disabled" }

    # Firewall
    $fwStatus = (Get-NetFirewallProfile | ForEach-Object {
        "$($_.Name):$(if($_.Enabled){'ON'}else{'OFF'})"
    }) -join "  "

    Write-Host ""
    Write-Host "  Current Server Status" -ForegroundColor DarkCyan
    Write-Host "  $('-' * 50)" -ForegroundColor DarkGray
    Write-Host "  Hostname:    " -NoNewline -ForegroundColor DarkGray; Write-Host "$($cs.Name)" -ForegroundColor White
    Write-Host "  Domain:      " -NoNewline -ForegroundColor DarkGray
    if ($cs.PartOfDomain) {
        Write-Host "$($cs.Domain) (Member)" -ForegroundColor Green
    } else {
        Write-Host "WORKGROUP" -ForegroundColor Yellow
    }
    Write-Host "  OS:          " -NoNewline -ForegroundColor DarkGray; Write-Host "$($os.Caption)" -ForegroundColor White
    Write-Host "  Interface:   " -NoNewline -ForegroundColor DarkGray; Write-Host "$(if($iface){"$($iface.Name)"}else{'N/A'})" -ForegroundColor White
    Write-Host "  IP:          " -NoNewline -ForegroundColor DarkGray; Write-Host "$(if($ip){"$($ip.IPAddress)/$($ip.PrefixLength)"}else{'N/A'}) $(if($dhcp -eq 'Enabled'){'(DHCP)'}else{'(Fixo)'})" -ForegroundColor White
    Write-Host "  Gateway:     " -NoNewline -ForegroundColor DarkGray; Write-Host "$(if($gw){$gw}else{'N/A'})" -ForegroundColor White
    Write-Host "  DNS:         " -NoNewline -ForegroundColor DarkGray; Write-Host "$(if($dns){$dns -join ', '}else{'N/A'})" -ForegroundColor White
    Write-Host "  Timezone:    " -NoNewline -ForegroundColor DarkGray; Write-Host "$($tz.Id)" -ForegroundColor White
    Write-Host "  RDP:         " -NoNewline -ForegroundColor DarkGray; Write-Host "$rdpStatus" -ForegroundColor $(if($rdpStatus -eq "Enabled"){"Green"}else{"Yellow"})
    Write-Host "  Firewall:    " -NoNewline -ForegroundColor DarkGray; Write-Host "$fwStatus" -ForegroundColor White
    Write-Host "  RAM:         " -NoNewline -ForegroundColor DarkGray; Write-Host "$([math]::Round($os.TotalVisibleMemorySize/1MB, 1)) GB" -ForegroundColor White
    Write-Host "  $('-' * 50)" -ForegroundColor DarkGray
    Write-Host ""
}

# =============================================================================
# 1. HOSTNAME
# =============================================================================
function Set-ServerHostname {
    Show-Header "CHANGE HOSTNAME"
    Write-Host "  Current hostname: $env:COMPUTERNAME" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  New hostname (Enter to cancel): " -NoNewline -ForegroundColor Cyan
    $newName = Read-Host
    if ([string]::IsNullOrWhiteSpace($newName)) { return }

    if ($newName -match '[^a-zA-Z0-9\-]') {
        Write-Host "  [!] Invalid hostname. Use only letters, numbers, and hyphens." -ForegroundColor Red
        Pause-Screen; return
    }

    Write-Host "  Change to '$newName'? (s/n): " -NoNewline -ForegroundColor Yellow
    if ((Read-Host) -ne "s") { return }

    try {
        Rename-Computer -NewName $newName -Force
        Write-Log "Hostname changed to '$newName'." "INFO"
        Write-Host "  [OK] Hostname changed to '$newName'." -ForegroundColor Green
        Write-Host "  [!] RESTART required to apply changes." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "  Restart now? (s/n): " -NoNewline -ForegroundColor Cyan
        if ((Read-Host) -eq "s") { Restart-Computer -Force }
    }
    catch {
        Write-Host "  [ERROR] $_" -ForegroundColor Red
        Write-Log "Failed to change hostname: $_" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 2. IP FIXO
# =============================================================================
function Set-ServerIP {
    Show-Header "CONFIGURE STATIC IP"

    [array]$interfaces = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }
    if ($interfaces.Count -eq 0) {
        Write-Host "  [!] No active interfaces found." -ForegroundColor Red
        Pause-Screen; return
    }

    Write-Host "  Available interfaces:" -ForegroundColor DarkCyan
    Write-Host ""
    for ($i = 0; $i -lt $interfaces.Count; $i++) {
        $iface = $interfaces[$i]
        $curIP = Get-NetIPAddress -InterfaceIndex $iface.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                 Where-Object { $_.IPAddress -notlike "169.254.*" } | Select-Object -First 1
        $dhcpSt = (Get-NetIPInterface -InterfaceIndex $iface.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).Dhcp
        $ipTxt = if ($curIP) { "$($curIP.IPAddress)/$($curIP.PrefixLength)" } else { "No IP" }
        $dhcpTxt = if ($dhcpSt -eq "Enabled") { "(DHCP)" } else { "(Static)" }
        Write-Host "  [$($i+1)] $($iface.Name) - $ipTxt $dhcpTxt" -ForegroundColor White
    }
    Write-Host ""

    # Selecao
    if ($interfaces.Count -eq 1) {
        Write-Host "  Single interface selected automatically." -ForegroundColor DarkGray
        $ifSel = $interfaces[0]
    } else {
        Write-Host "  Number of the interface (Enter to cancel): " -NoNewline -ForegroundColor Cyan
        $sel = Read-Host
        if ([string]::IsNullOrWhiteSpace($sel)) { return }
        $idx = [int]$sel - 1
        if ($idx -lt 0 -or $idx -ge $interfaces.Count) {
            Write-Host "  [!] Invalid option." -ForegroundColor Red; Pause-Screen; return
        }
        $ifSel = $interfaces[$idx]
    }

    $ifName = $ifSel.Name
    $ifIndex = $ifSel.ifIndex
    Write-Host ""
    Write-Host "  Configuring: $ifName" -ForegroundColor Cyan
    Write-Host ""

    Write-Host "  New IP (e.g., 192.168.19.10): " -NoNewline -ForegroundColor Cyan; $newIP = Read-Host
    Write-Host "  Prefix (e.g., 24): " -NoNewline -ForegroundColor Cyan; $prefix = Read-Host
    Write-Host "  Gateway (e.g., 192.168.19.1): " -NoNewline -ForegroundColor Cyan; $gw = Read-Host
    Write-Host "  DNS Primario (e.g., 127.0.0.1): " -NoNewline -ForegroundColor Cyan; $dns1 = Read-Host
    Write-Host "  DNS Secundario (Enter to skip): " -NoNewline -ForegroundColor Cyan; $dns2 = Read-Host

    if ([string]::IsNullOrWhiteSpace($newIP) -or [string]::IsNullOrWhiteSpace($prefix) -or [string]::IsNullOrWhiteSpace($gw)) {
        Write-Host "  [!] IP, Prefix and Gateway are required." -ForegroundColor Red
        Pause-Screen; return
    }

    Write-Host ""
    Write-Host "  Interface: $ifName" -ForegroundColor White
    Write-Host "  IP:        $newIP/$prefix" -ForegroundColor White
    Write-Host "  Gateway:   $gw" -ForegroundColor White
    Write-Host "  DNS:       $dns1$(if(-not [string]::IsNullOrWhiteSpace($dns2)){", $dns2"})" -ForegroundColor White
    Write-Host ""
    Write-Host "  Apply? (s/n): " -NoNewline -ForegroundColor Yellow
    if ((Read-Host) -ne "s") { return }

    # Converter prefixo para mascara
    $prefixLen = [int]$prefix
    $maskBin = ('1' * $prefixLen).PadRight(32, '0')
    $subnetMask = [string]::Join('.', @(
        [Convert]::ToInt32($maskBin.Substring(0, 8), 2),
        [Convert]::ToInt32($maskBin.Substring(8, 8), 2),
        [Convert]::ToInt32($maskBin.Substring(16, 8), 2),
        [Convert]::ToInt32($maskBin.Substring(24, 8), 2)
    ))

    try {
        Write-Host "  Applying with netsh..." -ForegroundColor DarkGray
        netsh interface ipv4 set address name="$ifName" static $newIP $subnetMask $gw 2>&1 | Out-Null
        netsh interface ipv4 set dns name="$ifName" static $dns1 primary 2>&1 | Out-Null
        if (-not [string]::IsNullOrWhiteSpace($dns2)) {
            netsh interface ipv4 add dns name="$ifName" $dns2 index=2 2>&1 | Out-Null
        }

        Start-Sleep -Seconds 2
        $verifyIP = Get-NetIPAddress -InterfaceIndex $ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                    Where-Object { $_.IPAddress -notlike "169.254.*" } | Select-Object -First 1

        Write-Host "  [OK] IP configured: $($verifyIP.IPAddress)/$($verifyIP.PrefixLength)" -ForegroundColor Green
        Write-Log "IP configured: $ifName -> $newIP/$prefix GW:$gw DNS:$dns1" "INFO"
    }
    catch {
        Write-Host "  [ERROR] $_" -ForegroundColor Red
        Write-Host "  Manual command: netsh interface ipv4 set address name=`"$ifName`" static $newIP $subnetMask $gw" -ForegroundColor DarkGray
        Write-Log "Failed to configure IP address.: $_" "ERROR"
    }
    Pause-Screen
}

# =============================================================================
# 3. TIMEZONE
# =============================================================================
function Set-ServerTimezone {
    Show-Header "CONFIGURE TIMEZONE"

    $current = Get-TimeZone
    Write-Host "  Current Timezone: $($current.Id) ($($current.DisplayName))" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  [1] GMT Standard Time          (Lisboa, Londres)" -ForegroundColor White
    Write-Host "  [2] Romance Standard Time       (Madrid, Paris)" -ForegroundColor White
    Write-Host "  [3] Central European Std Time   (Berlim)" -ForegroundColor White
    Write-Host "  [4] W. Europe Standard Time     (Amesterdam)" -ForegroundColor White
    Write-Host "  [5] Eastern Standard Time       (Nova Iorque)" -ForegroundColor White
    Write-Host "  [6] UTC" -ForegroundColor White
    Write-Host "  [7] Outro (escrever ID manualmente)" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  Opcao (Enter para cancelar): " -NoNewline -ForegroundColor Cyan
    $sel = Read-Host

    $tzId = switch ($sel) {
        "1" { "GMT Standard Time" }
        "2" { "Romance Standard Time" }
        "3" { "Central European Standard Time" }
        "4" { "W. Europe Standard Time" }
        "5" { "Eastern Standard Time" }
        "6" { "UTC" }
        "7" {
            Write-Host "  (Dica: Get-TimeZone -ListAvailable | Select Id)" -ForegroundColor DarkGray
            Write-Host "  ID da timezone: " -NoNewline -ForegroundColor Cyan
            Read-Host
        }
        default { $null }
    }

    if ([string]::IsNullOrWhiteSpace($tzId)) { return }

    try {
        Set-TimeZone -Id $tzId
        Write-Host "  [OK] Timezone alterado para '$tzId'." -ForegroundColor Green
        Write-Log "Timezone alterado para '$tzId'." "INFO"
    }
    catch {
        Write-Host "  [ERRO] Timezone invalida: $_" -ForegroundColor Red
    }
    Pause-Screen
}

# =============================================================================
# 4. DOMINIO (AD DS)
# =============================================================================
function Set-ServerDomain {
    Show-Header "CONFIGURE DOMAIN (ACTIVE DIRECTORY)"

    $cs = Get-CimInstance Win32_ComputerSystem
    if ($cs.PartOfDomain) {
        Write-Host "  State: Member of domain '$($cs.Domain)'" -ForegroundColor Green
    } else {
        Write-Host "  State: WORKGROUP (no domain)" -ForegroundColor Yellow
    }
    Write-Host ""
    Write-Host "  [1] Create new domain (new AD DS forest)" -ForegroundColor White
    Write-Host "  [2] Join existing domain" -ForegroundColor White
    Write-Host "  [3] Leave domain (return to WORKGROUP)" -ForegroundColor White
    Write-Host ""
    Write-Host "  Option (Enter to cancel): " -NoNewline -ForegroundColor Cyan
    $sel = Read-Host

    switch ($sel) {
        "1" {
            Write-Host ""
            Write-Host "  Domain name (e.g., atec.local): " -NoNewline -ForegroundColor Cyan; $domName = Read-Host
            Write-Host "  NETBIOS name (e.g., ATEC): " -NoNewline -ForegroundColor Cyan; $netbios = Read-Host
            if ([string]::IsNullOrWhiteSpace($domName)) { return }

            Write-Host ""
            Write-Host "  Domain: $domName | NETBIOS: $netbios" -ForegroundColor White
            Write-Host "  This will install AD DS and promote the server to a DC. Continue? (y/n): " -NoNewline -ForegroundColor Yellow
            if ((Read-Host) -ne "y") { return }

            try {
                Write-Host "  Installing AD DS..." -ForegroundColor DarkGray
                Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools | Out-Null

                $dsrmPass = Read-Host "  Password DSRM" -AsSecureString

                Install-ADDSForest `
                    -DomainName $domName `
                    -DomainNetbiosName $netbios `
                    -SafeModeAdministratorPassword $dsrmPass `
                    -InstallDns:$true `
                    -CreateDnsDelegation:$false `
                    -DatabasePath "C:\Windows\NTDS" `
                    -LogPath "C:\Windows\NTDS" `
                    -SysvolPath "C:\Windows\SYSVOL" `
                    -NoRebootOnCompletion:$false `
                    -Force:$true

                Write-Log "Domain '$domName' created. Server promoted to DC." "INFO"
            }
            catch { Write-Host "  [ERRO] $_" -ForegroundColor Red; Write-Log "Failed AD DS: $_" "ERROR" }
        }
        "2" {
            Write-Host "  Domain to join (e.g., atec.local): " -NoNewline -ForegroundColor Cyan; $joinDom = Read-Host
            if ([string]::IsNullOrWhiteSpace($joinDom)) { return }
            $cred = Get-Credential -Message "Domain administrator credentials '$joinDom'"
            try {
                Add-Computer -DomainName $joinDom -Credential $cred -Restart -Force
                Write-Log "Server added to domain '$joinDom'." "INFO"
            }
            catch { Write-Host "  [ERRO] $_" -ForegroundColor Red; Write-Log "Failed to join domain: $_" "ERROR" }
        }
        "3" {
            if (-not $cs.PartOfDomain) {
                Write-Host "  [!] The server is not part of a domain." -ForegroundColor Yellow
                Pause-Screen; return
            }
            Write-Host "  Leave domain '$($cs.Domain)'? (write SIM): " -NoNewline -ForegroundColor Yellow
            if ((Read-Host) -ne "SIM") { return }
            try {
                $cred = Get-Credential -Message "Domain administrator credentials"
                Remove-Computer -UnjoinDomainCredential $cred -WorkgroupName "WORKGROUP" -Restart -Force
                Write-Log "Server removed from domain." "INFO"
            }
            catch { Write-Host "  [ERROR] $_" -ForegroundColor Red; Write-Log "Failed to leave domain: $_" "ERROR" }
        }
    }
    Pause-Screen
}

# =============================================================================
# 5. REMOTE DESKTOP
# =============================================================================
function Set-ServerRDP {
    Show-Header "REMOTE DESKTOP"

    $rdp = (Get-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server').fDenyTSConnections
    $isOn = ($rdp -eq 0)

    Write-Host "  Current state: $(if($isOn){'ENABLED'}else{'DISABLED'})" -ForegroundColor $(if($isOn){"Green"}else{"Yellow"})
    Write-Host ""

    if ($isOn) {
        Write-Host "  Disable Remote Desktop? (s/n): " -NoNewline -ForegroundColor Cyan
        if ((Read-Host) -eq "s") {
            Set-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -Value 1
            Disable-NetFirewallRule -DisplayGroup "Remote Desktop" -ErrorAction SilentlyContinue
            Write-Host "  [OK] Remote Desktop disabled." -ForegroundColor Green
            Write-Log "RDP disabled." "INFO"
        }
    } else {
        Write-Host "  Enable Remote Desktop? (s/n): " -NoNewline -ForegroundColor Cyan
        if ((Read-Host) -eq "s") {
            Set-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -Value 0
            Enable-NetFirewallRule -DisplayGroup "Remote Desktop" -ErrorAction SilentlyContinue
            Set-NetFirewallRule -Name "RemoteDesktop-UserMode-In-TCP" -Enabled True -ErrorAction SilentlyContinue
            Write-Host "  [OK] Remote Desktop enabled." -ForegroundColor Green
            Write-Log "RDP enabled." "INFO"
        }
    }
    Pause-Screen
}

# =============================================================================
# 6. DNS
# =============================================================================
function Set-ServerDNS {
    Show-Header "CONFIGURE DNS SERVICE"

    $dnsOK = (Get-WindowsFeature -Name DNS -ErrorAction SilentlyContinue).Installed
    if (-not $dnsOK) {
        Write-Host "  DNS service not installed." -ForegroundColor Yellow
        Write-Host "  Install now? (s/n): " -NoNewline -ForegroundColor Cyan
        if ((Read-Host) -eq "s") {
            Install-WindowsFeature -Name DNS -IncludeManagementTools | Out-Null
            Write-Host "  [OK] DNS installed." -ForegroundColor Green
            Write-Log "DNS service installed." "INFO"
        } else { return }
    }

    Write-Host ""
    Write-Host "  [1] Create direct lookup zone" -ForegroundColor White
    Write-Host "  [2] Create inverse lookup zone" -ForegroundColor White
    Write-Host "  [3] Add A record (host)" -ForegroundColor White
    Write-Host "  [4] Add forwarder" -ForegroundColor White
    Write-Host "  [5] View existing zones" -ForegroundColor White
    Write-Host ""
    Write-Host "  Option (Enter to cancel): " -NoNewline -ForegroundColor Cyan
    $sel = Read-Host

    switch ($sel) {
        "1" {
            Write-Host "  Zone name (e.g., atec.local): " -NoNewline -ForegroundColor Cyan; $z = Read-Host
            try {
                Add-DnsServerPrimaryZone -Name $z -ReplicationScope Domain -ErrorAction Stop
                Write-Host "  [OK] Zone '$z' created." -ForegroundColor Green
                Write-Log "DNS zone created: $z" "INFO"
            } catch {
                try {
                    Add-DnsServerPrimaryZone -Name $z -ZoneFile "$z.dns"
                    Write-Host "  [OK] Zone '$z' created (local file)." -ForegroundColor Green
                } catch { Write-Host "  [ERROR] $_" -ForegroundColor Red }
            }
        }
        "2" {
            Write-Host "  Network (e.g., 192.168.19): " -NoNewline -ForegroundColor Cyan; $net = Read-Host
            try {
                Add-DnsServerPrimaryZone -NetworkID "$net.0/24" -ReplicationScope Domain
                Write-Host "  [OK] Inverse zone created for $net.0/24" -ForegroundColor Green
                Write-Log "Inverse DNS zone created: $net.0/24" "INFO"
            } catch { Write-Host "  [ERROR] $_" -ForegroundColor Red }
        }
        "3" {
            Write-Host "  Zone name (e.g., atec.local): " -NoNewline -ForegroundColor Cyan; $z = Read-Host
            Write-Host "  Hostname (e.g., webserver): " -NoNewline -ForegroundColor Cyan; $h = Read-Host
            Write-Host "  IP (e.g., 192.168.1.100): " -NoNewline -ForegroundColor Cyan; $ip = Read-Host
            try {
                Add-DnsServerResourceRecordA -ZoneName $z -Name $h -IPv4Address $ip
                Write-Host "  [OK] Record: $h.$z -> $ip" -ForegroundColor Green
                Write-Log "DNS A record added: $h.$z -> $ip" "INFO"
            } catch { Write-Host "  [ERROR] $_" -ForegroundColor Red }
        }
        "4" {
            Write-Host "  IP of forwarder (e.g., 8.8.8.8): " -NoNewline -ForegroundColor Cyan; $fw = Read-Host
            try {
                Add-DnsServerForwarder -IPAddress $fw
                Write-Host "  [OK] Forwarder $fw added." -ForegroundColor Green
                Write-Log "DNS forwarder added: $fw" "INFO"
            } catch { Write-Host "  [ERROR] $_" -ForegroundColor Red }
        }
        "5" {
            Write-Host ""
            Get-DnsServerZone -ErrorAction SilentlyContinue | Format-Table ZoneName, ZoneType, IsReverseLookupZone -AutoSize
        }
    }
    Pause-Screen
}

# =============================================================================
# 7. FIREWALL
# =============================================================================
function Set-ServerFirewall {
    Show-Header "CONFIGURE FIREWALL"

    $profiles = Get-NetFirewallProfile
    Write-Host "  Current state:" -ForegroundColor DarkCyan
    foreach ($p in $profiles) {
        $st = if ($p.Enabled) { "ON" } else { "OFF" }
        $color = if ($p.Enabled) { "Green" } else { "Yellow" }
        Write-Host "    $($p.Name): $st" -ForegroundColor $color
    }

    Write-Host ""
    Write-Host "  [1] Activate all profiles" -ForegroundColor White
    Write-Host "  [2] Deactivate all profiles" -ForegroundColor White
    Write-Host "  [3] Open specific port" -ForegroundColor White
    Write-Host "  [4] View active Inbound rules" -ForegroundColor White
    Write-Host ""
    Write-Host "  Option (Enter to cancel): " -NoNewline -ForegroundColor Cyan
    $sel = Read-Host

    switch ($sel) {
        "1" {
            Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True
            Write-Host "  [OK] Firewall activated in all profiles." -ForegroundColor Green
            Write-Log "Firewall activated (all profiles)." "INFO"
        }
        "2" {
            Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False
            Write-Host "  [OK] Firewall deactivated." -ForegroundColor Green
            Write-Log "Firewall deactivated." "WARN"
        }
        "3" {
            Write-Host "  Name of rule (e.g., Allow-HTTP): " -NoNewline -ForegroundColor Cyan; $name = Read-Host
            Write-Host "  Port (e.g., 80): " -NoNewline -ForegroundColor Cyan; $port = Read-Host
            Write-Host "  Protocol (TCP/UDP): " -NoNewline -ForegroundColor Cyan; $proto = Read-Host
            try {
                New-NetFirewallRule -DisplayName $name -Direction Inbound -Protocol $proto -LocalPort $port -Action Allow | Out-Null
                Write-Host "  [OK] Rule '$name' created ($port/$proto)." -ForegroundColor Green
                Write-Log "Firewall rule created: $name ($port/$proto)." "INFO"
            } catch { Write-Host "  [ERROR] $_" -ForegroundColor Red }
        }
        "4" {
            Get-NetFirewallRule | Where-Object { $_.Enabled -eq $true -and $_.Direction -eq "Inbound" } |
                Select-Object DisplayName, Action, Profile |
                Sort-Object DisplayName |
                Format-Table -AutoSize |
                Out-Host -Paging
        }
    }
    Pause-Screen
}

# =============================================================================
# 8. WINDOWS UPDATE
# =============================================================================
function Set-ServerUpdates {
    Show-Header "WINDOWS UPDATE"

    Write-Host "  [1] Check for available updates" -ForegroundColor White
    Write-Host "  [2] Install all updates" -ForegroundColor White
    Write-Host ""
    Write-Host "  Option (Enter to cancel): " -NoNewline -ForegroundColor Cyan
    $sel = Read-Host

    if ($sel -notin @("1","2")) { return }

    # Garantir modulo
    if (-not (Get-Module -ListAvailable -Name PSWindowsUpdate -ErrorAction SilentlyContinue)) {
        Write-Host "  Installing PSWindowsUpdate module..." -ForegroundColor DarkGray
        Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -ErrorAction SilentlyContinue | Out-Null
        Install-Module PSWindowsUpdate -Force -ErrorAction SilentlyContinue | Out-Null
    }
    Import-Module PSWindowsUpdate -ErrorAction SilentlyContinue

    switch ($sel) {
        "1" {
            Write-Host "  Checking for updates..." -ForegroundColor DarkGray
            Get-WindowsUpdate
            Write-Log "Windows Update checked." "INFO"
        }
        "2" {
            Write-Host "  Installing updates (may take time)..." -ForegroundColor DarkGray
            Install-WindowsUpdate -AcceptAll -AutoReboot
            Write-Log "Windows Update installed." "INFO"
        }
    }
    Pause-Screen
}

# =============================================================================
# 9. ROLES & FEATURES
# =============================================================================
function Set-ServerRoles {
    do {
        Show-Header "ROLES & FEATURES"

        # Get installed and available
        $all = Get-WindowsFeature -ErrorAction SilentlyContinue
        $installed = $all | Where-Object { $_.Installed -eq $true }
        $roles     = $installed | Where-Object { $_.FeatureType -eq "Role" }
        $features  = $installed | Where-Object { $_.FeatureType -ne "Role" }

        Write-Host "  Installed: $($roles.Count) roles, $($features.Count) features" -ForegroundColor DarkGray
        Write-Host ""
        Write-Host "  [1]  List installed roles & features" -ForegroundColor White
        Write-Host "  [2]  Search available roles & features" -ForegroundColor White
        Write-Host "  [3]  Install a role or feature" -ForegroundColor White
        Write-Host "  [4]  Remove a role or feature" -ForegroundColor White
        Write-Host ""
        Write-Host "  [B]  Back" -ForegroundColor DarkYellow
        Write-Host ""

        $sel = Read-Host "  Option"

        switch ($sel.ToUpper()) {
            "1" {
                Show-Header "INSTALLED ROLES & FEATURES"
                Write-Host "  -- ROLES --" -ForegroundColor Cyan
                if ($roles) {
                    $roles | Sort-Object DisplayName | ForEach-Object {
                        Write-Host "    [*] $($_.DisplayName)" -ForegroundColor Green
                    }
                } else { Write-Host "    (none)" -ForegroundColor DarkGray }

                Write-Host ""
                Write-Host "  -- FEATURES --" -ForegroundColor Cyan
                if ($features) {
                    $features | Sort-Object DisplayName | ForEach-Object {
                        Write-Host "    [*] $($_.DisplayName)" -ForegroundColor Green
                    }
                } else { Write-Host "    (none)" -ForegroundColor DarkGray }
                Pause-Screen
            }
            "2" {
                Write-Host ""
                Write-Host "  Search term (ex: DNS, DHCP, IIS, Hyper): " -NoNewline -ForegroundColor Cyan
                $search = Read-Host
                if ([string]::IsNullOrWhiteSpace($search)) { continue }

                $results = $all | Where-Object { $_.DisplayName -like "*$search*" -or $_.Name -like "*$search*" } |
                           Sort-Object FeatureType, DisplayName | Select-Object -First 25

                if (-not $results) {
                    Write-Host "  No results for '$search'." -ForegroundColor Yellow
                } else {
                    Write-Host ""
                    Write-Host "  --------------------------------------------------------" -ForegroundColor DarkGray
                    Write-Host "  NAME                                TYPE       STATUS" -ForegroundColor DarkCyan
                    Write-Host "  --------------------------------------------------------" -ForegroundColor DarkGray
                    foreach ($r in $results) {
                        $status = if ($r.Installed) { "Installed" } else { "Available" }
                        $color  = if ($r.Installed) { "Green" } else { "White" }
                        $line = "  " + $r.DisplayName.PadRight(38) + "$($r.FeatureType)".PadRight(11) + $status
                        Write-Host $line -ForegroundColor $color
                    }
                    Write-Host ""
                    Write-Host "  Use the NAME column value to install/remove." -ForegroundColor DarkGray
                }
                Pause-Screen
            }
            "3" {
                Write-Host ""
                Write-Host "  Name of role/feature to install: " -NoNewline -ForegroundColor Cyan
                $name = Read-Host
                if ([string]::IsNullOrWhiteSpace($name)) { continue }

                # Validate it exists
                $feature = Get-WindowsFeature -Name $name -ErrorAction SilentlyContinue
                if (-not $feature) {
                    # Try searching by display name
                    $feature = Get-WindowsFeature | Where-Object { $_.DisplayName -like "*$name*" } | Select-Object -First 1
                }

                if (-not $feature) {
                    Write-Host "  [!] '$name' not found. Use option 2 to search." -ForegroundColor Red
                    Pause-Screen; continue
                }

                if ($feature.Installed) {
                    Write-Host "  [!] '$($feature.DisplayName)' is already installed." -ForegroundColor Yellow
                    Pause-Screen; continue
                }

                Write-Host ""
                Write-Host "  Role/Feature: $($feature.DisplayName) ($($feature.Name))" -ForegroundColor White
                Write-Host "  Type:         $($feature.FeatureType)" -ForegroundColor DarkGray
                Write-Host ""
                Write-Host "  Include management tools? (s/n): " -NoNewline -ForegroundColor Cyan
                $inclMgmt = (Read-Host) -eq "s"

                Write-Host "  Install '$($feature.DisplayName)'? (s/n): " -NoNewline -ForegroundColor Yellow
                if ((Read-Host) -ne "s") { continue }

                Write-Host ""
                Write-Host "  Installing..." -ForegroundColor DarkGray
                try {
                    $params = @{ Name = $feature.Name; ErrorAction = "Stop" }
                    if ($inclMgmt) { $params["IncludeManagementTools"] = $true }

                    $result = Install-WindowsFeature @params
                    Write-Host "  [OK] '$($feature.DisplayName)' installed successfully." -ForegroundColor Green
                    Write-Log "Role/Feature installed: $($feature.DisplayName) ($($feature.Name))" "INFO"

                    if ($result.RestartNeeded -eq "Yes") {
                        Write-Host "  [!] RESTART REQUIRED to complete installation." -ForegroundColor Yellow
                        Write-Host "  Restart now? (s/n): " -NoNewline -ForegroundColor Cyan
                        if ((Read-Host) -eq "s") { Restart-Computer -Force }
                    }
                }
                catch {
                    Write-Host "  [ERROR] $_" -ForegroundColor Red
                    Write-Log "Failed to install $($feature.Name): $_" "ERROR"
                }
                Pause-Screen
            }
            "4" {
                Write-Host ""
                Write-Host "  Name of role/feature to remove: " -NoNewline -ForegroundColor Cyan
                $name = Read-Host
                if ([string]::IsNullOrWhiteSpace($name)) { continue }

                $feature = Get-WindowsFeature -Name $name -ErrorAction SilentlyContinue
                if (-not $feature) {
                    $feature = Get-WindowsFeature | Where-Object { $_.DisplayName -like "*$name*" -and $_.Installed } | Select-Object -First 1
                }

                if (-not $feature) {
                    Write-Host "  [!] '$name' not found." -ForegroundColor Red
                    Pause-Screen; continue
                }
                if (-not $feature.Installed) {
                    Write-Host "  [!] '$($feature.DisplayName)' is not installed." -ForegroundColor Yellow
                    Pause-Screen; continue
                }

                Write-Host ""
                Write-Host "  REMOVE '$($feature.DisplayName)'? This may affect services. (type YES): " -NoNewline -ForegroundColor Yellow
                if ((Read-Host) -ne "YES") { continue }

                try {
                    $result = Remove-WindowsFeature -Name $feature.Name -ErrorAction Stop
                    Write-Host "  [OK] '$($feature.DisplayName)' removed." -ForegroundColor Green
                    Write-Log "Role/Feature removed: $($feature.DisplayName) ($($feature.Name))" "WARN"

                    if ($result.RestartNeeded -eq "Yes") {
                        Write-Host "  [!] RESTART REQUIRED." -ForegroundColor Yellow
                        Write-Host "  Restart now? (s/n): " -NoNewline -ForegroundColor Cyan
                        if ((Read-Host) -eq "s") { Restart-Computer -Force }
                    }
                }
                catch {
                    Write-Host "  [ERROR] $_" -ForegroundColor Red
                    Write-Log "Failed to remove $($feature.Name): $_" "ERROR"
                }
                Pause-Screen
            }
            "B" { return }
            default { Write-Host "`n  Invalid option." -ForegroundColor Red; Start-Sleep -Seconds 1 }
        }
    } while ($true)
}

# =============================================================================
# SUBMENU - CONFIGURACAO DO SERVIDOR
# =============================================================================
function Show-ServerConfigMenu {
    do {
        Show-Header "INITIAL SERVER CONFIGURATION"
        Get-ServerOverview

        Write-Host "  [1]  Change Hostname" -ForegroundColor White
        Write-Host "  [2]  Configure Static IP" -ForegroundColor White
        Write-Host "  [3]  Configure Timezone" -ForegroundColor White
        Write-Host "  [4]  Configure Domain (AD DS)" -ForegroundColor White
        Write-Host "  [5]  Remote Desktop (Enable/Disable)" -ForegroundColor White
        Write-Host "  [6]  Configure DNS Service" -ForegroundColor White
        Write-Host "  [7]  Configure Firewall" -ForegroundColor White
        Write-Host "  [8]  Windows Update" -ForegroundColor White
        Write-Host "  [9]  Roles & Features" -ForegroundColor White
        Write-Host ""
        Write-Host "  [B]  Back to Main Menu" -ForegroundColor DarkYellow
        Write-Host ""
        Write-Host ("=" * 60) -ForegroundColor DarkCyan
        Write-Host ""

        $choice = Read-Host "  Option"

        switch ($choice.ToUpper()) {
            "1" { Set-ServerHostname }
            "2" { Set-ServerIP }
            "3" { Set-ServerTimezone }
            "4" { Set-ServerDomain }
            "5" { Set-ServerRDP }
            "6" { Set-ServerDNS }
            "7" { Set-ServerFirewall }
            "8" { Set-ServerUpdates }
            "9" { Set-ServerRoles }
            "B" { return }
            default { Write-Host "`n  Invalid option." -ForegroundColor Red; Start-Sleep -Seconds 1 }
        }
    } while ($true)
}

# --- Entry point (called by Open-Module from MainMenu.ps1) ---
Show-ServerConfigMenu
